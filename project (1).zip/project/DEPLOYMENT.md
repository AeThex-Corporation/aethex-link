# Quick Deployment Guide

## Deploy to Vercel in 5 Minutes

### Option 1: GitHub Integration (Easiest)

1. **Push to GitHub:**
```bash
git init
git add .
git commit -m "Initial deployment"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/aethex-platform.git
git push -u origin main
```

2. **Deploy on Vercel:**
   - Visit https://vercel.com/new
   - Click "Import Git Repository"
   - Select your repository
   - Vercel auto-detects React Router
   - Add environment variables (see below)
   - Click "Deploy"

3. **Add Domain:**
   - Vercel Dashboard → Your Project → Settings → Domains
   - Add: `aethex.me`
   - Add: `*.aethex.me`
   - Follow DNS instructions Vercel provides

### Option 2: Vercel CLI (Fastest)

```bash
# Install Vercel CLI
npm install -g vercel

# Login
vercel login

# Deploy
vercel

# Deploy to production
vercel --prod
```

## Required Environment Variables

Add these in Vercel Dashboard → Settings → Environment Variables:

```
JWT_SECRET=your_jwt_secret_here
GITHUB_TOKEN=your_github_token_here
STACKOVERFLOW_API_KEY=your_stackoverflow_key_here
FREENAME_API_URL=https://api.freename.io/v1
FREENAME_API_KEY=your_freename_api_key_here
FREENAME_RESELLER_ID=your_reseller_id_here
```

## DNS Configuration (Spaceship)

In your Spaceship DNS settings for aethex.me:

**A Record:**
```
Type: A
Name: @
Value: 76.76.21.21
```

**Wildcard CNAME:**
```
Type: CNAME  
Name: *
Value: cname.vercel-dns.com
```

**TXT Record (Vercel provides this):**
```
Type: TXT
Name: _vercel
Value: [copy from Vercel dashboard]
```

## Testing

After deployment and DNS propagation (up to 48 hours):

1. Visit `https://aethex.me` - Should load home page
2. Register account with username "test"
3. Visit `https://test.aethex.me` - Should show your portfolio
4. Try `https://random.aethex.me` - Should show 404

## Troubleshooting

**Subdomains not working?**
- Wait for DNS propagation (check https://dnschecker.org)
- Verify wildcard domain added in Vercel
- Check Vercel logs for errors

**Build fails?**
- Check environment variables are set
- Verify all dependencies in package.json
- Check build logs in Vercel dashboard

**Need help?**
See `PRODUCTION_DEPLOYMENT.md` for detailed guide.
