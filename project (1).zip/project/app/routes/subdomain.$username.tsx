import type { Route } from './+types/subdomain.$username';
import { db } from '~/lib/db.server';
import { Card, CardContent, CardHeader, CardTitle } from '~/components/ui/card/card';
import { Badge } from '~/components/ui/badge/badge';
import { Button } from '~/components/ui/button/button';
import { Avatar, AvatarFallback, AvatarImage } from '~/components/ui/avatar/avatar';
import { 
  GithubIcon, 
  LinkedinIcon, 
  TwitterIcon, 
  Globe, 
  Mail,
  MapPin,
  Briefcase,
  Shield,
} from 'lucide-react';
import styles from './subdomain.$username.module.css';

export async function loader({ params, request }: Route.LoaderArgs) {
  const { username } = params;
  
  // Check if this is a subdomain request
  const host = request.headers.get('host') || '';
  const parts = host.split('.');
  
  // Determine target username from subdomain or params
  let targetUsername = username;
  
  // Handle subdomain.aethex.me (free tier)
  if (parts.length >= 3 && parts[parts.length - 2] === 'aethex' && parts[parts.length - 1] === 'me') {
    targetUsername = parts[0];
  }
  // Handle subdomain.aethex (premium tier)
  else if (parts.length >= 2 && parts[parts.length - 1] === 'aethex') {
    targetUsername = parts[0];
  }

  const user = await db.user.findByUsername(targetUsername);
  
  if (!user) {
    throw new Response('User not found', { status: 404 });
  }

  const profile = await db.profile.findByUserId(user.id);
  const portfolio = await db.portfolio.findByUserId(user.id);

  return {
    user: {
      id: user.id,
      username: user.username,
      name: user.name,
      bio: user.bio,
      avatar: user.avatar,
      location: user.location,
      title: user.title,
      domainTier: user.domainTier,
      aethexDomain: user.aethexDomain,
    },
    profile: {
      githubUsername: profile?.githubUsername,
      stackOverflowId: profile?.stackOverflowId,
      npmUsername: profile?.npmUsername,
      devtoUsername: profile?.devtoUsername,
      mediumUsername: profile?.mediumUsername,
    },
    portfolio,
  };
}

export default function SubdomainProfile({ loaderData }: Route.ComponentProps) {
  const { user, profile, portfolio } = loaderData;

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <div className={styles.hero}>
          <Avatar className={styles.avatar}>
            <AvatarImage src={user.avatar} alt={user.name} />
            <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
          </Avatar>
          
          <div className={styles.userInfo}>
            <div className={styles.nameRow}>
              <h1 className={styles.name}>{user.name}</h1>
              {user.domainTier === 'premium' && (
                <Badge variant="default" className={styles.verifiedBadge}>
                  <Shield size={12} />
                  Verified
                </Badge>
              )}
            </div>
            <p className={styles.username}>
              @{user.username}
              {user.domainTier === 'premium' && user.aethexDomain && (
                <span className={styles.premiumDomain}> • {user.aethexDomain}</span>
              )}
            </p>
            {user.title && <p className={styles.title}><Briefcase size={16} /> {user.title}</p>}
            {user.location && <p className={styles.location}><MapPin size={16} /> {user.location}</p>}
            {user.bio && <p className={styles.bio}>{user.bio}</p>}
            
            <div className={styles.links}>
              {profile.githubUsername && (
                <Button variant="ghost" size="sm" asChild>
                  <a href={`https://github.com/${profile.githubUsername}`} target="_blank" rel="noopener noreferrer">
                    <GithubIcon size={18} /> GitHub
                  </a>
                </Button>
              )}
              {profile.npmUsername && (
                <Button variant="ghost" size="sm" asChild>
                  <a href={`https://npmjs.com/~${profile.npmUsername}`} target="_blank" rel="noopener noreferrer">
                    <Globe size={18} /> NPM
                  </a>
                </Button>
              )}
              {profile.devtoUsername && (
                <Button variant="ghost" size="sm" asChild>
                  <a href={`https://dev.to/${profile.devtoUsername}`} target="_blank" rel="noopener noreferrer">
                    <Globe size={18} /> Dev.to
                  </a>
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className={styles.content}>
        <h2 className={styles.sectionTitle}>Portfolio</h2>
        
        {portfolio.length === 0 ? (
          <Card>
            <CardContent className={styles.empty}>
              <p>No portfolio items yet</p>
            </CardContent>
          </Card>
        ) : (
          <div className={styles.portfolio}>
            {portfolio.map(item => (
              <Card key={item.id} className={styles.portfolioCard}>
                {item.thumbnailUrl && (
                  <div className={styles.thumbnail}>
                    <img src={item.thumbnailUrl} alt={item.title} />
                  </div>
                )}
                <CardHeader>
                  <div className={styles.cardHeader}>
                    <CardTitle>{item.title}</CardTitle>
                    <Badge>{item.type}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className={styles.description}>{item.description}</p>
                  {item.tags && item.tags.length > 0 && (
                    <div className={styles.tags}>
                      {item.tags.map(tag => (
                        <Badge key={tag} variant="outline">{tag}</Badge>
                      ))}
                    </div>
                  )}
                  {item.url && (
                    <Button variant="link" asChild className={styles.viewButton}>
                      <a href={item.url} target="_blank" rel="noopener noreferrer">
                        View Project →
                      </a>
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <footer className={styles.footer}>
        <p>Powered by Aethex</p>
      </footer>
    </div>
  );
}
