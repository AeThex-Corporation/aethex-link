import { sessionStorage } from '~/lib/session.server';

export async function action({ request }: { request: Request }) {
  const session = await sessionStorage.getSession(request.headers.get('Cookie'));
  
  return Response.json(
    { success: true },
    {
      headers: {
        'Set-Cookie': await sessionStorage.destroySession(session),
      },
    }
  );
}
