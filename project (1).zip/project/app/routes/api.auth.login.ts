import type { Route } from './+types/api.auth.login';
import { auth } from '~/lib/auth.server';
import { sessionStorage } from '~/lib/session.server';

export async function action({ request }: Route.ActionArgs) {
  if (request.method !== 'POST') {
    return new Response('Method not allowed', { status: 405 });
  }

  try {
    const body = await request.json();
    const { email, password } = body;

    if (!email || !password) {
      return Response.json(
        { error: 'Email and password are required' },
        { status: 400 }
      );
    }

    const result = await auth.login({ email, password });

    // Create session
    const session = await sessionStorage.getSession();
    session.set('userId', result.user.id);

    return Response.json(result, {
      headers: {
        'Set-Cookie': await sessionStorage.commitSession(session),
      },
    });
  } catch (error: any) {
    return Response.json(
      { error: error.message || 'Login failed' },
      { status: 401 }
    );
  }
}
