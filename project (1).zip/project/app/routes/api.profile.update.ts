import type { Route } from './+types/api.profile.update';
import { auth } from '~/lib/auth.server';
import { db } from '~/lib/db.server';
import { getUserId } from '~/lib/session.server';

export async function action({ request }: Route.ActionArgs) {
  if (request.method !== 'POST') {
    return new Response('Method not allowed', { status: 405 });
  }

  try {
    // Get user from session or token
    let userId: string | null = await getUserId(request);
    if (!userId) {
      const user = await auth.getOptionalUser(request);
      if (!user || !user.id) {
        throw new Response('Unauthorized', { status: 401 });
      }
      userId = user.id;
    }

    const body = await request.json();

    // Update user fields
    const { name, bio, location, title, avatar } = body;
    
    if (!userId) {
      throw new Response('Unauthorized', { status: 401 });
    }
    
    const updatedUser = await db.user.update(userId, {
      name,
      bio,
      location,
      title,
      avatar,
    });

    if (!updatedUser) {
      return Response.json(
        { error: 'Failed to update profile' },
        { status: 500 }
      );
    }

    return Response.json({ 
      success: true, 
      user: auth.sanitizeUser(updatedUser) 
    });
  } catch (error: any) {
    if (error instanceof Response) {
      throw error;
    }
    return Response.json(
      { error: error.message || 'Failed to update profile' },
      { status: 500 }
    );
  }
}
