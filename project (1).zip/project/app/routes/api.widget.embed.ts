import type { Route } from './+types/api.widget.embed';
import { db } from '~/lib/db.server';

/**
 * Embeddable widget generator
 * Returns JavaScript code that creators can embed on their websites
 */
export async function loader({ request }: Route.LoaderArgs) {
  const url = new URL(request.url);
  const username = url.searchParams.get('username');
  const type = url.searchParams.get('type') || 'card'; // card, badge, portfolio
  const theme = url.searchParams.get('theme') || 'light';

  if (!username) {
    return new Response('Username required', { status: 400 });
  }

  const user = await db.user.findByUsername(username);
  
  if (!user) {
    return new Response('User not found', { status: 404 });
  }

  const profile = await db.profile.findByUserId(user.id);
  const portfolio = await db.portfolio.findByUserId(user.id);

  // Generate widget data
  const widgetData = {
    user: {
      username: user.username,
      name: user.name,
      bio: user.bio,
      avatar: user.avatar,
      title: user.title,
      aethexDomain: user.aethexDomain,
    },
    profile: {
      githubUsername: profile?.githubUsername,
      npmUsername: profile?.npmUsername,
    },
    portfolio: portfolio.slice(0, 3).map(item => ({
      title: item.title,
      description: item.description,
      url: item.url,
      thumbnailUrl: item.thumbnailUrl,
    })),
  };

  // Generate embeddable JavaScript
  const widgetScript = `
(function() {
  const data = ${JSON.stringify(widgetData)};
  const theme = '${theme}';
  const type = '${type}';
  
  const styles = \`
    .aethex-widget {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      border: 1px solid #e5e7eb;
      border-radius: 12px;
      padding: 24px;
      background: ${theme === 'dark' ? '#1f2937' : '#ffffff'};
      color: ${theme === 'dark' ? '#f9fafb' : '#111827'};
      max-width: 400px;
    }
    .aethex-widget-header {
      display: flex;
      align-items: center;
      gap: 16px;
      margin-bottom: 16px;
    }
    .aethex-widget-avatar {
      width: 64px;
      height: 64px;
      border-radius: 50%;
      object-fit: cover;
    }
    .aethex-widget-name {
      font-size: 1.25rem;
      font-weight: 700;
      margin: 0;
    }
    .aethex-widget-title {
      font-size: 0.875rem;
      color: ${theme === 'dark' ? '#9ca3af' : '#6b7280'};
      margin: 4px 0 0;
    }
    .aethex-widget-bio {
      margin: 12px 0;
      line-height: 1.6;
    }
    .aethex-widget-links {
      display: flex;
      gap: 8px;
      margin-top: 16px;
    }
    .aethex-widget-link {
      display: inline-flex;
      align-items: center;
      padding: 8px 12px;
      border-radius: 6px;
      background: ${theme === 'dark' ? '#374151' : '#f3f4f6'};
      color: ${theme === 'dark' ? '#f9fafb' : '#111827'};
      text-decoration: none;
      font-size: 0.875rem;
      transition: background 0.2s;
    }
    .aethex-widget-link:hover {
      background: ${theme === 'dark' ? '#4b5563' : '#e5e7eb'};
    }
    .aethex-widget-footer {
      margin-top: 16px;
      padding-top: 16px;
      border-top: 1px solid ${theme === 'dark' ? '#374151' : '#e5e7eb'};
      text-align: center;
      font-size: 0.75rem;
      color: ${theme === 'dark' ? '#9ca3af' : '#6b7280'};
    }
    .aethex-widget-footer a {
      color: inherit;
      text-decoration: none;
    }
  \`;

  const styleSheet = document.createElement('style');
  styleSheet.textContent = styles;
  document.head.appendChild(styleSheet);

  const container = document.getElementById('aethex-widget');
  if (!container) return;

  const html = \`
    <div class="aethex-widget">
      <div class="aethex-widget-header">
        <img class="aethex-widget-avatar" src="\${data.user.avatar || 'https://placehold.co/64x64/6366f1/ffffff?text=' + data.user.name.charAt(0)}" alt="\${data.user.name}" />
        <div>
          <h3 class="aethex-widget-name">\${data.user.name}</h3>
          \${data.user.title ? \`<p class="aethex-widget-title">\${data.user.title}</p>\` : ''}
        </div>
      </div>
      \${data.user.bio ? \`<p class="aethex-widget-bio">\${data.user.bio}</p>\` : ''}
      <div class="aethex-widget-links">
        \${data.profile.githubUsername ? \`<a class="aethex-widget-link" href="https://github.com/\${data.profile.githubUsername}" target="_blank">GitHub</a>\` : ''}
        \${data.profile.npmUsername ? \`<a class="aethex-widget-link" href="https://npmjs.com/~\${data.profile.npmUsername}" target="_blank">NPM</a>\` : ''}
        \${data.user.aethexDomain ? \`<a class="aethex-widget-link" href="https://\${data.user.aethexDomain}.aethex.com" target="_blank">Portfolio</a>\` : ''}
      </div>
      <div class="aethex-widget-footer">
        <a href="https://aethex.com/@\${data.user.username}" target="_blank">View full profile on Aethex →</a>
      </div>
    </div>
  \`;

  container.innerHTML = html;
})();
`;

  return new Response(widgetScript, {
    headers: {
      'Content-Type': 'application/javascript',
      'Access-Control-Allow-Origin': '*',
      'Cache-Control': 'public, max-age=3600',
    },
  });
}
