import type { Route } from './+types/premium';
import { Header } from '~/components/header/header';
import { PremiumUpgrade } from '~/components/premium-upgrade/premium-upgrade';
import { useAuth } from '~/hooks/use-auth';
import { useNavigate } from 'react-router';
import { useToast } from '~/hooks/use-toast';
import { 
  Check, 
  X, 
  ArrowRight, 
  Shield, 
  Zap, 
  Users, 
  BarChart, 
  Lock,
  Sparkles,
  ChevronDown,
  Star
} from 'lucide-react';
import { Card } from '~/components/ui/card/card';
import { Badge } from '~/components/ui/badge/badge';
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from '~/components/ui/accordion/accordion';
import { useState } from 'react';
import styles from './premium.module.css';

export function meta({}: Route.MetaArgs) {
  return [
    { title: 'Upgrade to Premium - CreatorHub' },
    { name: 'description', content: 'Unlock premium features for your creator profile' },
  ];
}

const comparisonFeatures = [
  {
    category: 'Platform Connections',
    features: [
      { name: 'GitHub Integration', free: true, pro: true, business: true },
      { name: 'GitLab Integration', free: true, pro: true, business: true },
      { name: 'NPM Integration', free: true, pro: true, business: true },
      { name: 'Platform Limit', free: '3 platforms', pro: 'Unlimited', business: 'Unlimited' },
      { name: 'Auto-sync Frequency', free: 'Daily', pro: 'Hourly', business: 'Real-time' },
      { name: 'Custom Integrations', free: false, pro: false, business: true },
    ],
  },
  {
    category: 'Analytics & Insights',
    features: [
      { name: 'Basic Analytics', free: true, pro: true, business: true },
      { name: 'Advanced Metrics', free: false, pro: true, business: true },
      { name: 'AI Recommendations', free: false, pro: true, business: true },
      { name: 'Career Path Analysis', free: false, pro: true, business: true },
      { name: 'Export Reports', free: false, pro: true, business: true },
      { name: 'API Access', free: false, pro: false, business: true },
    ],
  },
  {
    category: 'Profile & Branding',
    features: [
      { name: 'Public Profile Page', free: true, pro: true, business: true },
      { name: 'Profile Customization', free: 'Basic', pro: 'Advanced', business: 'Advanced' },
      { name: 'Premium .aethex Domain', free: false, pro: true, business: true },
      { name: 'Remove Branding', free: false, pro: true, business: true },
      { name: 'White-label Options', free: false, pro: false, business: true },
      { name: 'Custom CSS/Themes', free: false, pro: true, business: true },
    ],
  },
  {
    category: 'Collaboration & Teams',
    features: [
      { name: 'Individual Account', free: true, pro: true, business: true },
      { name: 'Team Members', free: false, pro: false, business: 'Up to 10' },
      { name: 'Role Management', free: false, pro: false, business: true },
      { name: 'Shared Analytics', free: false, pro: false, business: true },
    ],
  },
  {
    category: 'Support & Security',
    features: [
      { name: 'Community Support', free: true, pro: true, business: true },
      { name: 'Priority Support', free: false, pro: true, business: true },
      { name: 'Dedicated Account Manager', free: false, pro: false, business: true },
      { name: 'SLA Guarantee', free: false, pro: false, business: '99.9%' },
      { name: 'Advanced Security', free: false, pro: false, business: true },
    ],
  },
];

const faqs = [
  {
    question: 'Can I switch plans at any time?',
    answer: 'Yes! You can upgrade or downgrade your plan at any time. When upgrading, you\'ll be charged the prorated amount. When downgrading, the change takes effect at the end of your current billing cycle.',
  },
  {
    question: 'What payment methods do you accept?',
    answer: 'We accept all major credit cards (Visa, MasterCard, American Express, Discover) and PayPal. For Business plans, we also support invoicing and wire transfers.',
  },
  {
    question: 'Is there a free trial for premium plans?',
    answer: 'Yes! All premium plans come with a 14-day free trial. No credit card required to start. You can cancel anytime during the trial period without being charged.',
  },
  {
    question: 'What happens to my data if I downgrade?',
    answer: 'Your data is never deleted. If you downgrade, some premium features will be disabled, but your data remains intact. You can always upgrade again to regain access to all features.',
  },
  {
    question: 'Do you offer refunds?',
    answer: 'Yes, we offer a 14-day money-back guarantee on all plans. If you\'re not satisfied within the first 14 days, contact us for a full refund, no questions asked.',
  },
  {
    question: 'Can I use my own domain with the Pro plan?',
    answer: 'Absolutely! Pro and Business plans include premium .aethex domain support. Your domain is blockchain-verified and owned as an NFT for a fully branded experience.',
  },
  {
    question: 'What\'s the difference between Pro and Business?',
    answer: 'Pro is perfect for individual creators who want advanced features. Business is designed for teams, recruiters, and agencies who need collaboration tools, API access, and enterprise-grade security.',
  },
  {
    question: 'Do you offer discounts for students or nonprofits?',
    answer: 'Yes! We offer special pricing for students and nonprofit organizations. Contact our sales team with proof of eligibility for a custom quote.',
  },
];

const testimonials = [
  {
    name: 'Sarah Chen',
    role: 'Full-Stack Developer',
    avatar: 'https://i.pravatar.cc/150?img=5',
    content: 'The Pro plan has been a game-changer for my career. The AI recommendations helped me land my dream job, and the custom domain makes my profile look incredibly professional.',
    rating: 5,
  },
  {
    name: 'Marcus Johnson',
    role: 'Tech Recruiter',
    avatar: 'https://i.pravatar.cc/150?img=12',
    content: 'The Business plan is worth every penny. Our team can now collaborate seamlessly, and the API access lets us integrate CreatorHub into our existing workflows.',
    rating: 5,
  },
  {
    name: 'Emily Rodriguez',
    role: 'Open Source Contributor',
    avatar: 'https://i.pravatar.cc/150?img=9',
    content: 'I started with the free plan and upgraded to Pro after a month. The analytics insights alone justify the cost. I can see exactly which projects are getting attention.',
    rating: 5,
  },
];

export default function Premium() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);

  const handleUpgrade = async (tierId: string) => {
    if (!user) {
      toast({
        title: 'Authentication Required',
        description: 'Please sign in to upgrade your account.',
        variant: 'destructive',
      });
      navigate('/auth');
      return;
    }

    toast({
      title: 'Redirecting to checkout...',
      description: `Processing upgrade to ${tierId} plan`,
    });

    setTimeout(() => {
      toast({
        title: 'Upgrade Successful!',
        description: 'Welcome to premium! All features are now unlocked.',
        variant: 'default',
      });
      navigate('/dashboard');
    }, 2000);
  };

  const renderFeatureValue = (value: string | boolean) => {
    if (typeof value === 'boolean') {
      return value ? (
        <Check className={styles.checkIcon} />
      ) : (
        <X className={styles.xIcon} />
      );
    }
    return <span className={styles.featureText}>{value}</span>;
  };

  return (
    <div className={styles.page}>
      <Header isAuthenticated={!!user} />
      
      <div className={styles.container}>
        {/* Hero Section */}
        <div className={styles.hero}>
          <Badge variant="outline" className={styles.heroBadge}>
            <Sparkles className={styles.badgeIcon} />
            Premium Plans
          </Badge>
          <h1 className={styles.heroTitle}>Supercharge Your Creator Profile</h1>
          <p className={styles.heroDescription}>
            Unlock powerful features, advanced analytics, and exclusive tools to grow your presence
            and accelerate your career.
          </p>
        </div>

        {/* Pricing Cards */}
        <PremiumUpgrade onUpgrade={handleUpgrade} currentTier={user ? 'free' : undefined} />

        {/* Feature Highlights */}
        <div className={styles.featureHighlights}>
          <h2 className={styles.sectionTitle}>Why Go Premium?</h2>
          <div className={styles.highlightGrid}>
            <Card className={styles.highlightCard}>
              <div className={styles.highlightIcon}>
                <Zap />
              </div>
              <h3 className={styles.highlightTitle}>Advanced Analytics</h3>
              <p className={styles.highlightDescription}>
                Get deep insights into your profile performance, track engagement, and understand what resonates with your audience.
              </p>
            </Card>

            <Card className={styles.highlightCard}>
              <div className={styles.highlightIcon}>
                <Shield />
              </div>
              <h3 className={styles.highlightTitle}>Custom Branding</h3>
              <p className={styles.highlightDescription}>
                Connect your own domain, remove CreatorHub branding, and create a fully personalized professional presence.
              </p>
            </Card>

            <Card className={styles.highlightCard}>
              <div className={styles.highlightIcon}>
                <BarChart />
              </div>
              <h3 className={styles.highlightTitle}>AI-Powered Insights</h3>
              <p className={styles.highlightDescription}>
                Leverage machine learning to get personalized career recommendations and identify growth opportunities.
              </p>
            </Card>

            <Card className={styles.highlightCard}>
              <div className={styles.highlightIcon}>
                <Users />
              </div>
              <h3 className={styles.highlightTitle}>Team Collaboration</h3>
              <p className={styles.highlightDescription}>
                Work with your team, manage roles, and collaborate on projects with Business plan's team features.
              </p>
            </Card>

            <Card className={styles.highlightCard}>
              <div className={styles.highlightIcon}>
                <Lock />
              </div>
              <h3 className={styles.highlightTitle}>Priority Support</h3>
              <p className={styles.highlightDescription}>
                Get help when you need it with priority email support and dedicated account management for Business.
              </p>
            </Card>

            <Card className={styles.highlightCard}>
              <div className={styles.highlightIcon}>
                <ArrowRight />
              </div>
              <h3 className={styles.highlightTitle}>Early Access</h3>
              <p className={styles.highlightDescription}>
                Be the first to try new features and integrations before they're available to free users.
              </p>
            </Card>
          </div>
        </div>

        {/* Detailed Comparison Table */}
        <div className={styles.comparisonSection}>
          <h2 className={styles.sectionTitle}>Compare Plans in Detail</h2>
          <p className={styles.sectionDescription}>
            See exactly what's included in each plan
          </p>

          <div className={styles.comparisonTable}>
            <div className={styles.tableHeader}>
              <div className={styles.featureColumn}>Features</div>
              <div className={styles.planColumn}>Free</div>
              <div className={styles.planColumn}>
                Pro
                <Badge variant="default" className={styles.popularBadge}>Popular</Badge>
              </div>
              <div className={styles.planColumn}>Business</div>
            </div>

            {comparisonFeatures.map((category) => (
              <div key={category.category} className={styles.categoryGroup}>
                <div className={styles.categoryHeader}>
                  <h3 className={styles.categoryTitle}>{category.category}</h3>
                </div>
                {category.features.map((feature, idx) => (
                  <div key={idx} className={styles.featureRow}>
                    <div className={styles.featureColumn}>{feature.name}</div>
                    <div className={styles.planColumn}>{renderFeatureValue(feature.free)}</div>
                    <div className={styles.planColumn}>{renderFeatureValue(feature.pro)}</div>
                    <div className={styles.planColumn}>{renderFeatureValue(feature.business)}</div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>

        {/* Testimonials */}
        <div className={styles.testimonialsSection}>
          <h2 className={styles.sectionTitle}>Loved by Creators & Teams</h2>
          <div className={styles.testimonialGrid}>
            {testimonials.map((testimonial, idx) => (
              <Card key={idx} className={styles.testimonialCard}>
                <div className={styles.testimonialHeader}>
                  <img src={testimonial.avatar} alt={testimonial.name} className={styles.avatar} />
                  <div className={styles.testimonialInfo}>
                    <div className={styles.testimonialName}>{testimonial.name}</div>
                    <div className={styles.testimonialRole}>{testimonial.role}</div>
                  </div>
                  <div className={styles.rating}>
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className={styles.starIcon} />
                    ))}
                  </div>
                </div>
                <p className={styles.testimonialContent}>{testimonial.content}</p>
              </Card>
            ))}
          </div>
        </div>

        {/* FAQ */}
        <div className={styles.faqSection}>
          <h2 className={styles.sectionTitle}>Frequently Asked Questions</h2>
          <Accordion type="single" collapsible className={styles.faqAccordion}>
            {faqs.map((faq, idx) => (
              <AccordionItem key={idx} value={`faq-${idx}`}>
                <AccordionTrigger className={styles.faqQuestion}>
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className={styles.faqAnswer}>
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        {/* CTA Section */}
        <div className={styles.ctaSection}>
          <Card className={styles.ctaCard}>
            <h2 className={styles.ctaTitle}>Ready to unlock your full potential?</h2>
            <p className={styles.ctaDescription}>
              Join thousands of creators who have already upgraded to premium.
              Start your 14-day free trial today.
            </p>
            <div className={styles.ctaButtons}>
              <button 
                className={styles.ctaPrimary}
                onClick={() => handleUpgrade('pro')}
              >
                Start Free Trial
                <ArrowRight className={styles.ctaIcon} />
              </button>
              <button className={styles.ctaSecondary}>
                Contact Sales
              </button>
            </div>
            <p className={styles.ctaFootnote}>
              No credit card required • Cancel anytime • 14-day money-back guarantee
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
