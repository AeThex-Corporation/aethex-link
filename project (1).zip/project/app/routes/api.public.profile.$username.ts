import type { Route } from './+types/api.public.profile.$username';
import { db } from '~/lib/db.server';

/**
 * Public API endpoint for retrieving user profiles
 * This can be used by third-party applications
 */
export async function loader({ params, request }: Route.LoaderArgs) {
  try {
    const { username } = params;
    const apiKey = request.headers.get('X-API-Key');

    // Validate API key if provided
    if (apiKey) {
      const key = await db.apiKey.findByKey(apiKey);
      if (key) {
        await db.apiKey.updateLastUsed(apiKey);
        
        // Check permissions
        if (!key.permissions.includes('profile:read')) {
          return Response.json(
            { error: 'Insufficient permissions' },
            { status: 403 }
          );
        }

        // Check expiry
        if (key.expiresAt && key.expiresAt < new Date()) {
          return Response.json(
            { error: 'API key expired' },
            { status: 401 }
          );
        }
      }
    }

    // Get user by username
    const user = await db.user.findByUsername(username);
    
    if (!user) {
      return Response.json({ error: 'User not found' }, { status: 404 });
    }

    // Get profile
    const profile = await db.profile.findByUserId(user.id);
    
    // Get portfolio items
    const portfolio = await db.portfolio.findByUserId(user.id);

    // Public profile data
    const publicProfile = {
      id: user.id,
      username: user.username,
      name: user.name,
      bio: user.bio,
      avatar: user.avatar,
      location: user.location,
      title: user.title,
      aethexDomain: user.aethexDomain,
      platforms: {
        github: profile?.githubUsername,
        stackoverflow: profile?.stackOverflowId,
        npm: profile?.npmUsername,
        pypi: profile?.pypiUsername,
        gitlab: profile?.gitlabUsername,
        devto: profile?.devtoUsername,
        medium: profile?.mediumUsername,
        roblox: profile?.robloxUsername,
        unity: profile?.unityPublisherId,
        huggingface: profile?.huggingFaceUsername,
        kaggle: profile?.kaggleUsername,
      },
      portfolio: portfolio.map(item => ({
        id: item.id,
        type: item.type,
        title: item.title,
        description: item.description,
        platform: item.platform,
        url: item.url,
        thumbnailUrl: item.thumbnailUrl,
        tags: item.tags,
        stats: item.stats,
      })),
    };

    return Response.json(
      { profile: publicProfile },
      {
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET',
          'Access-Control-Allow-Headers': 'X-API-Key',
        },
      }
    );
  } catch (error: any) {
    return Response.json(
      { error: error.message || 'Failed to fetch profile' },
      { status: 500 }
    );
  }
}

// Handle CORS preflight
export async function options() {
  return new Response(null, {
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET',
      'Access-Control-Allow-Headers': 'X-API-Key',
    },
  });
}
