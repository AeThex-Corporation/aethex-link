import type { Route } from './+types/api.auth.me';
import { getUserId } from '~/lib/session.server';
import { db } from '~/lib/db.server';
import { auth } from '~/lib/auth.server';

export async function loader({ request }: Route.LoaderArgs) {
  try {
    // Check session first
    const userId = await getUserId(request);
    if (userId) {
      const user = await db.user.findById(userId);
      if (user) {
        return Response.json({ user: auth.sanitizeUser(user) });
      }
    }

    // Fallback to token-based auth
    const user = await auth.getOptionalUser(request);
    if (user) {
      return Response.json({ user });
    }

    return Response.json(
      { error: 'Unauthorized' },
      { status: 401 }
    );
  } catch (error) {
    return Response.json(
      { error: 'Unauthorized' },
      { status: 401 }
    );
  }
}
