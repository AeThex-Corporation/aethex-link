import type { Route } from './+types/marketplace';
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '~/components/ui/card/card';
import { Button } from '~/components/ui/button/button';
import { Input } from '~/components/ui/input/input';
import { Badge } from '~/components/ui/badge/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '~/components/ui/dialog/dialog';
import { Label } from '~/components/ui/label/label';
import { Textarea } from '~/components/ui/textarea/textarea';
import { useToast } from '~/hooks/use-toast';
import { api } from '~/lib/api.client';
import { Store, Search, DollarSign, Calendar, User } from 'lucide-react';
import styles from './marketplace.module.css';

export default function Marketplace({}: Route.ComponentProps) {
  const [listings, setListings] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    loadListings();
  }, []);

  const loadListings = async () => {
    try {
      const response = await fetch('/api/marketplace');
      const data = await response.json();
      setListings(data.listings || []);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load marketplace listings',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const buyDomain = async (listingId: string) => {
    try {
      await api.request('/api/marketplace', {
        method: 'POST',
        body: JSON.stringify({ action: 'buy', listingId }),
      });

      toast({
        title: 'Success',
        description: 'Domain purchased successfully!',
      });

      loadListings();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to purchase domain',
        variant: 'destructive',
      });
    }
  };

  const filteredListings = listings.filter(listing =>
    listing.domain.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <div className={styles.headerContent}>
          <div className={styles.headerText}>
            <h1 className={styles.title}>
              <Store size={32} />
              Domain Marketplace
            </h1>
            <p className={styles.subtitle}>
              Buy and sell .aethex domains from the community
            </p>
          </div>

          <ListDomainDialog onSuccess={loadListings} />
        </div>

        <div className={styles.searchBar}>
          <Search size={20} />
          <Input
            type="text"
            placeholder="Search domains..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={styles.searchInput}
          />
        </div>
      </div>

      <div className={styles.content}>
        {loading ? (
          <div className={styles.loading}>Loading listings...</div>
        ) : filteredListings.length === 0 ? (
          <Card>
            <CardContent className={styles.empty}>
              <Store size={48} />
              <p>No domains listed for sale</p>
            </CardContent>
          </Card>
        ) : (
          <div className={styles.listings}>
            {filteredListings.map(listing => (
              <Card key={listing.id} className={styles.listingCard}>
                <CardHeader>
                  <div className={styles.cardHeader}>
                    <CardTitle className={styles.domain}>
                      {listing.domain}.aethex
                    </CardTitle>
                    <Badge variant="outline">For Sale</Badge>
                  </div>
                  {listing.description && (
                    <CardDescription>{listing.description}</CardDescription>
                  )}
                </CardHeader>
                <CardContent>
                  <div className={styles.listingDetails}>
                    <div className={styles.price}>
                      <DollarSign size={20} />
                      <span className={styles.priceAmount}>
                        {listing.price.toLocaleString()} {listing.currency}
                      </span>
                    </div>

                    <div className={styles.seller}>
                      <User size={16} />
                      <span>Seller: @{listing.seller?.username}</span>
                    </div>

                    <div className={styles.date}>
                      <Calendar size={16} />
                      <span>Listed {new Date(listing.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>

                  <Button 
                    onClick={() => buyDomain(listing.id)}
                    className={styles.buyButton}
                  >
                    Buy Domain
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ListDomainDialog({ onSuccess }: { onSuccess: () => void }) {
  const [open, setOpen] = useState(false);
  const [domain, setDomain] = useState('');
  const [price, setPrice] = useState('');
  const [description, setDescription] = useState('');
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      await api.request('/api/marketplace', {
        method: 'POST',
        body: JSON.stringify({
          action: 'create',
          domain,
          price: parseFloat(price),
          description,
        }),
      });

      toast({
        title: 'Success',
        description: 'Domain listed for sale!',
      });

      setOpen(false);
      setDomain('');
      setPrice('');
      setDescription('');
      onSuccess();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to list domain',
        variant: 'destructive',
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>List Your Domain</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>List Domain for Sale</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className={styles.form}>
          <div className={styles.formField}>
            <Label htmlFor="domain">Domain Name</Label>
            <Input
              id="domain"
              value={domain}
              onChange={(e) => setDomain(e.target.value)}
              placeholder="yourdomain"
              required
            />
            <span className={styles.domainSuffix}>.aethex</span>
          </div>

          <div className={styles.formField}>
            <Label htmlFor="price">Price (USD)</Label>
            <Input
              id="price"
              type="number"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="1000"
              required
            />
          </div>

          <div className={styles.formField}>
            <Label htmlFor="description">Description (Optional)</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Why is this domain valuable?"
              rows={3}
            />
          </div>

          <Button type="submit">List Domain</Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
