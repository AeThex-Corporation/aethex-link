import type { Route } from './+types/api.profile.$userId';
import { aggregation } from '~/lib/aggregation.server';
import { db } from '~/lib/db.server';
import { analytics } from '~/lib/analytics.server';

export async function loader({ params, request }: Route.LoaderArgs) {
  try {
    const { userId } = params;

    // Get user
    const user = await db.user.findById(userId);
    if (!user) {
      return Response.json({ error: 'User not found' }, { status: 404 });
    }

    // Get aggregated profile
    const profile = await aggregation.syncAllPlatforms(userId);

    // Track profile view
    const viewerToken = request.headers.get('Authorization')?.split(' ')[1];
    
    await analytics.trackEvent(userId, 'profile_view', {
      viewerId: viewerToken ? 'authenticated-user' : 'anonymous',
      timestamp: new Date().toISOString(),
    });

    return Response.json({
      user: {
        id: user.id,
        name: user.name,
        username: user.username,
        avatar: user.avatar,
        bio: user.bio,
        location: user.location,
        title: user.title,
      },
      profile,
    });
  } catch (error: any) {
    console.error('Profile fetch error:', error);
    return Response.json(
      { error: error.message || 'Failed to fetch profile' },
      { status: 500 }
    );
  }
}
