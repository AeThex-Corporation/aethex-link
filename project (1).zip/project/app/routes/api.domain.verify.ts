import type { ActionFunctionArgs } from 'react-router';
import { auth } from '~/lib/auth.server';
import { db } from '~/lib/db.server';
import { freenameAPI } from '~/lib/freename.server';

/**
 * Verify domain ownership on blockchain
 * POST /api/domain/verify
 */
export async function action({ request }: ActionFunctionArgs) {
  // Require authentication
  const user = await auth.requireAuth(request);

  try {
    // Get user's domain
    const domainRecord = await db.domain.findByUserId(user.id);
    if (!domainRecord) {
      return Response.json({ error: 'No domain found for user' }, { status: 404 });
    }

    // Verify ownership via Freename API
    const verified = await freenameAPI.verifyOwnership(
      domainRecord.domain,
      user.id
    );

    // Update user verification status
    await db.user.update(user.id, {
      aethexDomainVerified: verified,
    });

    // Update domain status
    if (verified) {
      await db.domain.update(domainRecord.domain, {
        status: 'active',
      });
    }

    return Response.json({
      success: true,
      verified,
      domain: domainRecord.domain,
    });
  } catch (error: any) {
    console.error('Domain verification failed:', error);
    return Response.json({
      error: error.message || 'Failed to verify domain',
    }, { status: 500 });
  }
}
