import { useState } from "react";
import type { Route } from "./+types/auth";
import { Header } from "~/components/header/header";
import { Button } from "~/components/ui/button/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "~/components/ui/tabs/tabs";
import { Input } from "~/components/ui/input/input";
import { Label } from "~/components/ui/label/label";
import { useToast } from "~/hooks/use-toast";
import { useAuth } from "~/hooks/use-auth";
import styles from "./auth.module.css";

export function meta({}: Route.MetaArgs) {
  return [
    { title: "Sign In - AethexLink" },
    { name: "description", content: "Sign in or create your AethexLink account" },
  ];
}

export default function Auth() {
  const { toast } = useToast();
  const { login, register } = useAuth();
  const [isLoading, setIsLoading] = useState(false);

  const handleSignUp = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);

    const formData = new FormData(e.currentTarget);
    const name = formData.get('name') as string;
    const email = formData.get('email') as string;
    const password = formData.get('password') as string;
    const username = email.split('@')[0]; // Generate username from email

    try {
      await register(email, password, name, username);
      toast({
        title: "Account created successfully!",
        description: "Welcome to DevHub. Redirecting to your dashboard...",
        variant: "default",
      });
    } catch (error: any) {
      toast({
        title: "Registration failed",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);

    const formData = new FormData(e.currentTarget);
    const email = formData.get('email') as string;
    const password = formData.get('password') as string;

    try {
      await login(email, password);
      toast({
        title: "Login successful!",
        description: "Welcome back to DevHub.",
        variant: "default",
      });
    } catch (error: any) {
      toast({
        title: "Login failed",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className={styles.page}>
      <Header isAuthenticated={false} />

      <div className={styles.container}>
        <div className={styles.card}>
          <div className={styles.header}>
            <h1 className={styles.title}>Welcome to DevHub</h1>
            <p className={styles.description}>Sign in to build your verified developer profile</p>
          </div>

          <Tabs defaultValue="login" className={styles.tabs}>
            <TabsList>
              <TabsTrigger value="login">Log In</TabsTrigger>
              <TabsTrigger value="signup">Sign Up</TabsTrigger>
            </TabsList>

            <TabsContent value="login">
              <form onSubmit={handleLogin} className={styles.form}>
                <div className={styles.formField}>
                  <Label htmlFor="login-email">Email</Label>
                  <Input
                    id="login-email"
                    name="email"
                    type="email"
                    placeholder="developer@example.com"
                    required
                    className={styles.input}
                  />
                </div>

                <div className={styles.formField}>
                  <Label htmlFor="login-password">Password</Label>
                  <Input id="login-password" name="password" type="password" placeholder="••••••••" required className={styles.input} />
                </div>

                <Button type="submit" className={styles.submitButton} disabled={isLoading}>
                  {isLoading ? "Logging in..." : "Log In"}
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="signup">
              <form onSubmit={handleSignUp} className={styles.form}>
                <div className={styles.formField}>
                  <Label htmlFor="signup-name">Full Name</Label>
                  <Input id="signup-name" name="name" type="text" placeholder="Alex Developer" required className={styles.input} />
                </div>

                <div className={styles.formField}>
                  <Label htmlFor="signup-email">Email</Label>
                  <Input
                    id="signup-email"
                    name="email"
                    type="email"
                    placeholder="developer@example.com"
                    required
                    className={styles.input}
                  />
                </div>

                <div className={styles.formField}>
                  <Label htmlFor="signup-password">Password</Label>
                  <Input
                    id="signup-password"
                    name="password"
                    type="password"
                    placeholder="••••••••"
                    required
                    minLength={6}
                    className={styles.input}
                  />
                </div>

                <Button type="submit" className={styles.submitButton} disabled={isLoading}>
                  {isLoading ? "Creating account..." : "Sign Up"}
                </Button>
              </form>
            </TabsContent>
          </Tabs>

          <div className={styles.footer}>
            By continuing, you agree to our{" "}
            <a href="#" className={styles.footerLink}>
              Terms of Service
            </a>{" "}
            and{" "}
            <a href="#" className={styles.footerLink}>
              Privacy Policy
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
