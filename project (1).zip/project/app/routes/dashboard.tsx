import { 
  TrendingUp, 
  Users, 
  Search, 
  GitBranch,
  Award,
  Activity,
  Code2,
  MessageSquare,
  Star,
  ExternalLink,
  Check,
  Download,
  Share2,
  Eye,
  BarChart3,
  Gamepad2,
  Brain,
  Globe,
  Shield
} from "lucide-react";
import { SiGithub, SiX } from '@icons-pack/react-simple-icons';
import { Header } from "~/components/header/header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "~/components/ui/card/card";
import { Badge } from "~/components/ui/badge/badge";
import { Button } from "~/components/ui/button/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "~/components/ui/tabs/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "~/components/ui/avatar/avatar";
import { Progress } from "~/components/ui/progress/progress";
import { EmbedWidget } from "~/components/ui/embed-widget/embed-widget";
import { DomainRegistration } from "~/components/domain-registration/domain-registration";
import { DomainManager } from "~/components/domain-manager/domain-manager";
import { ProfileSyncDialog } from "~/components/profile-sync-dialog/profile-sync-dialog";
import { RevenueDashboard } from "~/components/revenue-dashboard/revenue-dashboard";
import {
  mockProfileViews,
  mockSkillGrowth,
  mockSourceBreakdown,
  mockNetworkGrowth,
  mockRecruiterViews,
  exportAllAnalytics,
} from "~/data/mock-analytics";
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import styles from "./dashboard.module.css";

export function meta() {
  return [
    { title: "Dashboard - CreatorHub" },
    { name: "description", content: "Your multi-platform creator dashboard with verified credentials across game dev, AI, and software development" },
  ];
}

// Mock data
const mockUser = {
  name: "Alex Rivera",
  username: "alexrivera",
  avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop",
  title: "Game Developer & AI Engineer",
  location: "San Francisco, CA",
  verified: true,
  domainTier: 'free' as 'free' | 'premium',
  aethexDomain: null, // null means no domain registered yet
  categories: ["Game Dev", "AI", "Software Dev"],
  stats: {
    // Game Dev Stats
    robloxGames: 12,
    totalGameVisits: 2400000,
    unityProjects: 8,
    // AI Stats
    huggingFaceModels: 15,
    kaggleMedals: 3,
    // Software Dev Stats
    repos: 127,
    commits: 8432,
    pullRequests: 342,
    followers: 1245,
    ranking: "Top 5%"
  }
};

const skills = [
  // Game Dev Skills
  { name: "Roblox Lua", level: 95, verified: true, category: "Game Dev" },
  { name: "Unity C#", level: 92, verified: true, category: "Game Dev" },
  { name: "Unreal C++", level: 88, verified: true, category: "Game Dev" },
  { name: "Game Design", level: 90, verified: true, category: "Game Dev" },
  // AI Skills
  { name: "PyTorch", level: 93, verified: true, category: "AI" },
  { name: "TensorFlow", level: 89, verified: true, category: "AI" },
  { name: "Transformers", level: 87, verified: true, category: "AI" },
  // Software Dev Skills
  { name: "TypeScript", level: 95, verified: true, category: "Software Dev" },
  { name: "React", level: 92, verified: true, category: "Software Dev" },
  { name: "Node.js", level: 88, verified: true, category: "Software Dev" }
];

const recentActivity = [
  { type: "game", platform: "Roblox", message: "'Obby Challenge' reached 100K visits", time: "2 hours ago", icon: Gamepad2, category: "Game Dev" },
  { type: "model", platform: "Hugging Face", message: "Published 'sentiment-analyzer-v2' model", time: "5 hours ago", icon: Brain, category: "AI" },
  { type: "commit", repo: "unity-toolkit/core", message: "Add multiplayer networking system", time: "1 day ago", icon: GitBranch, category: "Game Dev" },
  { type: "competition", platform: "Kaggle", message: "Bronze medal in NLP competition", time: "2 days ago", icon: Award, category: "AI" },
  { type: "pr", repo: "react-toolkit/core", message: "Fix TypeScript generics in hooks", time: "3 days ago", icon: Code2, category: "Software Dev" },
  { type: "answer", platform: "Stack Overflow", message: "Answered: React Server Components", time: "4 days ago", icon: MessageSquare, category: "Software Dev" }
];

const achievements = [
  { title: "Roblox Creator", description: "1M+ total game visits", icon: Gamepad2, earned: true, category: "Game Dev" },
  { title: "Unity Developer", description: "Published 5+ games", icon: Gamepad2, earned: true, category: "Game Dev" },
  { title: "AI Researcher", description: "10+ models on Hugging Face", icon: Brain, earned: true, category: "AI" },
  { title: "Kaggle Expert", description: "3+ competition medals", icon: Award, earned: true, category: "AI" },
  { title: "Open Source Champion", description: "100+ merged PRs", icon: Code2, earned: true, category: "Software Dev" },
  { title: "Stack Overflow Contributor", description: "500+ reputation points", icon: MessageSquare, earned: true, category: "Software Dev" }
];

const suggestedConnections = [
  {
    name: "Jordan Chen",
    title: "Backend Engineer",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop",
    match: 92,
    commonSkills: ["TypeScript", "Node.js", "GraphQL"]
  },
  {
    name: "Sam Patel",
    title: "DevOps Engineer",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop",
    match: 88,
    commonSkills: ["Docker", "PostgreSQL"]
  },
  {
    name: "Taylor Kim",
    title: "Frontend Architect",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop",
    match: 85,
    commonSkills: ["React", "TypeScript"]
  }
];

const projects = [
  {
    name: "devhub/platform",
    description: "Developer verification and networking platform",
    stars: 1240,
    language: "TypeScript",
    contributions: 234,
    role: "Core Maintainer"
  },
  {
    name: "react-toolkit/core",
    description: "Modern React hooks and utilities library",
    stars: 8500,
    language: "TypeScript",
    contributions: 45,
    role: "Contributor"
  },
  {
    name: "awesome-dev-tools",
    description: "Curated list of developer productivity tools",
    stars: 12400,
    language: "Markdown",
    contributions: 12,
    role: "Contributor"
  }
];

const COLORS = {
  github: 'var(--color-accent-9)',
  stackoverflow: 'var(--color-success-9)',
  blog: 'var(--color-secondary-9)',
  npm: 'var(--color-neutral-9)'
};

// Mock revenue data
const mockRevenue = {
  totalRevenue: 45000,
  currency: 'USD',
  sources: [
    {
      platform: 'Roblox',
      revenue: 25000,
      breakdown: [
        { name: 'Obby Challenge', amount: 15000 },
        { name: 'Racing Simulator', amount: 7000 },
        { name: 'Adventure Quest', amount: 3000 }
      ]
    },
    {
      platform: 'Unity Asset Store',
      revenue: 12000,
      breakdown: [
        { name: 'Multiplayer Toolkit', amount: 8000 },
        { name: 'UI Framework', amount: 4000 }
      ]
    },
    {
      platform: 'Hugging Face',
      revenue: 5000,
      breakdown: [
        { name: 'Model Downloads', amount: 3000 },
        { name: 'Sponsorships', amount: 2000 }
      ]
    },
    {
      platform: 'GitHub Sponsors',
      revenue: 3000
    }
  ],
  monthlyTrend: [
    { month: 'Jan', revenue: 2500 },
    { month: 'Feb', revenue: 3200 },
    { month: 'Mar', revenue: 4100 },
    { month: 'Apr', revenue: 5500 },
    { month: 'May', revenue: 6200 },
    { month: 'Jun', revenue: 7500 },
    { month: 'Jul', revenue: 8000 },
    { month: 'Aug', revenue: 8500 }
  ],
  topEarningPlatform: 'Roblox',
  yearToDateRevenue: 45000,
  projectedAnnualRevenue: 67500
};

const mockMilestones = [
  {
    milestone: 'First $1,000',
    achieved: true,
    progress: 100
  },
  {
    milestone: 'Reach $10,000',
    achieved: true,
    progress: 100
  },
  {
    milestone: 'Reach $50,000',
    achieved: false,
    progress: 90
  },
  {
    milestone: 'Reach $100,000',
    achieved: false,
    progress: 45
  }
];

export default function Dashboard() {
  return (
    <div className={styles.page}>
      <Header isAuthenticated={true} />

      <div className={styles.container}>
        {/* Profile Header */}
        <div className={styles.profileHeader}>
          <div className={styles.profileInfo}>
            <Avatar className={styles.avatar}>
              <AvatarImage src={mockUser.avatar} alt={mockUser.name} />
              <AvatarFallback>{mockUser.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
            </Avatar>
            <div className={styles.profileDetails}>
              <div className={styles.nameRow}>
                <h1 className={styles.profileName}>{mockUser.name}</h1>
                {mockUser.verified && (
                  <Badge variant="default" className={styles.verifiedBadge}>
                    <Check size={14} />
                    Verified
                  </Badge>
                )}
              </div>
              <p className={styles.profileTitle}>{mockUser.title}</p>
              <p className={styles.profileLocation}>{mockUser.location}</p>
            </div>
          </div>
          <div className={styles.profileActions}>
            <ProfileSyncDialog />
            {!mockUser.aethexDomain ? (
              <DomainRegistration onSuccess={() => window.location.reload()} />
            ) : (
              <Button variant="outline" className={styles.domainButton}>
                <Globe size={18} />
                {mockUser.username}.aethex
              </Button>
            )}
            <Button variant="outline">
              <SiGithub size={18} />
              View on GitHub
            </Button>
            <Button>Edit Profile</Button>
          </div>
        </div>

        {/* Category Badges */}
        <div className={styles.categoryBadges}>
          {mockUser.categories.map((category) => (
            <Badge key={category} variant="secondary" className={styles.categoryBadge}>
              {category === "Game Dev" && <Gamepad2 size={14} />}
              {category === "AI" && <Brain size={14} />}
              {category === "Software Dev" && <Code2 size={14} />}
              {category}
            </Badge>
          ))}
        </div>

        {/* Stats Overview */}
        <div className={styles.statsGrid}>
          <Card>
            <CardHeader>
              <CardTitle className={styles.statCardTitle}>
                <Gamepad2 size={18} />
                Roblox Games
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className={styles.statValue}>{mockUser.stats.robloxGames}</div>
              <div className={styles.statLabel}>{mockUser.stats.totalGameVisits.toLocaleString()} total visits</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className={styles.statCardTitle}>
                <Gamepad2 size={18} />
                Unity Projects
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className={styles.statValue}>{mockUser.stats.unityProjects}</div>
              <div className={styles.statLabel}>Published games</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className={styles.statCardTitle}>
                <Brain size={18} />
                AI Models
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className={styles.statValue}>{mockUser.stats.huggingFaceModels}</div>
              <div className={styles.statLabel}>{mockUser.stats.kaggleMedals} Kaggle medals</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className={styles.statCardTitle}>
                <Code2 size={18} />
                GitHub Repos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className={styles.statValue}>{mockUser.stats.repos}</div>
              <div className={styles.statLabel}>{mockUser.stats.commits.toLocaleString()} commits</div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="overview" className={styles.tabs}>
          <TabsList>
            <TabsTrigger value="overview">
              <Activity size={16} />
              Overview
            </TabsTrigger>
            <TabsTrigger value="projects">
              <GitBranch size={16} />
              Projects
            </TabsTrigger>
            <TabsTrigger value="analytics">
              <BarChart3 size={16} />
              Analytics
            </TabsTrigger>
            <TabsTrigger value="network">
              <Users size={16} />
              Network
            </TabsTrigger>
            <TabsTrigger value="share">
              <Share2 size={16} />
              Share
            </TabsTrigger>
            <TabsTrigger value="domain">
              <Globe size={16} />
              Domain
            </TabsTrigger>
            <TabsTrigger value="revenue">
              <TrendingUp size={16} />
              Revenue
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className={styles.tabContent}>
            <div className={styles.overviewGrid}>
              {/* Skills */}
              <Card className={styles.skillsCard}>
                <CardHeader>
                  <CardTitle>Verified Skills</CardTitle>
                  <CardDescription>Skills verified across all platforms</CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="all" className={styles.skillsTabs}>
                    <TabsList className={styles.skillsTabsList}>
                      <TabsTrigger value="all">All</TabsTrigger>
                      <TabsTrigger value="gamedev">Game Dev</TabsTrigger>
                      <TabsTrigger value="ai">AI</TabsTrigger>
                      <TabsTrigger value="softwaredev">Software Dev</TabsTrigger>
                    </TabsList>
                    <TabsContent value="all">
                      <div className={styles.skillsList}>
                        {skills.slice(0, 6).map((skill) => (
                          <div key={skill.name} className={styles.skillItem}>
                            <div className={styles.skillHeader}>
                              <span className={styles.skillName}>
                                {skill.name}
                                <Badge variant="outline" className={styles.skillCategoryBadge}>
                                  {skill.category}
                                </Badge>
                              </span>
                              <span className={styles.skillLevel}>{skill.level}%</span>
                            </div>
                            <Progress value={skill.level} className={styles.skillProgress} />
                          </div>
                        ))}
                      </div>
                    </TabsContent>
                    <TabsContent value="gamedev">
                      <div className={styles.skillsList}>
                        {skills.filter(s => s.category === "Game Dev").map((skill) => (
                          <div key={skill.name} className={styles.skillItem}>
                            <div className={styles.skillHeader}>
                              <span className={styles.skillName}>{skill.name}</span>
                              <span className={styles.skillLevel}>{skill.level}%</span>
                            </div>
                            <Progress value={skill.level} className={styles.skillProgress} />
                          </div>
                        ))}
                      </div>
                    </TabsContent>
                    <TabsContent value="ai">
                      <div className={styles.skillsList}>
                        {skills.filter(s => s.category === "AI").map((skill) => (
                          <div key={skill.name} className={styles.skillItem}>
                            <div className={styles.skillHeader}>
                              <span className={styles.skillName}>{skill.name}</span>
                              <span className={styles.skillLevel}>{skill.level}%</span>
                            </div>
                            <Progress value={skill.level} className={styles.skillProgress} />
                          </div>
                        ))}
                      </div>
                    </TabsContent>
                    <TabsContent value="softwaredev">
                      <div className={styles.skillsList}>
                        {skills.filter(s => s.category === "Software Dev").map((skill) => (
                          <div key={skill.name} className={styles.skillItem}>
                            <div className={styles.skillHeader}>
                              <span className={styles.skillName}>{skill.name}</span>
                              <span className={styles.skillLevel}>{skill.level}%</span>
                            </div>
                            <Progress value={skill.level} className={styles.skillProgress} />
                          </div>
                        ))}
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>

              {/* Recent Activity */}
              <Card className={styles.activityCard}>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>Your latest contributions across platforms</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className={styles.activityList}>
                    {recentActivity.map((activity, index) => (
                      <div key={index} className={styles.activityItem}>
                        <div className={styles.activityIcon}>
                          <activity.icon size={16} />
                        </div>
                        <div className={styles.activityContent}>
                          <p className={styles.activityMessage}>{activity.message}</p>
                          <p className={styles.activityMeta}>
                            <span className={styles.activityRepo}>{activity.repo}</span>
                            <span className={styles.activityTime}>{activity.time}</span>
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Achievements */}
              <Card className={styles.achievementsCard}>
                <CardHeader>
                  <CardTitle>Achievements</CardTitle>
                  <CardDescription>Verified milestones and badges</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className={styles.achievementsGrid}>
                    {achievements.map((achievement, index) => (
                      <div 
                        key={index} 
                        className={`${styles.achievementItem} ${achievement.earned ? styles.achievementEarned : styles.achievementLocked}`}
                      >
                        <achievement.icon size={24} />
                        <h4 className={styles.achievementTitle}>{achievement.title}</h4>
                        <p className={styles.achievementDescription}>{achievement.description}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="projects" className={styles.tabContent}>
            <div className={styles.projectsGrid}>
              {projects.map((project, index) => (
                <Card key={index} className={styles.projectCard}>
                  <CardHeader>
                    <div className={styles.projectHeader}>
                      <CardTitle>{project.name}</CardTitle>
                      <ExternalLink size={18} className={styles.projectLink} />
                    </div>
                    <CardDescription>{project.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className={styles.projectMeta}>
                      <div className={styles.projectMetaItem}>
                        <Star size={16} />
                        <span>{project.stars.toLocaleString()}</span>
                      </div>
                      <div className={styles.projectMetaItem}>
                        <Code2 size={16} />
                        <span>{project.language}</span>
                      </div>
                      <div className={styles.projectMetaItem}>
                        <GitBranch size={16} />
                        <span>{project.contributions} contributions</span>
                      </div>
                    </div>
                    <Badge className={styles.projectRole}>{project.role}</Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className={styles.tabContent}>
            <div className={styles.analyticsGrid}>
              {/* Profile Views Chart */}
              <Card className={styles.chartCard}>
                <div className={styles.chartHeader}>
                  <div>
                    <h3>Profile Views</h3>
                    <p className={styles.chartDescription}>Monthly views and unique visitors</p>
                  </div>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={() => exportAllAnalytics({ 
                      profileViews: mockProfileViews, 
                      skillGrowth: mockSkillGrowth, 
                      sourceBreakdown: mockSourceBreakdown, 
                      networkGrowth: mockNetworkGrowth 
                    })}
                  >
                    <Download className={styles.buttonIcon} />
                    Export CSV
                  </Button>
                </div>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={mockProfileViews}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--color-neutral-6)" />
                    <XAxis dataKey="date" stroke="var(--color-neutral-11)" />
                    <YAxis stroke="var(--color-neutral-11)" />
                    <Tooltip contentStyle={{ background: 'var(--color-neutral-2)', border: '1px solid var(--color-neutral-6)' }} />
                    <Legend />
                    <Line type="monotone" dataKey="views" stroke="var(--color-accent-9)" strokeWidth={2} name="Total Views" />
                    <Line type="monotone" dataKey="uniqueVisitors" stroke="var(--color-success-9)" strokeWidth={2} name="Unique Visitors" />
                  </LineChart>
                </ResponsiveContainer>
              </Card>

              {/* Skill Growth Chart */}
              <Card className={styles.chartCard}>
                <div className={styles.chartHeader}>
                  <div>
                    <h3>Skill Growth</h3>
                    <p className={styles.chartDescription}>Contributions vs skill score over time</p>
                  </div>
                </div>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={mockSkillGrowth}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--color-neutral-6)" />
                    <XAxis dataKey="month" stroke="var(--color-neutral-11)" />
                    <YAxis stroke="var(--color-neutral-11)" />
                    <Tooltip contentStyle={{ background: 'var(--color-neutral-2)', border: '1px solid var(--color-neutral-6)' }} />
                    <Legend />
                    <Bar dataKey="contributions" fill="var(--color-accent-9)" name="Contributions" />
                    <Bar dataKey="skillScore" fill="var(--color-success-9)" name="Skill Score" />
                  </BarChart>
                </ResponsiveContainer>
              </Card>

              {/* Source Breakdown */}
              <Card className={styles.chartCard}>
                <div className={styles.chartHeader}>
                  <div>
                    <h3>Contribution Sources</h3>
                    <p className={styles.chartDescription}>Where your provable skills come from</p>
                  </div>
                </div>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={mockSourceBreakdown as any}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={(entry: any) => `${entry.source}: ${entry.percentage}%`}
                      outerRadius={100}
                      dataKey="contributions"
                    >
                      {mockSourceBreakdown.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={Object.values(COLORS)[index % 4]} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ background: 'var(--color-neutral-2)', border: '1px solid var(--color-neutral-6)' }} />
                  </PieChart>
                </ResponsiveContainer>
              </Card>

              {/* Who Viewed Your Profile */}
              <Card className={styles.chartCard}>
                <div className={styles.chartHeader}>
                  <div>
                    <h3>Who Viewed Your Profile</h3>
                    <p className={styles.chartDescription}>Recent recruiter activity</p>
                  </div>
                  <Badge variant="outline">Pro Feature</Badge>
                </div>
                <div className={styles.recruiterList}>
                  {mockRecruiterViews.map((recruiter) => (
                    <div key={recruiter.id} className={styles.recruiterItem}>
                      <img src={recruiter.avatar} alt={recruiter.name} className={styles.recruiterAvatar} />
                      <div className={styles.recruiterInfo}>
                        <div className={styles.recruiterName}>{recruiter.name}</div>
                        <div className={styles.recruiterCompany}>{recruiter.company}</div>
                      </div>
                      <div className={styles.recruiterStats}>
                        <Eye className={styles.statsIcon} />
                        <span>{recruiter.timesViewed}x</span>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </TabsContent>

          {/* Network Tab */}
          <TabsContent value="network" className={styles.tabContent}>
            <div className={styles.networkGrid}>
              {/* Network Growth */}
              <Card className={styles.chartCard}>
                <div className={styles.chartHeader}>
                  <div>
                    <h3>Network Growth</h3>
                    <p className={styles.chartDescription}>Connections and visibility over time</p>
                  </div>
                </div>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={mockNetworkGrowth}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--color-neutral-6)" />
                    <XAxis dataKey="month" stroke="var(--color-neutral-11)" />
                    <YAxis stroke="var(--color-neutral-11)" />
                    <Tooltip contentStyle={{ background: 'var(--color-neutral-2)', border: '1px solid var(--color-neutral-6)' }} />
                    <Legend />
                    <Line type="monotone" dataKey="connections" stroke="var(--color-accent-9)" strokeWidth={2} name="Connections" />
                    <Line type="monotone" dataKey="profileViews" stroke="var(--color-success-9)" strokeWidth={2} name="Profile Views" />
                  </LineChart>
                </ResponsiveContainer>
              </Card>

              {/* Suggested Connections */}
              <Card className={styles.connectionsCard}>
                <CardHeader>
                  <CardTitle>Suggested High-Signal Connections</CardTitle>
                  <CardDescription>Developers with similar expertise and contributions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className={styles.connectionsList}>
                    {suggestedConnections.map((connection, index) => (
                      <div key={index} className={styles.connectionItem}>
                        <Avatar className={styles.connectionAvatar}>
                          <AvatarImage src={connection.avatar} alt={connection.name} />
                          <AvatarFallback>{connection.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                        </Avatar>
                        <div className={styles.connectionInfo}>
                          <h4 className={styles.connectionName}>{connection.name}</h4>
                          <p className={styles.connectionTitle}>{connection.title}</p>
                          <div className={styles.connectionSkills}>
                            {connection.commonSkills.map((skill, i) => (
                              <Badge key={i} variant="secondary">{skill}</Badge>
                            ))}
                          </div>
                        </div>
                        <div className={styles.connectionMatch}>
                          <div className={styles.matchScore}>{connection.match}%</div>
                          <div className={styles.matchLabel}>Match</div>
                        </div>
                        <Button variant="outline">
                          <Users className={styles.buttonIcon} />
                          Connect
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Domain Tab */}
          <TabsContent value="domain" className={styles.tabContent}>
            <div className={styles.domainTabContent}>
              {!mockUser.aethexDomain ? (
                <Card>
                  <CardHeader>
                    <CardTitle className={styles.domainCardTitle}>
                      <Globe size={20} />
                      Claim Your .aethex Domain
                    </CardTitle>
                    <CardDescription>
                      Get your blockchain-verified Web3 identity. Your .aethex domain becomes your universal creator identity across the platform.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className={styles.domainBenefits}>
                      <div className={styles.benefitItem}>
                        <div className={styles.benefitIcon}>
                          <Shield size={24} />
                        </div>
                        <div className={styles.benefitContent}>
                          <h4>Blockchain Verified</h4>
                          <p>Your identity is secured and verified on the blockchain, proving ownership.</p>
                        </div>
                      </div>
                      <div className={styles.benefitItem}>
                        <div className={styles.benefitIcon}>
                          <Globe size={24} />
                        </div>
                        <div className={styles.benefitContent}>
                          <h4>Custom Portfolio Page</h4>
                          <p>Get a beautiful portfolio at yourname.aethex showcasing all your work.</p>
                        </div>
                      </div>
                      <div className={styles.benefitItem}>
                        <div className={styles.benefitIcon}>
                          <Check size={24} />
                        </div>
                        <div className={styles.benefitContent}>
                          <h4>Verified Creator Badge</h4>
                          <p>Display your verified status across the entire platform.</p>
                        </div>
                      </div>
                    </div>
                    <div className={styles.domainCta}>
                      <DomainRegistration onSuccess={() => window.location.reload()} />
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <DomainManager domainTier={mockUser.domainTier} username={mockUser.username} />
              )}
            </div>
          </TabsContent>

          {/* Revenue Tab */}
          <TabsContent value="revenue" className={styles.tabContent}>
            <RevenueDashboard revenue={mockRevenue} milestones={mockMilestones} />
          </TabsContent>

          {/* Share Tab */}
          <TabsContent value="share" className={styles.tabContent}>
            <div className={styles.shareGrid}>
              {/* Embed Widget */}
              <EmbedWidget 
                username={mockUser.username} 
                profileUrl={`https://devhub.dev/${mockUser.username}`}
              />

              {/* Share Links */}
              <Card className={styles.shareCard}>
                <CardHeader>
                  <CardTitle>Share Your Profile</CardTitle>
                  <CardDescription>Spread the word about your verified developer profile</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className={styles.shareButtons}>
                    <Button variant="outline" className={styles.shareButton}>
                      <Share2 className={styles.buttonIcon} />
                      Copy Link
                    </Button>
                    <Button variant="outline" className={styles.shareButton}>
                      <SiGithub className={styles.buttonIcon} />
                      Share on GitHub
                    </Button>
                    <Button variant="outline" className={styles.shareButton}>
                      <SiX className={styles.buttonIcon} />
                      Share on X
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
