import type { Route } from './+types/api.revenue';
import { revenue } from '~/lib/revenue.server';
import { auth } from '~/lib/auth.server';

export async function loader({ request }: Route.LoaderArgs) {
  const session = await auth.getSession(request.headers.get('Cookie'));
  const userId = session.get('userId');

  if (!userId) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const data = await revenue.getRevenueAnalytics(userId);
    return Response.json(data);
  } catch (error) {
    console.error('Revenue error:', error);
    return Response.json({ error: 'Failed to load revenue data' }, { status: 500 });
  }
}
