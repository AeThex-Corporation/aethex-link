import { Globe, Shield, Check, Wallet } from 'lucide-react';
import styles from './home.module.css';

export function DomainSection() {
  return (
    <section className={styles.domainSection}>
      <div className={styles.domainContent}>
        <div className={styles.domainHeader}>
          <Globe className={styles.domainHeaderIcon} />
          <h2 className={styles.domainTitle}>
            Claim Your <span className={styles.aethexHighlight}>.aethex</span> Domain
          </h2>
        </div>
        <p className={styles.domainDescription}>
          Get your blockchain-verified Web3 identity. Your .aethex domain becomes your canonical creator identity 
          across the entire platform—portable, verified, and owned by you forever.
        </p>
        
        <div className={styles.domainFeatures}>
          <div className={styles.domainFeature}>
            <div className={styles.featureIconWrapper}>
              <Shield size={32} />
            </div>
            <h3>Blockchain Verified</h3>
            <p>Your domain is registered and verified on the blockchain, proving ownership and authenticity.</p>
          </div>
          
          <div className={styles.domainFeature}>
            <div className={styles.featureIconWrapper}>
              <Globe size={32} />
            </div>
            <h3>Custom Portfolio</h3>
            <p>Get a beautiful portfolio page at yourname.aethex showcasing all your verified work.</p>
          </div>
          
          <div className={styles.domainFeature}>
            <div className={styles.featureIconWrapper}>
              <Check size={32} />
            </div>
            <h3>Verified Badge</h3>
            <p>Display your verified creator status across the platform with your .aethex domain.</p>
          </div>
          
          <div className={styles.domainFeature}>
            <div className={styles.featureIconWrapper}>
              <Wallet size={32} />
            </div>
            <h3>Portable Identity</h3>
            <p>Own your identity on the blockchain. Transfer, sell, or keep it forever—it's yours.</p>
          </div>
        </div>

        <div className={styles.domainPricing}>
          <div className={styles.pricingCard}>
            <div className={styles.pricingHeader}>
              <h3>Standard Domain</h3>
              <div className={styles.price}>
                <span className={styles.priceAmount}>$10</span>
                <span className={styles.pricePeriod}>/year</span>
              </div>
            </div>
            <ul className={styles.pricingFeatures}>
              <li>
                <Check size={16} />
                <span>Blockchain registration</span>
              </li>
              <li>
                <Check size={16} />
                <span>Custom portfolio page</span>
              </li>
              <li>
                <Check size={16} />
                <span>Verified creator badge</span>
              </li>
              <li>
                <Check size={16} />
                <span>Subdomain support</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
