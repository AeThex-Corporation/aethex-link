import { getUserId } from '~/lib/session.server';
import { db } from '~/lib/db.server';
import { freenameAPI } from '~/lib/freename.server';

export async function action({ request }: { request: Request }) {
  if (request.method !== 'POST') {
    return new Response('Method not allowed', { status: 405 });
  }

  try {
    const userId = await getUserId(request);
    if (!userId) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await db.user.findById(userId);
    if (!user) {
      return Response.json({ error: 'User not found' }, { status: 404 });
    }

    const body = await request.json();
    const { domain, walletAddress } = body;

    if (!domain || !walletAddress) {
      return Response.json(
        { error: 'Domain and wallet address are required' },
        { status: 400 }
      );
    }

    // Ensure domain ends with .aethex
    if (!domain.endsWith('.aethex')) {
      return Response.json(
        { error: 'Invalid domain format' },
        { status: 400 }
      );
    }

    // Check availability with Freename
    const isAvailable = await freenameAPI.checkAvailability(domain);
    if (!isAvailable) {
      return Response.json(
        { error: 'Domain is not available' },
        { status: 400 }
      );
    }

    // Register domain
    const registration = await freenameAPI.registerDomain(domain, walletAddress, 1);

    // Create domain record
    await db.domain.create({
      userId,
      domain,
      walletAddress,
      registrationDate: new Date(),
      expiryDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), // 1 year
      status: 'pending',
      transactionHash: registration.transactionHash,
      blockchain: 'Polygon',
      autoRenew: false,
    });

    // Create transaction record
    await db.domainTransaction.create({
      userId,
      domain,
      type: 'registration',
      amount: 10, // $10 per year
      currency: 'USD',
      status: 'pending',
      transactionHash: registration.transactionHash,
    });

    // Upgrade user to premium tier
    await db.user.update(userId, {
      domainTier: 'premium',
      aethexDomain: domain,
      walletAddress,
    });

    return Response.json({
      success: true,
      domain,
      transactionHash: registration.transactionHash,
    });
  } catch (error: any) {
    console.error('Domain upgrade error:', error);
    return Response.json(
      { error: error.message || 'Failed to upgrade domain' },
      { status: 500 }
    );
  }
}
