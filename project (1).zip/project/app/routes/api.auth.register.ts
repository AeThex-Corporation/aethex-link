import type { Route } from './+types/api.auth.register';
import { auth } from '~/lib/auth.server';
import { sessionStorage } from '~/lib/session.server';

export async function action({ request }: Route.ActionArgs) {
  if (request.method !== 'POST') {
    return new Response('Method not allowed', { status: 405 });
  }

  try {
    const body = await request.json();
    const { email, password, name, username } = body;

    if (!email || !password || !name || !username) {
      return Response.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const result = await auth.register({ email, password, name, username });

    // Create session
    const session = await sessionStorage.getSession();
    session.set('userId', result.user.id);

    return Response.json(result, {
      headers: {
        'Set-Cookie': await sessionStorage.commitSession(session),
      },
    });
  } catch (error: any) {
    return Response.json(
      { error: error.message || 'Registration failed' },
      { status: 400 }
    );
  }
}
