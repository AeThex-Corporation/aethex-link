import type { Route } from './+types/api.connections';
import { auth } from '~/lib/auth.server';
import { db } from '~/lib/db.server';
import { analytics } from '~/lib/analytics.server';

export async function loader({ request }: Route.LoaderArgs) {
  try {
    const user = await auth.requireAuth(request);
    const connections = await db.connection.findByUserId(user.id);

    return Response.json({ connections });
  } catch (error: any) {
    return Response.json(
      { error: error.message || 'Failed to fetch connections' },
      { status: 500 }
    );
  }
}

export async function action({ request }: Route.ActionArgs) {
  if (request.method !== 'POST') {
    return new Response('Method not allowed', { status: 405 });
  }

  try {
    const user = await auth.requireAuth(request);
    const body = await request.json();
    const { connectedUserId, action: connectionAction } = body;

    if (!connectedUserId) {
      return Response.json(
        { error: 'connectedUserId is required' },
        { status: 400 }
      );
    }

    let result;

    if (connectionAction === 'request') {
      result = await db.connection.create(user.id, connectedUserId);
      await analytics.trackEvent(user.id, 'connection_request', {
        connectedUserId,
      });
    } else if (connectionAction === 'accept') {
      result = await db.connection.updateStatus(connectedUserId, 'accepted');
      await analytics.trackEvent(user.id, 'connection_accept', {
        connectedUserId,
      });
    } else if (connectionAction === 'reject') {
      result = await db.connection.updateStatus(connectedUserId, 'rejected');
    } else {
      return Response.json(
        { error: 'Invalid action' },
        { status: 400 }
      );
    }

    return Response.json({ success: true, connection: result });
  } catch (error: any) {
    return Response.json(
      { error: error.message || 'Connection action failed' },
      { status: 500 }
    );
  }
}
