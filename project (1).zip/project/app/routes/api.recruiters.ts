import type { Route } from './+types/api.recruiters';
import { auth } from '~/lib/auth.server';
import { db } from '~/lib/db.server';

export async function loader({ request }: Route.LoaderArgs) {
  try {
    const url = new URL(request.url);
    const action = url.searchParams.get('action');

    if (action === 'search') {
      // Search for candidates
      const user = await auth.requireAuth(request);
      const recruiter = await db.recruiter.findByUserId(user.id);
      
      if (!recruiter) {
        return Response.json({ error: 'Not a recruiter' }, { status: 403 });
      }

      const skills = url.searchParams.get('skills')?.split(',') || [];
      const location = url.searchParams.get('location');

      // Get all users with profiles
      const allUsers: any[] = [];
      
      // This is simplified - in production, use proper search/filtering
      // For now, return sample matches
      const candidates = allUsers.filter(user => {
        // Match against recruiter's criteria
        return true; // Simplified
      });

      return Response.json({ candidates: candidates.slice(0, 20) });
    }

    // Get all recruiters
    const recruiters = await db.recruiter.findAll();
    const enrichedRecruiters = await Promise.all(
      recruiters.map(async (recruiter) => {
        const user = await db.user.findById(recruiter.userId);
        return {
          ...recruiter,
          user: user ? {
            id: user.id,
            name: user.name,
            username: user.username,
            avatar: user.avatar,
          } : null,
        };
      })
    );

    return Response.json({ recruiters: enrichedRecruiters });
  } catch (error: any) {
    return Response.json(
      { error: error.message || 'Failed to fetch recruiters' },
      { status: 500 }
    );
  }
}

export async function action({ request }: Route.ActionArgs) {
  try {
    const user = await auth.requireAuth(request);
    const body = await request.json();
    const { action, company, position, lookingFor, industries } = body;

    if (action === 'create') {
      const profile = await db.recruiter.create({
        userId: user.id,
        company,
        position,
        lookingFor: lookingFor || [],
        industries: industries || [],
        verified: false,
      });

      return Response.json({ success: true, profile });
    }

    if (action === 'update') {
      const profile = await db.recruiter.update(user.id, {
        company,
        position,
        lookingFor,
        industries,
      });

      return Response.json({ success: true, profile });
    }

    return Response.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error: any) {
    console.error('Recruiter error:', error);
    return Response.json(
      { error: error.message || 'Recruiter operation failed' },
      { status: 500 }
    );
  }
}
