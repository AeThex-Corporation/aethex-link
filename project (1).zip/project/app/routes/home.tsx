import { Link } from "react-router";
import type { Route } from "./+types/home";
import styles from "./home.module.css";
import { Button } from "~/components/ui/button/button";
import { Zap, Shield, Users, TrendingUp, Gamepad2, Brain, Code2, Award, Sparkles } from "lucide-react";
import { SiRoblox, SiUnity, SiUnrealengine, SiMeta } from "@icons-pack/react-simple-icons";
import { Particles } from "~/components/particles/particles";
import { AnimatedCounter } from "~/components/animated-counter/animated-counter";
import { FloatingShapes } from "~/components/floating-shapes/floating-shapes";
import { DomainSection } from "./home-domain-section";

export function meta({}: Route.MetaArgs) {
  return [
    { title: "CreatorHub - Multi-Platform Creator Verification" },
    {
      name: "description",
      content:
        "The ultimate verification platform for game developers, AI engineers, and software developers. Verify your skills across Roblox, Unity, Unreal, Meta Horizon Worlds, GitHub, and more.",
    },
    { property: "og:title", content: "CreatorHub - Multi-Platform Creator Verification" },
    {
      property: "og:description",
      content: "Verified credentials for game developers, AI engineers, and software creators. Auto-generated, data-backed profiles from your real work.",
    },
    { property: "og:type", content: "website" },
  ];
}

export default function Home() {
  return (
    <div className={styles.page}>
      <Particles />
      <FloatingShapes />
      {/* Hero Section */}
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <div className={styles.badge}>
            <Shield className={styles.badgeIcon} />
            <span>Multi-Platform Creator Verification</span>
          </div>
          <h1 className={styles.heroTitle}>
            Prove Your Skills Across
            <br />
            <span className={styles.highlight}>Every Platform You Create On</span>
          </h1>
          <p className={styles.heroDescription}>
            The ultimate verification hub for creators. Whether you're building games in Roblox, developing in Unity, 
            training AI models, or shipping code on GitHub—we aggregate all your work into one verified professional profile 
            that speaks for itself.
          </p>
          <div className={styles.heroActions}>
            <Button asChild size="lg">
              <Link to="/auth">Start Verifying Free</Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link to="/profile">View Demo Profile</Link>
            </Button>
          </div>
          <div className={styles.heroStats}>
            <div className={styles.stat}>
              <div className={styles.statValue}>
                <AnimatedCounter end={75000} suffix="+" />
              </div>
              <div className={styles.statLabel}>Verified Creators</div>
            </div>
            <div className={styles.stat}>
              <div className={styles.statValue}>
                <AnimatedCounter end={3800000} suffix="+" />
              </div>
              <div className={styles.statLabel}>Projects Analyzed</div>
            </div>
            <div className={styles.stat}>
              <div className={styles.statValue}>
                <AnimatedCounter end={12} suffix="+" />
              </div>
              <div className={styles.statLabel}>Platforms Supported</div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className={styles.categories}>
        <h2 className={styles.sectionTitle}>Verification Across All Creator Categories</h2>
        <p className={styles.sectionDescription}>
          One profile, unlimited possibilities. We verify your expertise across game development, AI engineering, and software development.
        </p>
        <div className={styles.categoriesGrid}>
          <div className={styles.category}>
            <div className={styles.categoryIcon}>
              <Gamepad2 />
            </div>
            <h3 className={styles.categoryTitle}>Game Development</h3>
            <p className={styles.categoryDescription}>
              Verify your game dev skills across Roblox, Unity, Unreal Engine, Meta Horizon Worlds, and more. 
              Track your game releases, player counts, revenue, and community engagement—all in one place.
            </p>
            <div className={styles.categoryPlatforms}>
              <span className={styles.platformBadge}>Roblox</span>
              <span className={styles.platformBadge}>Unity</span>
              <span className={styles.platformBadge}>Unreal Engine</span>
              <span className={styles.platformBadge}>Meta Horizon</span>
              <span className={styles.platformBadge}>Godot</span>
              <span className={styles.platformBadge}>GameMaker</span>
            </div>
          </div>
          <div className={styles.category}>
            <div className={styles.categoryIcon}>
              <Brain />
            </div>
            <h3 className={styles.categoryTitle}>AI Engineering</h3>
            <p className={styles.categoryDescription}>
              Showcase your AI and machine learning expertise. Verify contributions to AI models, Hugging Face repositories, 
              Kaggle competitions, research papers, and production ML systems.
            </p>
            <div className={styles.categoryPlatforms}>
              <span className={styles.platformBadge}>Hugging Face</span>
              <span className={styles.platformBadge}>Kaggle</span>
              <span className={styles.platformBadge}>Papers with Code</span>
              <span className={styles.platformBadge}>GitHub ML</span>
              <span className={styles.platformBadge}>OpenAI</span>
            </div>
          </div>
          <div className={styles.category}>
            <div className={styles.categoryIcon}>
              <Code2 />
            </div>
            <h3 className={styles.categoryTitle}>Software Development</h3>
            <p className={styles.categoryDescription}>
              Aggregate your coding contributions from GitHub, GitLab, Stack Overflow, npm packages, and open-source projects. 
              Build a verified developer resume backed by real code.
            </p>
            <div className={styles.categoryPlatforms}>
              <span className={styles.platformBadge}>GitHub</span>
              <span className={styles.platformBadge}>GitLab</span>
              <span className={styles.platformBadge}>Stack Overflow</span>
              <span className={styles.platformBadge}>npm/PyPI</span>
              <span className={styles.platformBadge}>Dev.to</span>
            </div>
          </div>
        </div>
      </section>

      {/* Game Dev Focus Section */}
      <section className={styles.gameDevSection}>
        <div className={styles.gameDevContent}>
          <div className={styles.gameDevHeader}>
            <Sparkles className={styles.gameDevIcon} />
            <h2 className={styles.gameDevTitle}>Game Developers: Your Work, Verified</h2>
          </div>
          <p className={styles.gameDevDescription}>
            We've built the most comprehensive game development verification system. Whether you're a Roblox creator with millions 
            of plays, a Unity developer shipping mobile games, or an Unreal Engine artist crafting AAA experiences—we track it all.
          </p>
          
          <div className={styles.gameDevPlatforms}>
            <div className={styles.gameDevPlatform}>
              <div className={styles.platformHeader}>
                <SiRoblox size={32} className={styles.platformLogo} />
                <h4>Roblox Studio</h4>
              </div>
              <ul className={styles.platformFeatures}>
                <li>Total game visits & active players</li>
                <li>Robux revenue & premium payouts</li>
                <li>Community ratings & favorites</li>
                <li>Scripting expertise (Lua)</li>
              </ul>
            </div>
            
            <div className={styles.gameDevPlatform}>
              <div className={styles.platformHeader}>
                <SiUnity size={32} className={styles.platformLogo} />
                <h4>Unity</h4>
              </div>
              <ul className={styles.platformFeatures}>
                <li>Published games on Asset Store</li>
                <li>GitHub Unity projects</li>
                <li>Unity forum contributions</li>
                <li>C# & Unity API expertise</li>
              </ul>
            </div>
            
            <div className={styles.gameDevPlatform}>
              <div className={styles.platformHeader}>
                <SiUnrealengine size={32} className={styles.platformLogo} />
                <h4>Unreal Engine</h4>
              </div>
              <ul className={styles.platformFeatures}>
                <li>Marketplace assets & plugins</li>
                <li>Blueprint & C++ projects</li>
                <li>Community forum activity</li>
                <li>AAA game contributions</li>
              </ul>
            </div>
            
            <div className={styles.gameDevPlatform}>
              <div className={styles.platformHeader}>
                <SiMeta size={32} className={styles.platformLogo} />
                <h4>Meta Horizon Worlds</h4>
              </div>
              <ul className={styles.platformFeatures}>
                <li>Published VR experiences</li>
                <li>World visitor metrics</li>
                <li>Scripting & world building</li>
                <li>Community engagement</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Three Pillars */}
      <section className={styles.pillars}>
        <div className={styles.pillarsGrid}>
          <div className={styles.pillar}>
            <div className={styles.pillarIcon}>
              <Shield />
            </div>
            <h3 className={styles.pillarTitle}>Multi-Platform Verification</h3>
            <p className={styles.pillarDescription}>
              Your portfolio writes itself. We aggregate everything—from Roblox game stats to GitHub commits, 
              Unity Asset Store sales to Kaggle medals. One verified profile, unlimited platforms.
            </p>
          </div>
          <div className={styles.pillar}>
            <div className={styles.pillarIcon}>
              <Users />
            </div>
            <h3 className={styles.pillarTitle}>Creator Networking</h3>
            <p className={styles.pillarDescription}>
              Connect with fellow game developers, AI engineers, and software creators based on actual work. 
              Find collaborators who've shipped similar projects or solved the same technical challenges.
            </p>
          </div>
          <div className={styles.pillar}>
            <div className={styles.pillarIcon}>
              <TrendingUp />
            </div>
            <h3 className={styles.pillarTitle}>Industry Discovery</h3>
            <p className={styles.pillarDescription}>
              For recruiters and studios: find verified talent based on real shipped projects. 
              Discover game developers with proven player engagement, AI engineers with published models, 
              or developers with production code—not just resume keywords.
            </p>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className={styles.howItWorks}>
        <h2 className={styles.sectionTitle}>How It Works</h2>
        <div className={styles.stepsGrid}>
          <div className={styles.step}>
            <div className={styles.stepNumber}>1</div>
            <h3 className={styles.stepTitle}>Connect Your Platforms</h3>
            <p className={styles.stepDescription}>
              Link your Roblox account, Unity profile, GitHub, Unreal Marketplace, Meta Horizon, 
              Hugging Face, Kaggle, and more. We securely aggregate public data only.
            </p>
          </div>
          <div className={styles.step}>
            <div className={styles.stepNumber}>2</div>
            <h3 className={styles.stepTitle}>We Verify Everything</h3>
            <p className={styles.stepDescription}>
              Our engine analyzes your game stats, code contributions, AI models, downloads, player counts, 
              revenue, and community engagement to build your comprehensive verified profile.
            </p>
          </div>
          <div className={styles.step}>
            <div className={styles.stepNumber}>3</div>
            <h3 className={styles.stepTitle}>Showcase & Connect</h3>
            <p className={styles.stepDescription}>
              Share your verified multi-platform profile, connect with other creators, 
              and let studios and companies discover you based on your real accomplishments.
            </p>
          </div>
        </div>
      </section>

      {/* Domain Section */}
      <DomainSection />

      {/* Data Sources */}
      <section className={styles.sources}>
        <h2 className={styles.sectionTitle}>All Your Platforms, One Profile</h2>
        <p className={styles.sectionDescription}>
          We integrate with 12+ platforms where creators actually build, ship, and share their work.
        </p>
        <div className={styles.sourcesGrid}>
          <div className={styles.sourceCard}>
            <Gamepad2 className={styles.sourceIcon} />
            <h4>Roblox</h4>
            <p>Games, visits, revenue, scripts, community ratings</p>
          </div>
          <div className={styles.sourceCard}>
            <Gamepad2 className={styles.sourceIcon} />
            <h4>Unity & Unreal</h4>
            <p>Published games, assets, marketplace sales, projects</p>
          </div>
          <div className={styles.sourceCard}>
            <Gamepad2 className={styles.sourceIcon} />
            <h4>Meta Horizon</h4>
            <p>VR worlds, visitors, scripting, community engagement</p>
          </div>
          <div className={styles.sourceCard}>
            <Brain className={styles.sourceIcon} />
            <h4>Hugging Face</h4>
            <p>Model uploads, downloads, community contributions</p>
          </div>
          <div className={styles.sourceCard}>
            <Brain className={styles.sourceIcon} />
            <h4>Kaggle</h4>
            <p>Competitions, notebooks, datasets, medals</p>
          </div>
          <div className={styles.sourceCard}>
            <Code2 className={styles.sourceIcon} />
            <h4>GitHub</h4>
            <p>Commits, PRs, repositories, stars, contributions</p>
          </div>
          <div className={styles.sourceCard}>
            <Code2 className={styles.sourceIcon} />
            <h4>Stack Overflow</h4>
            <p>Answers, questions, reputation, expertise tags</p>
          </div>
          <div className={styles.sourceCard}>
            <Award className={styles.sourceIcon} />
            <h4>npm / PyPI</h4>
            <p>Package authorship, downloads, maintenance</p>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className={styles.cta}>
        <h2 className={styles.ctaTitle}>Ready to Verify Your Multi-Platform Skills?</h2>
        <p className={styles.ctaDescription}>
          Join 75,000+ game developers, AI engineers, and software creators who've built their verified profiles. 
          Free for creators, always.
        </p>
        <Button asChild size="lg">
          <Link to="/auth">Create Your Profile</Link>
        </Button>
      </section>
    </div>
  );
}
