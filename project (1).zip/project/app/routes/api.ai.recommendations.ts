import type { Route } from './+types/api.ai.recommendations';
import { aiRecommendations } from '~/lib/ai-recommendations.server';
import { auth } from '~/lib/auth.server';

export async function loader({ request }: Route.LoaderArgs) {
  const user = await auth.requireAuth(request);
  
  // In production, fetch from database
  const mockProfile = {
    skills: [
      { name: 'TypeScript', level: 92, category: 'Languages' },
      { name: 'React', level: 88, category: 'Frontend' },
      { name: 'Node.js', level: 85, category: 'Backend' },
      { name: 'JavaScript', level: 95, category: 'Languages' },
      { name: 'Python', level: 75, category: 'Languages' },
      { name: 'Docker', level: 70, category: 'DevOps' },
      { name: 'SQL', level: 80, category: 'Database' },
    ],
  };

  const recommendations = await aiRecommendations.generateSkillRecommendations(
    mockProfile.skills,
    'senior',
    'senior'
  );

  return Response.json({ recommendations });
}
