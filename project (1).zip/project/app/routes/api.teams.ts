import type { Route } from './+types/api.teams';
import { auth } from '~/lib/auth.server';
import { db } from '~/lib/db.server';

export async function loader({ request }: Route.LoaderArgs) {
  try {
    const user = await auth.requireAuth(request);
    
    // Get user's team memberships
    const memberships = await db.teamMember.findByUserId(user.id);
    
    // Get team details
    const teams = await Promise.all(
      memberships.map(async (membership) => {
        const team = await db.team.findById(membership.teamId);
        if (!team) return null;
        
        const members = await db.teamMember.findByTeamId(team.id);
        const enrichedMembers = await Promise.all(
          members.map(async (m) => {
            const user = await db.user.findById(m.userId);
            return {
              ...m,
              user: user ? {
                id: user.id,
                name: user.name,
                username: user.username,
                avatar: user.avatar,
              } : null,
            };
          })
        );

        return {
          ...team,
          role: membership.role,
          members: enrichedMembers,
        };
      })
    );

    return Response.json({ teams: teams.filter(Boolean) });
  } catch (error: any) {
    return Response.json(
      { error: error.message || 'Failed to fetch teams' },
      { status: 500 }
    );
  }
}

export async function action({ request }: Route.ActionArgs) {
  try {
    const user = await auth.requireAuth(request);
    const body = await request.json();
    const { action, teamId, name, description, userId, role } = body;

    if (action === 'create') {
      // Create new team
      const team = await db.team.create({
        name,
        description,
        ownerId: user.id,
      });

      // Add creator as owner
      await db.teamMember.create({
        teamId: team.id,
        userId: user.id,
        role: 'owner',
        joinedAt: new Date(),
      });

      return Response.json({ success: true, team });
    }

    if (action === 'update') {
      const team = await db.team.findById(teamId);
      
      if (!team) {
        return Response.json({ error: 'Team not found' }, { status: 404 });
      }

      if (team.ownerId !== user.id) {
        return Response.json({ error: 'Unauthorized' }, { status: 403 });
      }

      const updated = await db.team.update(teamId, { name, description });
      return Response.json({ success: true, team: updated });
    }

    if (action === 'invite') {
      const team = await db.team.findById(teamId);
      
      if (!team) {
        return Response.json({ error: 'Team not found' }, { status: 404 });
      }

      // Check if user has permission to invite
      const membership = (await db.teamMember.findByTeamId(teamId))
        .find(m => m.userId === user.id);
      
      if (!membership || (membership.role !== 'owner' && membership.role !== 'admin')) {
        return Response.json({ error: 'Unauthorized' }, { status: 403 });
      }

      // Add member
      const member = await db.teamMember.create({
        teamId,
        userId,
        role: role || 'member',
        joinedAt: new Date(),
      });

      return Response.json({ success: true, member });
    }

    if (action === 'remove') {
      const team = await db.team.findById(teamId);
      
      if (!team) {
        return Response.json({ error: 'Team not found' }, { status: 404 });
      }

      const membership = (await db.teamMember.findByTeamId(teamId))
        .find(m => m.userId === user.id);
      
      if (!membership || (membership.role !== 'owner' && membership.role !== 'admin')) {
        return Response.json({ error: 'Unauthorized' }, { status: 403 });
      }

      await db.teamMember.remove(teamId, userId);
      return Response.json({ success: true });
    }

    if (action === 'leave') {
      await db.teamMember.remove(teamId, user.id);
      return Response.json({ success: true });
    }

    if (action === 'delete') {
      const team = await db.team.findById(teamId);
      
      if (!team) {
        return Response.json({ error: 'Team not found' }, { status: 404 });
      }

      if (team.ownerId !== user.id) {
        return Response.json({ error: 'Unauthorized' }, { status: 403 });
      }

      await db.team.delete(teamId);
      return Response.json({ success: true });
    }

    return Response.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error: any) {
    console.error('Team error:', error);
    return Response.json(
      { error: error.message || 'Team operation failed' },
      { status: 500 }
    );
  }
}
