import type { Route } from './+types/api.portfolio';
import { auth } from '~/lib/auth.server';
import { db } from '~/lib/db.server';

export async function loader({ request }: Route.LoaderArgs) {
  try {
    const user = await auth.requireAuth(request);
    const url = new URL(request.url);
    const type = url.searchParams.get('type') as any;

    let portfolioItems;
    if (type) {
      portfolioItems = await db.portfolio.findByUserAndType(user.id, type);
    } else {
      portfolioItems = await db.portfolio.findByUserId(user.id);
    }

    return Response.json({ items: portfolioItems });
  } catch (error: any) {
    console.error('Portfolio fetch error:', error);
    return Response.json(
      { error: error.message || 'Failed to fetch portfolio items' },
      { status: 500 }
    );
  }
}

export async function action({ request }: Route.ActionArgs) {
  try {
    const user = await auth.requireAuth(request);
    const body = await request.json();
    const { action: actionType } = body;

    if (request.method === 'POST' && actionType === 'create') {
      const { type, title, description, platform, url, thumbnailUrl, videoUrl, stats, tags, featured } = body;

      const item = await db.portfolio.create({
        userId: user.id,
        type,
        title,
        description,
        platform,
        url,
        thumbnailUrl,
        videoUrl,
        stats,
        tags: tags || [],
        featured: featured || false,
      });

      return Response.json({ success: true, item });
    }

    if (request.method === 'PATCH') {
      const { id, ...updates } = body;
      const item = await db.portfolio.update(id, updates);

      if (!item) {
        return Response.json({ error: 'Portfolio item not found' }, { status: 404 });
      }

      return Response.json({ success: true, item });
    }

    if (request.method === 'DELETE') {
      const { id } = body;
      const success = await db.portfolio.delete(id);

      if (!success) {
        return Response.json({ error: 'Portfolio item not found' }, { status: 404 });
      }

      return Response.json({ success: true });
    }

    return Response.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error: any) {
    console.error('Portfolio action error:', error);
    return Response.json(
      { error: error.message || 'Failed to process portfolio action' },
      { status: 500 }
    );
  }
}
