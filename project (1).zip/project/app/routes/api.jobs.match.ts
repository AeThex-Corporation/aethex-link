import type { Route } from './+types/api.jobs.match';
import { jobMatching, type JobPosting } from '~/lib/job-matching.server';
import { auth } from '~/lib/auth.server';

// Mock job postings (in production, fetch from real job APIs)
const MOCK_JOBS: JobPosting[] = [
  {
    id: '1',
    title: 'Senior Full-Stack Developer',
    company: 'TechCorp',
    location: 'San Francisco, CA',
    remote: true,
    salary: { min: 140000, max: 180000, currency: 'USD' },
    requiredSkills: ['TypeScript', 'React', 'Node.js', 'PostgreSQL'],
    preferredSkills: ['GraphQL', 'Docker', 'AWS'],
    experience: { min: 4, max: 7 },
    description: 'Join our team building next-gen web applications...',
    benefits: ['Health insurance', 'Equity', '401k matching'],
    postedDate: new Date('2024-01-15'),
  },
  {
    id: '2',
    title: 'React Developer',
    company: 'StartupXYZ',
    location: 'Remote',
    remote: true,
    salary: { min: 120000, max: 150000, currency: 'USD' },
    requiredSkills: ['React', 'TypeScript', 'JavaScript'],
    preferredSkills: ['Next.js', 'GraphQL', 'Testing'],
    experience: { min: 3, max: 5 },
    description: 'Build beautiful user interfaces...',
    benefits: ['Remote work', 'Flexible hours', 'Learning budget'],
    postedDate: new Date('2024-01-20'),
  },
  {
    id: '3',
    title: 'Staff Engineer',
    company: 'MegaCorp',
    location: 'New York, NY',
    remote: false,
    salary: { min: 180000, max: 250000, currency: 'USD' },
    requiredSkills: ['System Design', 'Microservices', 'Kubernetes', 'AWS'],
    preferredSkills: ['Python', 'Go', 'Team Leadership'],
    experience: { min: 7, max: 12 },
    description: 'Lead critical infrastructure projects...',
    benefits: ['Competitive salary', 'Stock options', 'Full benefits'],
    postedDate: new Date('2024-01-18'),
  },
  {
    id: '4',
    title: 'Machine Learning Engineer',
    company: 'AI Innovations',
    location: 'Remote',
    remote: true,
    salary: { min: 150000, max: 200000, currency: 'USD' },
    requiredSkills: ['Python', 'Machine Learning', 'TensorFlow', 'PyTorch'],
    preferredSkills: ['Kubernetes', 'AWS', 'MLOps'],
    experience: { min: 3, max: 6 },
    description: 'Deploy ML models at scale...',
    benefits: ['Remote work', 'GPU budget', 'Conference attendance'],
    postedDate: new Date('2024-01-22'),
  },
  {
    id: '5',
    title: 'Frontend Developer',
    company: 'DesignStudio',
    location: 'Austin, TX',
    remote: true,
    salary: { min: 100000, max: 130000, currency: 'USD' },
    requiredSkills: ['React', 'JavaScript', 'CSS'],
    preferredSkills: ['TypeScript', 'Vue.js', 'Figma'],
    experience: { min: 2, max: 4 },
    description: 'Create stunning user experiences...',
    benefits: ['Remote-first', 'Design tools budget', 'Flexible PTO'],
    postedDate: new Date('2024-01-25'),
  },
];

export async function loader({ request }: Route.LoaderArgs) {
  const user = await auth.requireAuth(request);
  
  // Mock developer profile
  const profile = {
    skills: [
      { name: 'TypeScript', level: 92 },
      { name: 'React', level: 88 },
      { name: 'Node.js', level: 85 },
      { name: 'JavaScript', level: 95 },
      { name: 'Python', level: 75 },
      { name: 'Docker', level: 70 },
      { name: 'PostgreSQL', level: 80 },
      { name: 'GraphQL', level: 65 },
    ],
    experience: 5,
    location: 'Remote',
    remotePreference: true,
    salaryExpectation: { min: 130000, max: 170000, currency: 'USD' },
    willingToRelocate: false,
  };

  const matches = await jobMatching.findMatchingJobs(profile, MOCK_JOBS, 10);

  return Response.json({ matches, totalJobs: MOCK_JOBS.length });
}
