import type { Route } from './+types/api.profile.sync';
import { aggregation } from '~/lib/aggregation.server';
import { auth } from '~/lib/auth.server';

export async function action({ request }: Route.ActionArgs) {
  const session = await auth.getSession(request.headers.get('Cookie'));
  const userId = session.get('userId');

  if (!userId) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const profile = await aggregation.syncAllPlatforms(userId);
    return Response.json({ 
      success: true, 
      profile,
      message: 'Profile synced successfully',
    });
  } catch (error) {
    console.error('Sync error:', error);
    return Response.json({ 
      error: 'Failed to sync profile',
      details: error instanceof Error ? error.message : 'Unknown error',
    }, { status: 500 });
  }
}
