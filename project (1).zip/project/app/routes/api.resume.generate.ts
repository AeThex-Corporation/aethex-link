import type { Route } from './+types/api.resume.generate';
import { resumeBuilder } from '~/lib/resume-builder.server';
import { auth } from '~/lib/auth.server';
import { mockProfile } from '~/data/mock-profile-data';

export async function loader({ request }: Route.LoaderArgs) {
  const user = await auth.requireAuth(request);
  const url = new URL(request.url);
  const template = (url.searchParams.get('template') as any) || 'modern';
  
  const resumeData = await resumeBuilder.generateResumeData(mockProfile);

  return Response.json({ resumeData, template });
}

export async function action({ request }: Route.ActionArgs) {
  const user = await auth.requireAuth(request);
  const formData = await request.formData();
  const jobDescription = formData.get('jobDescription') as string;
  
  const resumeData = await resumeBuilder.generateResumeData(mockProfile);
  
  if (jobDescription) {
    const tailoredResume = await resumeBuilder.tailorToJobDescription(resumeData, jobDescription);
    const matchScore = resumeBuilder.calculateMatchScore(resumeData, jobDescription);
    
    return Response.json({ resumeData: tailoredResume, matchScore });
  }
  
  return Response.json({ resumeData });
}
