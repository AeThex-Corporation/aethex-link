import type { Route } from './+types/widgets';
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '~/components/ui/card/card';
import { Button } from '~/components/ui/button/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '~/components/ui/tabs/tabs';
import { Label } from '~/components/ui/label/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '~/components/ui/select/select';
import { Code, Copy, Check, Sparkles } from 'lucide-react';
import { useAuth } from '~/hooks/use-auth';
import { useToast } from '~/hooks/use-toast';
import styles from './widgets.module.css';

export default function Widgets({}: Route.ComponentProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [theme, setTheme] = useState('light');
  const [widgetType, setWidgetType] = useState('card');
  const [copied, setCopied] = useState(false);

  const embedCode = `<!-- Aethex Profile Widget -->
<div id="aethex-widget"></div>
<script src="https://aethex.com/api/widget/embed?username=${user?.username || 'yourUsername'}&type=${widgetType}&theme=${theme}"></script>`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(embedCode);
    setCopied(true);
    toast({
      title: 'Copied!',
      description: 'Widget code copied to clipboard',
    });
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <div className={styles.headerContent}>
          <div className={styles.headerText}>
            <h1 className={styles.title}>
              <Sparkles size={32} />
              Embeddable Widgets
            </h1>
            <p className={styles.subtitle}>
              Share your profile on any website with customizable widgets
            </p>
          </div>
        </div>
      </div>

      <div className={styles.content}>
        <div className={styles.grid}>
          <div className={styles.configPanel}>
            <Card>
              <CardHeader>
                <CardTitle>Widget Configuration</CardTitle>
                <CardDescription>
                  Customize your widget appearance
                </CardDescription>
              </CardHeader>
              <CardContent className={styles.config}>
                <div className={styles.configField}>
                  <Label>Widget Type</Label>
                  <Select value={widgetType} onValueChange={setWidgetType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="card">Profile Card</SelectItem>
                      <SelectItem value="badge">Simple Badge</SelectItem>
                      <SelectItem value="portfolio">Portfolio Grid</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className={styles.configField}>
                  <Label>Theme</Label>
                  <Select value={theme} onValueChange={setTheme}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">Light</SelectItem>
                      <SelectItem value="dark">Dark</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className={styles.codeBlock}>
                  <div className={styles.codeHeader}>
                    <Label>Embed Code</Label>
                    <Button 
                      size="sm" 
                      variant="ghost"
                      onClick={copyToClipboard}
                    >
                      {copied ? <Check size={16} /> : <Copy size={16} />}
                      {copied ? 'Copied!' : 'Copy'}
                    </Button>
                  </div>
                  <pre className={styles.code}>
                    <code>{embedCode}</code>
                  </pre>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Usage Instructions</CardTitle>
              </CardHeader>
              <CardContent className={styles.instructions}>
                <ol>
                  <li>Choose your preferred widget type and theme</li>
                  <li>Copy the embed code above</li>
                  <li>Paste it into your website's HTML</li>
                  <li>The widget will automatically load your profile data</li>
                </ol>
              </CardContent>
            </Card>
          </div>

          <div className={styles.preview}>
            <Card>
              <CardHeader>
                <CardTitle>Live Preview</CardTitle>
                <CardDescription>
                  This is how your widget will appear
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div 
                  className={styles.previewFrame}
                  style={{
                    background: theme === 'dark' ? '#1f2937' : '#ffffff'
                  }}
                >
                  <div id="widget-preview" className={styles.widgetPreview}>
                    <p className={styles.previewNote}>
                      Widget preview will appear here
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Features</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className={styles.features}>
                  <li>Automatically syncs with your profile</li>
                  <li>Responsive design for all devices</li>
                  <li>Lightweight and fast loading</li>
                  <li>No dependencies required</li>
                  <li>Customizable themes</li>
                  <li>SEO-friendly</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
