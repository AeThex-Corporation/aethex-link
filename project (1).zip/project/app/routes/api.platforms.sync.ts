import type { Route } from './+types/api.platforms.sync';
import { auth } from '~/lib/auth.server';
import { db } from '~/lib/db.server';
import { aggregation } from '~/lib/aggregation.server';
import { analytics } from '~/lib/analytics.server';

export async function action({ request }: Route.ActionArgs) {
  if (request.method !== 'POST') {
    return new Response('Method not allowed', { status: 405 });
  }

  try {
    const user = await auth.requireAuth(request);
    const body = await request.json();

    const {
      // Game Dev Platforms
      robloxUsername,
      robloxApiKey,
      unityPublisherId,
      unityApiKey,
      // AI Platforms
      huggingFaceUsername,
      huggingFaceToken,
      kaggleUsername,
      kaggleApiKey,
      // Existing platforms
      githubUsername,
      githubToken,
      stackOverflowId,
    } = body;

    // Update profile with new platform connections
    await db.profile.update(user.id, {
      robloxUsername: robloxUsername || undefined,
      robloxApiKey: robloxApiKey || undefined,
      unityPublisherId: unityPublisherId || undefined,
      unityApiKey: unityApiKey || undefined,
      huggingFaceUsername: huggingFaceUsername || undefined,
      huggingFaceToken: huggingFaceToken || undefined,
      kaggleUsername: kaggleUsername || undefined,
      kaggleApiKey: kaggleApiKey || undefined,
      githubUsername: githubUsername || undefined,
      stackOverflowId: stackOverflowId || undefined,
    });

    // Update user's tokens if provided
    if (githubToken) {
      await db.user.update(user.id, { githubToken });
    }

    // Aggregate data from all sources
    const profile = await aggregation.syncAllPlatforms(user.id);

    // Track sync events
    if (githubUsername) {
      await analytics.trackEvent(user.id, 'github_sync', {
        source: 'GitHub',
        contributions: profile.stats.totalContributions,
      });
    }

    if (stackOverflowId) {
      await analytics.trackEvent(user.id, 'stackoverflow_sync', {
        source: 'Stack Overflow',
        reputation: profile.stats.stackOverflowReputation,
      });
    }

    if (robloxUsername) {
      await analytics.trackEvent(user.id, 'profile_view', {
        source: 'Roblox',
        username: robloxUsername,
      });
    }

    if (huggingFaceUsername) {
      await analytics.trackEvent(user.id, 'profile_view', {
        source: 'Hugging Face',
        username: huggingFaceUsername,
      });
    }

    if (kaggleUsername) {
      await analytics.trackEvent(user.id, 'profile_view', {
        source: 'Kaggle',
        username: kaggleUsername,
      });
    }

    return Response.json({ success: true, profile });
  } catch (error: any) {
    console.error('Platform sync error:', error);
    return Response.json(
      { error: error.message || 'Failed to sync platforms' },
      { status: 500 }
    );
  }
}
