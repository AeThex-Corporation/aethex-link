import type { LoaderFunctionArgs } from 'react-router';
import { db } from '~/lib/db.server';

/**
 * Get domain registration analytics (admin only)
 * GET /api/domain/analytics
 */
export async function loader({ request }: LoaderFunctionArgs) {
  try {
    // In production, add admin authentication check here
    
    // Get total revenue from domain registrations and renewals
    const totalRevenue = await db.domainTransaction.getTotalRevenue();
    
    // Get all transactions
    const allTransactions = await Promise.all(
      Array.from({ length: 100 }, async (_, i) => {
        const userId = `user-${i}`;
        return db.domainTransaction.findByUserId(userId);
      })
    ).then(results => results.flat());

    // Calculate stats
    const registrations = allTransactions.filter(t => t.type === 'registration' && t.status === 'completed');
    const renewals = allTransactions.filter(t => t.type === 'renewal' && t.status === 'completed');
    
    const stats = {
      totalRevenue,
      totalDomains: registrations.length,
      totalRenewals: renewals.length,
      averagePrice: registrations.length > 0 
        ? registrations.reduce((sum, t) => sum + t.amount, 0) / registrations.length 
        : 0,
      recentTransactions: allTransactions
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
        .slice(0, 10),
    };

    return Response.json(stats);
  } catch (error: any) {
    console.error('Failed to get domain analytics:', error);
    return Response.json({
      error: error.message || 'Failed to get analytics',
    }, { status: 500 });
  }
}
