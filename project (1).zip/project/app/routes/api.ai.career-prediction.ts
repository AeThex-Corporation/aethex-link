import type { Route } from './+types/api.ai.career-prediction';
import { aiRecommendations } from '~/lib/ai-recommendations.server';
import { auth } from '~/lib/auth.server';

export async function loader({ request }: Route.LoaderArgs) {
  const user = await auth.requireAuth(request);
  
  // In production, fetch from database
  const mockProfile = {
    skills: [
      { name: 'TypeScript', level: 92 },
      { name: 'React', level: 88 },
      { name: 'Node.js', level: 85 },
      { name: 'JavaScript', level: 95 },
      { name: 'Python', level: 75 },
      { name: 'Docker', level: 70 },
      { name: 'SQL', level: 80 },
    ],
    experience: 5,
    title: 'Senior Full-Stack Developer',
  };

  const prediction = await aiRecommendations.predictCareerPath(
    mockProfile.skills,
    mockProfile.experience,
    mockProfile.title
  );

  return Response.json({ prediction });
}
