import { useState, useEffect } from 'react';
import type { Route } from './+types/career-hub';
import { Header } from '~/components/header/header';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '~/components/ui/tabs/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '~/components/ui/card/card';
import { Button } from '~/components/ui/button/button';
import { Badge } from '~/components/ui/badge/badge';
import { Progress } from '~/components/ui/progress/progress';
import {
  Brain,
  Briefcase,
  FileText,
  TrendingUp,
  Target,
  Zap,
  Award,
  Calendar,
  DollarSign,
  MapPin,
  ExternalLink,
  Download,
  Sparkles,
  Rocket,
  GraduationCap,
  Clock,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { GradientText } from '~/components/gradient-text/gradient-text';
import { AnimatedCounter } from '~/components/animated-counter/animated-counter';
import styles from './career-hub.module.css';

export function meta({}: Route.MetaArgs) {
  return [
    { title: 'Career Hub - AI-Powered Career Planning | CreatorHub' },
    { name: 'description', content: 'Smart job matching, AI skill recommendations, and automated resume builder' },
  ];
}

export default function CareerHub() {
  const [activeTab, setActiveTab] = useState('overview');
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [careerPrediction, setCareerPrediction] = useState<any>(null);
  const [jobMatches, setJobMatches] = useState<any[]>([]);
  const [resumeData, setResumeData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCareerData();
  }, []);

  const loadCareerData = async () => {
    try {
      setLoading(true);
      
      // Load all career data in parallel
      const [recsRes, predRes, jobsRes, resumeRes] = await Promise.all([
        fetch('/api/ai/recommendations'),
        fetch('/api/ai/career-prediction'),
        fetch('/api/jobs/match'),
        fetch('/api/resume/generate'),
      ]);

      const [recsData, predData, jobsData, resumeDataRes] = await Promise.all([
        recsRes.json(),
        predRes.json(),
        jobsRes.json(),
        resumeRes.json(),
      ]);

      setRecommendations(recsData.recommendations || []);
      setCareerPrediction(predData.prediction);
      setJobMatches(jobsData.matches || []);
      setResumeData(resumeDataRes.resumeData);
    } catch (error) {
      console.error('Error loading career data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getDemandColor = (demand: string) => {
    switch (demand) {
      case 'high': return 'var(--color-success-9)';
      case 'medium': return 'var(--color-accent-9)';
      case 'low': return 'var(--color-neutral-9)';
      default: return 'var(--color-neutral-9)';
    }
  };

  const getMatchColor = (score: number) => {
    if (score >= 80) return 'var(--color-success-9)';
    if (score >= 60) return 'var(--color-accent-9)';
    return 'var(--color-error-9)';
  };

  if (loading) {
    return (
      <div className={styles.page}>
        <Header isAuthenticated={true} />
        <div className={styles.loadingContainer}>
          <div className={styles.loadingSpinner} />
          <p>Analyzing your career trajectory...</p>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.page}>
      <Header isAuthenticated={true} />

      <div className={styles.container}>
        {/* Hero Section */}
        <div className={styles.hero}>
          <div className={styles.heroContent}>
            <h1 className={styles.heroTitle}>
              <GradientText>AI-Powered Career Hub</GradientText>
            </h1>
            <p className={styles.heroSubtitle}>
              Smart job matching, personalized skill recommendations, and career insights powered by AI
            </p>
          </div>

          {/* Career Score Dashboard */}
          {careerPrediction && (
            <div className={styles.scoreGrid}>
              <Card className={styles.scoreCard}>
                <CardContent className={styles.scoreCardContent}>
                  <div className={styles.scoreIcon}>
                    <Target size={32} />
                  </div>
                  <div className={styles.scoreValue}>
                    <AnimatedCounter end={careerPrediction.confidenceScore} duration={2000} />
                    <span className={styles.scoreUnit}>%</span>
                  </div>
                  <div className={styles.scoreLabel}>Career Confidence</div>
                </CardContent>
              </Card>

              <Card className={styles.scoreCard}>
                <CardContent className={styles.scoreCardContent}>
                  <div className={styles.scoreIcon}>
                    <TrendingUp size={32} />
                  </div>
                  <div className={styles.scoreValue}>
                    {careerPrediction.estimatedTimeToNextLevel}
                  </div>
                  <div className={styles.scoreLabel}>To {careerPrediction.nextLevel}</div>
                </CardContent>
              </Card>

              <Card className={styles.scoreCard}>
                <CardContent className={styles.scoreCardContent}>
                  <div className={styles.scoreIcon}>
                    <DollarSign size={32} />
                  </div>
                  <div className={styles.scoreValue}>
                    ${Math.round(careerPrediction.salaryProjection.projected / 1000)}k
                  </div>
                  <div className={styles.scoreLabel}>Projected Salary</div>
                </CardContent>
              </Card>

              <Card className={styles.scoreCard}>
                <CardContent className={styles.scoreCardContent}>
                  <div className={styles.scoreIcon}>
                    <Briefcase size={32} />
                  </div>
                  <div className={styles.scoreValue}>
                    <AnimatedCounter end={jobMatches.length} duration={1500} />
                  </div>
                  <div className={styles.scoreLabel}>Matching Jobs</div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className={styles.tabs}>
          <TabsList className={styles.tabsList}>
            <TabsTrigger value="overview">
              <Sparkles size={16} />
              Overview
            </TabsTrigger>
            <TabsTrigger value="recommendations">
              <Brain size={16} />
              Skill Recommendations
            </TabsTrigger>
            <TabsTrigger value="jobs">
              <Briefcase size={16} />
              Job Matches
            </TabsTrigger>
            <TabsTrigger value="resume">
              <FileText size={16} />
              Resume Builder
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className={styles.tabContent}>
            <div className={styles.overviewGrid}>
              {/* Career Path Prediction */}
              {careerPrediction && (
                <Card className={styles.careerPathCard}>
                  <CardHeader>
                    <CardTitle className={styles.cardTitleWithIcon}>
                      <Rocket size={24} />
                      Career Progression Path
                    </CardTitle>
                    <CardDescription>
                      AI-powered prediction based on your current trajectory
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className={styles.progressionPath}>
                      <div className={styles.currentLevel}>
                        <div className={styles.levelBadge}>
                          <Award size={20} />
                          <span>{careerPrediction.currentLevel}</span>
                        </div>
                        <div className={styles.levelLabel}>Current Level</div>
                      </div>

                      <div className={styles.progressionArrow}>
                        <TrendingUp size={32} />
                        <div className={styles.timeEstimate}>
                          <Clock size={16} />
                          <span>{careerPrediction.estimatedTimeToNextLevel}</span>
                        </div>
                      </div>

                      <div className={styles.nextLevel}>
                        <div className={styles.levelBadge}>
                          <Target size={20} />
                          <span>{careerPrediction.nextLevel}</span>
                        </div>
                        <div className={styles.levelLabel}>Target Level</div>
                      </div>
                    </div>

                    <div className={styles.skillGaps}>
                      <h4 className={styles.sectionSubtitle}>Skills to Master</h4>
                      <div className={styles.gapsList}>
                        {careerPrediction.skillGaps.map((skill: string) => (
                          <Badge key={skill} variant="outline" className={styles.gapBadge}>
                            <AlertCircle size={14} />
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className={styles.salaryProjection}>
                      <h4 className={styles.sectionSubtitle}>Salary Projection</h4>
                      <div className={styles.salaryComparison}>
                        <div className={styles.salaryItem}>
                          <div className={styles.salaryLabel}>Current</div>
                          <div className={styles.salaryValue}>
                            ${careerPrediction.salaryProjection.current.toLocaleString()}
                          </div>
                        </div>
                        <div className={styles.salaryArrow}>→</div>
                        <div className={styles.salaryItem}>
                          <div className={styles.salaryLabel}>Projected</div>
                          <div className={styles.salaryValue}>
                            ${careerPrediction.salaryProjection.projected.toLocaleString()}
                          </div>
                        </div>
                      </div>
                      <div className={styles.salaryIncrease}>
                        <TrendingUp size={16} />
                        <span>
                          +{Math.round(((careerPrediction.salaryProjection.projected - careerPrediction.salaryProjection.current) / careerPrediction.salaryProjection.current) * 100)}%
                          increase in {careerPrediction.salaryProjection.timeframe}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Top Recommendations Preview */}
              <Card className={styles.recommendationsPreview}>
                <CardHeader>
                  <CardTitle className={styles.cardTitleWithIcon}>
                    <Zap size={24} />
                    Top Skill Recommendations
                  </CardTitle>
                  <CardDescription>
                    Skills to learn next based on your career goals
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className={styles.recommendationsList}>
                    {recommendations.slice(0, 3).map((rec, idx) => (
                      <div key={idx} className={styles.recommendationItem}>
                        <div className={styles.recommendationHeader}>
                          <h4 className={styles.recommendationSkill}>{rec.skill}</h4>
                          <Badge 
                            style={{ 
                              background: getDemandColor(rec.marketDemand),
                              color: 'var(--color-neutral-1)' 
                            }}
                          >
                            {rec.marketDemand} demand
                          </Badge>
                        </div>
                        <p className={styles.recommendationReason}>{rec.reason}</p>
                        <div className={styles.recommendationMeta}>
                          <span className={styles.metaItem}>
                            <DollarSign size={14} />
                            +{rec.averageSalaryImpact}% salary
                          </span>
                          <span className={styles.metaItem}>
                            <Clock size={14} />
                            {rec.timeToLearn}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                  <Button 
                    variant="outline" 
                    className={styles.viewAllButton}
                    onClick={() => setActiveTab('recommendations')}
                  >
                    View All Recommendations
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Skill Recommendations Tab */}
          <TabsContent value="recommendations" className={styles.tabContent}>
            <Card>
              <CardHeader>
                <CardTitle className={styles.cardTitleWithIcon}>
                  <Brain size={24} />
                  AI-Powered Skill Recommendations
                </CardTitle>
                <CardDescription>
                  Personalized learning path based on market demand and your existing skills
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className={styles.fullRecommendationsList}>
                  {recommendations.map((rec, idx) => (
                    <div key={idx} className={styles.fullRecommendationItem}>
                      <div className={styles.recommendationRank}>#{idx + 1}</div>
                      <div className={styles.recommendationContent}>
                        <div className={styles.recommendationTop}>
                          <div>
                            <h3 className={styles.recommendationTitle}>{rec.skill}</h3>
                            <p className={styles.recommendationDescription}>{rec.reason}</p>
                          </div>
                          <div className={styles.recommendationBadges}>
                            <Badge 
                              style={{ 
                                background: getDemandColor(rec.marketDemand),
                                color: 'var(--color-neutral-1)' 
                              }}
                            >
                              {rec.marketDemand} demand
                            </Badge>
                            <Badge variant="outline">{rec.difficulty}</Badge>
                          </div>
                        </div>

                        <div className={styles.recommendationStats}>
                          <div className={styles.statItem}>
                            <TrendingUp size={16} />
                            <span>Trending Score: {rec.trendingScore}/100</span>
                          </div>
                          <div className={styles.statItem}>
                            <DollarSign size={16} />
                            <span>+{rec.averageSalaryImpact}% avg salary increase</span>
                          </div>
                          <div className={styles.statItem}>
                            <Clock size={16} />
                            <span>{rec.timeToLearn} to learn</span>
                          </div>
                        </div>

                        {rec.relatedToCurrentSkills.length > 0 && (
                          <div className={styles.relatedSkills}>
                            <span className={styles.relatedLabel}>Builds on:</span>
                            {rec.relatedToCurrentSkills.map((skill: string) => (
                              <Badge key={skill} variant="secondary" className={styles.relatedBadge}>
                                {skill}
                              </Badge>
                            ))}
                          </div>
                        )}

                        <div className={styles.resources}>
                          <span className={styles.resourcesLabel}>
                            <GraduationCap size={16} />
                            Learning Resources
                          </span>
                          <div className={styles.resourcesList}>
                            {rec.resources.map((resource: any, ridx: number) => (
                              <a
                                key={ridx}
                                href={resource.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className={styles.resourceLink}
                              >
                                <Badge variant="outline">
                                  {resource.platform}
                                  {resource.isFree && ' (Free)'}
                                </Badge>
                                <ExternalLink size={14} />
                              </a>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Job Matches Tab */}
          <TabsContent value="jobs" className={styles.tabContent}>
            <Card>
              <CardHeader>
                <CardTitle className={styles.cardTitleWithIcon}>
                  <Briefcase size={24} />
                  Smart Job Matches
                </CardTitle>
                <CardDescription>
                  AI-matched opportunities based on your verified skills and experience
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className={styles.jobsList}>
                  {jobMatches.map((match) => (
                    <div key={match.job.id} className={styles.jobCard}>
                      <div className={styles.jobHeader}>
                        <div>
                          <h3 className={styles.jobTitle}>{match.job.title}</h3>
                          <div className={styles.jobCompany}>
                            <span>{match.job.company}</span>
                            {match.job.remote && (
                              <Badge variant="outline">Remote</Badge>
                            )}
                          </div>
                        </div>
                        <div className={styles.matchScore} style={{ 
                          background: `linear-gradient(135deg, ${getMatchColor(match.matchScore)}, ${getMatchColor(match.matchScore)}dd)`
                        }}>
                          <span className={styles.matchScoreValue}>{match.matchScore}%</span>
                          <span className={styles.matchScoreLabel}>Match</span>
                        </div>
                      </div>

                      <div className={styles.jobMeta}>
                        <span className={styles.metaItem}>
                          <MapPin size={14} />
                          {match.job.location}
                        </span>
                        <span className={styles.metaItem}>
                          <DollarSign size={14} />
                          ${match.job.salary.min.toLocaleString()} - ${match.job.salary.max.toLocaleString()}
                        </span>
                        <span className={styles.metaItem}>
                          <Calendar size={14} />
                          {match.job.experience.min}-{match.job.experience.max} years
                        </span>
                      </div>

                      <div className={styles.matchBreakdown}>
                        <div className={styles.breakdownItem}>
                          <span>Skills</span>
                          <Progress value={match.breakdown.skillsMatch} />
                          <span>{match.breakdown.skillsMatch}%</span>
                        </div>
                        <div className={styles.breakdownItem}>
                          <span>Experience</span>
                          <Progress value={match.breakdown.experienceMatch} />
                          <span>{match.breakdown.experienceMatch}%</span>
                        </div>
                      </div>

                      {match.strengths.length > 0 && (
                        <div className={styles.strengths}>
                          <span className={styles.strengthsLabel}>
                            <CheckCircle2 size={14} />
                            Your Strengths:
                          </span>
                          <div className={styles.strengthsList}>
                            {match.strengths.slice(0, 3).map((strength: string, idx: number) => (
                              <Badge key={idx} variant="secondary">{strength}</Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {match.gaps.length > 0 && (
                        <div className={styles.gaps}>
                          <span className={styles.gapsLabel}>
                            <AlertCircle size={14} />
                            Skill Gaps:
                          </span>
                          <div className={styles.gapsList}>
                            {match.gaps.slice(0, 3).map((gap: any, idx: number) => (
                              <Badge key={idx} variant="outline">
                                {gap.skill} ({gap.timeToLearn})
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      <div className={styles.jobActions}>
                        <Button variant="default">
                          Apply Now
                        </Button>
                        <Button variant="outline">
                          Save for Later
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Resume Builder Tab */}
          <TabsContent value="resume" className={styles.tabContent}>
            <Card>
              <CardHeader>
                <CardTitle className={styles.cardTitleWithIcon}>
                  <FileText size={24} />
                  AI Resume Builder
                </CardTitle>
                <CardDescription>
                  Auto-generated professional resume from your verified profile data
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className={styles.resumeBuilder}>
                  <div className={styles.resumeTemplates}>
                    <h3 className={styles.sectionSubtitle}>Choose Template</h3>
                    <div className={styles.templateGrid}>
                      {['modern', 'classic', 'minimal', 'technical'].map((template) => (
                        <div key={template} className={styles.templateCard}>
                          <div className={styles.templatePreview}>
                            <FileText size={48} />
                          </div>
                          <div className={styles.templateName}>{template}</div>
                          <Button variant="outline" size="sm">Select</Button>
                        </div>
                      ))}
                    </div>
                  </div>

                  {resumeData && (
                    <div className={styles.resumePreview}>
                      <h3 className={styles.sectionSubtitle}>Resume Preview</h3>
                      <div className={styles.resumeContent}>
                        <div className={styles.resumeSection}>
                          <h4>{resumeData.personalInfo.name}</h4>
                          <p>{resumeData.personalInfo.title}</p>
                          <p>{resumeData.summary}</p>
                        </div>

                        <div className={styles.resumeSection}>
                          <h4>Skills</h4>
                          {resumeData.skills.map((category: any, idx: number) => (
                            <div key={idx}>
                              <strong>{category.category}:</strong>
                              <span> {category.skills.join(', ')}</span>
                            </div>
                          ))}
                        </div>

                        <div className={styles.resumeSection}>
                          <h4>Achievements</h4>
                          {resumeData.achievements.slice(0, 3).map((achievement: any, idx: number) => (
                            <div key={idx}>
                              <strong>{achievement.title}</strong>
                              <p>{achievement.description}</p>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className={styles.resumeActions}>
                        <Button variant="default">
                          <Download size={18} />
                          Download PDF
                        </Button>
                        <Button variant="outline">
                          <Download size={18} />
                          Download DOCX
                        </Button>
                        <Button variant="outline">
                          Optimize for ATS
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
