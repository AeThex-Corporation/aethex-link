import type { Route } from './+types/teams';
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '~/components/ui/card/card';
import { Button } from '~/components/ui/button/button';
import { Input } from '~/components/ui/input/input';
import { Label } from '~/components/ui/label/label';
import { Textarea } from '~/components/ui/textarea/textarea';
import { Badge } from '~/components/ui/badge/badge';
import { Avatar, AvatarFallback, AvatarImage } from '~/components/ui/avatar/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '~/components/ui/dialog/dialog';
import { useToast } from '~/hooks/use-toast';
import { api } from '~/lib/api.client';
import { Users, Plus, UserPlus, Settings, LogOut, Trash2 } from 'lucide-react';
import styles from './teams.module.css';

export default function Teams({}: Route.ComponentProps) {
  const [teams, setTeams] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadTeams();
  }, []);

  const loadTeams = async () => {
    try {
      const response = await fetch('/api/teams');
      const data = await response.json();
      setTeams(data.teams || []);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to load teams',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const leaveTeam = async (teamId: string) => {
    if (!confirm('Are you sure you want to leave this team?')) return;

    try {
      await api.request('/api/teams', {
        method: 'POST',
        body: JSON.stringify({ action: 'leave', teamId }),
      });

      toast({
        title: 'Success',
        description: 'Left team successfully',
      });

      loadTeams();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to leave team',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <div className={styles.headerContent}>
          <div className={styles.headerText}>
            <h1 className={styles.title}>
              <Users size={32} />
              Teams
            </h1>
            <p className={styles.subtitle}>
              Collaborate with other creators and developers
            </p>
          </div>

          <CreateTeamDialog onSuccess={loadTeams} />
        </div>
      </div>

      <div className={styles.content}>
        {loading ? (
          <div className={styles.loading}>Loading teams...</div>
        ) : teams.length === 0 ? (
          <Card>
            <CardContent className={styles.empty}>
              <Users size={48} />
              <p>You haven't joined any teams yet</p>
              <CreateTeamDialog onSuccess={loadTeams} />
            </CardContent>
          </Card>
        ) : (
          <div className={styles.teams}>
            {teams.map(team => (
              <Card key={team.id} className={styles.teamCard}>
                <CardHeader>
                  <div className={styles.cardHeader}>
                    <div>
                      <CardTitle>{team.name}</CardTitle>
                      {team.description && (
                        <CardDescription>{team.description}</CardDescription>
                      )}
                    </div>
                    <Badge>{team.role}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className={styles.members}>
                    <h3 className={styles.membersTitle}>
                      Members ({team.members?.length || 0})
                    </h3>
                    <div className={styles.membersList}>
                      {team.members?.slice(0, 5).map((member: any) => (
                        <div key={member.id} className={styles.member}>
                          <Avatar className={styles.memberAvatar}>
                            <AvatarImage src={member.user?.avatar} alt={member.user?.name} />
                            <AvatarFallback>{member.user?.name?.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div className={styles.memberInfo}>
                            <p className={styles.memberName}>{member.user?.name}</p>
                            <p className={styles.memberRole}>{member.role}</p>
                          </div>
                        </div>
                      ))}
                      {team.members?.length > 5 && (
                        <p className={styles.moreMembers}>
                          +{team.members.length - 5} more
                        </p>
                      )}
                    </div>
                  </div>

                  <div className={styles.actions}>
                    {(team.role === 'owner' || team.role === 'admin') && (
                      <>
                        <Button variant="outline" size="sm">
                          <UserPlus size={16} />
                          Invite Member
                        </Button>
                        <Button variant="outline" size="sm">
                          <Settings size={16} />
                          Settings
                        </Button>
                      </>
                    )}
                    {team.role !== 'owner' && (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => leaveTeam(team.id)}
                      >
                        <LogOut size={16} />
                        Leave Team
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function CreateTeamDialog({ onSuccess }: { onSuccess: () => void }) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      await api.request('/api/teams', {
        method: 'POST',
        body: JSON.stringify({
          action: 'create',
          name,
          description,
        }),
      });

      toast({
        title: 'Success',
        description: 'Team created successfully!',
      });

      setOpen(false);
      setName('');
      setDescription('');
      onSuccess();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to create team',
        variant: 'destructive',
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus size={18} />
          Create Team
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create New Team</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className={styles.form}>
          <div className={styles.formField}>
            <Label htmlFor="name">Team Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Awesome Team"
              required
            />
          </div>

          <div className={styles.formField}>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What does your team do?"
              rows={3}
            />
          </div>

          <Button type="submit">Create Team</Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
