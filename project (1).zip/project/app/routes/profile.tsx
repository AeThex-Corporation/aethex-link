import { useState, useEffect } from 'react';
import type { Route } from './+types/profile';
import { Header } from '~/components/header/header';
import { Badge } from '~/components/ui/badge/badge';
import { DomainBadge } from '~/components/domain-badge/domain-badge';
import { Button } from '~/components/ui/button/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '~/components/ui/tabs/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '~/components/ui/card/card';
import { Progress } from '~/components/ui/progress/progress';
import { Separator } from '~/components/ui/separator/separator';
import { 
  Shield, 
  Github, 
  MessageSquare, 
  FileText, 
  TrendingUp, 
  TrendingDown,
  Minus,
  ExternalLink,
  MapPin,
  Calendar,
  Award,
  GitPullRequest,
  GitCommit,
  MessageCircle,
  CheckCircle2,
  Eye,
  Star,
  Zap,
  Trophy,
  Target,
  Activity,
  Code2,
  Sparkles,
  Flame,
  Rocket,
  Brain,
  Globe
} from 'lucide-react';
import { mockProfile } from '~/data/mock-profile-data';
import { AnimatedCounter } from '~/components/animated-counter/animated-counter';
import { GradientText } from '~/components/gradient-text/gradient-text';
import { CardSpotlight } from '~/components/card-spotlight/card-spotlight';
import { FloatingShapes } from '~/components/floating-shapes/floating-shapes';
import { ProfileEditor } from '~/components/profile-editor/profile-editor';
import { useAuth } from '~/hooks/use-auth';
import { useNavigate } from 'react-router';
import styles from './profile.module.css';

export function meta({}: Route.MetaArgs) {
  return [
    { title: `Profile - CreatorHub` },
    { name: 'description', content: `Multi-platform verified creator profile` },
  ];
}

export default function Profile() {
  const [activeTab, setActiveTab] = useState('overview');
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isVisible, setIsVisible] = useState(false);
  const { user, loading, refreshUser } = useAuth();
  const navigate = useNavigate();
  
  // Redirect to auth if not logged in
  useEffect(() => {
    if (!loading && !user) {
      navigate('/auth');
    }
  }, [user, loading, navigate]);

  // Use mock profile for display, but replace user data with actual user when available
  const profile = user ? {
    ...mockProfile,
    name: user.name,
    username: user.username,
    avatar: user.avatar || mockProfile.avatar,
    bio: user.bio || mockProfile.bio,
    location: user.location || mockProfile.location,
    title: user.title || mockProfile.title,
  } : mockProfile;

  useEffect(() => {
    setIsVisible(true);
    
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // Calculate skill level color
  const getSkillColor = (level: number) => {
    if (level >= 90) return 'var(--color-accent-9)';
    if (level >= 70) return 'var(--color-success-9)';
    return 'var(--color-neutral-9)';
  };

  if (loading) {
    return (
      <div className={styles.page}>
        <Header isAuthenticated={false} />
        <div className={styles.loading}>Loading...</div>
      </div>
    );
  }

  return (
    <div className={styles.page}>
      <Header isAuthenticated={!!user} />
      <FloatingShapes />
      
      <div 
        className={styles.cursorGlow}
        style={{
          left: `${mousePosition.x}px`,
          top: `${mousePosition.y}px`,
        }}
      />

      <div className={styles.container}>
        {/* Hero Profile Section */}
        <div className={`${styles.profileHero} ${isVisible ? styles.visible : ''}`}>
          <div className={styles.profileHeroBackground}>
            <div className={styles.heroGradient1} />
            <div className={styles.heroGradient2} />
            <div className={styles.heroGradient3} />
            <div className={styles.heroGrid} />
          </div>

          <div className={styles.profileHeroContent}>
            <div className={styles.profileAvatarWrapper}>
              <div className={styles.avatarOrbit}>
                <div className={styles.orbitRing} />
                <div className={styles.orbitRing} />
                <div className={styles.orbitRing} />
              </div>
              <div className={styles.avatarGlow} />
              <img 
                src={profile.avatar} 
                alt={profile.name}
                className={styles.profileAvatar}
              />
              {profile.verified && (
                <div className={styles.verifiedBadge}>
                  <Shield size={20} />
                  <div className={styles.verifiedPulse} />
                </div>
              )}
              <div className={styles.levelBadge}>
                <Trophy size={16} />
                <span>Lvl 99</span>
              </div>
            </div>
            
            <div className={styles.profileHeroInfo}>
              <div className={styles.statusBadge}>
                <div className={styles.statusDot} />
                <span>Available for opportunities</span>
              </div>
              
              <h1 className={styles.profileHeroName}>
                <GradientText>{profile.name}</GradientText>
              </h1>
              
              <div className={styles.usernames}>
                <span className={styles.profileUsername}>@{profile.username}</span>
                <DomainBadge domain={`${profile.username}.aethex`} verified={true} size="sm" />
              </div>
              
              <p className={styles.profileHeroTitle}>
                <Sparkles size={18} />
                {profile.title}
              </p>
              
              <div className={styles.profileMeta}>
                <div className={styles.profileMetaItem}>
                  <MapPin size={16} />
                  <span>{profile.location}</span>
                </div>
                <div className={styles.profileMetaItem}>
                  <Calendar size={16} />
                  <span>Joined {new Date(profile.joinedDate).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</span>
                </div>
                <div className={styles.profileMetaItem}>
                  <Globe size={16} />
                  <span>Remote Worldwide</span>
                </div>
              </div>
              
              <p className={styles.profileBio}>{profile.bio}</p>
              
              <div className={styles.profileActions}>
                {user && (
                  <ProfileEditor 
                    user={{
                      name: user.name,
                      bio: user.bio,
                      location: user.location,
                      title: user.title,
                      avatar: user.avatar,
                    }}
                    onUpdate={refreshUser}
                  />
                )}
                <Button variant="default" className={styles.primaryCTA}>
                  <Rocket size={18} />
                  Hire Me
                </Button>
                <Button variant="outline">
                  <ExternalLink size={18} />
                  View Resume
                </Button>
              </div>
            </div>
          </div>

          {/* Impact Score */}
          <div className={styles.impactScore}>
            <div className={styles.impactScoreContent}>
              <div className={styles.impactScoreIcon}>
                <Flame size={32} />
              </div>
              <div className={styles.impactScoreText}>
                <div className={styles.impactScoreLabel}>Developer Impact Score</div>
                <div className={styles.impactScoreValue}>
                  <AnimatedCounter end={9847} duration={2000} />
                </div>
                <div className={styles.impactScoreRank}>Top 1% Worldwide</div>
              </div>
            </div>
            <div className={styles.impactScoreBar}>
              <div className={styles.impactScoreProgress} />
            </div>
          </div>
        </div>

        {/* Super Stats Grid */}
        <div className={styles.superStatsGrid}>
          <CardSpotlight className={styles.superStatCard}>
            <div className={styles.superStatIcon}>
              <Github size={40} />
            </div>
            <div className={styles.superStatContent}>
              <div className={styles.superStatValue}>
                <AnimatedCounter end={profile.stats.totalContributions} duration={2000} />
              </div>
              <div className={styles.superStatLabel}>GitHub Contributions</div>
              <div className={styles.superStatChange}>
                <TrendingUp size={14} />
                <span>+23% this month</span>
              </div>
            </div>
            <div className={styles.superStatSparkline}>
              {[65, 72, 68, 85, 92, 88, 95, 100].map((height, i) => (
                <div 
                  key={i} 
                  className={styles.sparklineBar}
                  style={{ height: `${height}%`, animationDelay: `${i * 0.1}s` }}
                />
              ))}
            </div>
          </CardSpotlight>
          
          <CardSpotlight className={styles.superStatCard}>
            <div className={styles.superStatIcon}>
              <MessageSquare size={40} />
            </div>
            <div className={styles.superStatContent}>
              <div className={styles.superStatValue}>
                <AnimatedCounter end={profile.stats.stackOverflowReputation} duration={2000} />
              </div>
              <div className={styles.superStatLabel}>Stack Overflow Rep</div>
              <div className={styles.superStatChange}>
                <TrendingUp size={14} />
                <span>+412 this week</span>
              </div>
            </div>
            <div className={styles.superStatRank}>
              <Star size={16} />
              <span>Top 5%</span>
            </div>
          </CardSpotlight>
          
          <CardSpotlight className={styles.superStatCard}>
            <div className={styles.superStatIcon}>
              <FileText size={40} />
            </div>
            <div className={styles.superStatContent}>
              <div className={styles.superStatValue}>
                <AnimatedCounter end={profile.stats.blogPosts} duration={1500} />
              </div>
              <div className={styles.superStatLabel}>Technical Articles</div>
              <div className={styles.superStatChange}>
                <Eye size={14} />
                <span>2.4M total views</span>
              </div>
            </div>
            <div className={styles.superStatTrending}>
              <Zap size={16} />
              <span>Trending Author</span>
            </div>
          </CardSpotlight>
          
          <CardSpotlight className={styles.superStatCard}>
            <div className={styles.superStatIcon}>
              <Code2 size={40} />
            </div>
            <div className={styles.superStatContent}>
              <div className={styles.superStatValue}>
                <AnimatedCounter end={profile.stats.yearsOfExperience} duration={1500} />
                <span className={styles.superStatSuffix}>+</span>
              </div>
              <div className={styles.superStatLabel}>Years Experience</div>
              <div className={styles.superStatChange}>
                <Brain size={14} />
                <span>15+ technologies mastered</span>
              </div>
            </div>
            <div className={styles.superStatBadges}>
              <Award size={16} />
              <Award size={16} />
              <Award size={16} />
            </div>
          </CardSpotlight>
        </div>

        {/* Achievement Showcase */}
        <div className={styles.achievementShowcase}>
          <h2 className={styles.sectionTitle}>
            <Trophy size={24} />
            <GradientText>Achievements Unlocked</GradientText>
          </h2>
          <div className={styles.achievementGrid}>
            {[
              { icon: <Star />, name: 'Elite Contributor', desc: '1000+ contributions', rarity: 'legendary' },
              { icon: <Zap />, name: 'Fast Responder', desc: 'Top 1% response time', rarity: 'epic' },
              { icon: <Target />, name: 'Problem Solver', desc: '500+ solutions', rarity: 'epic' },
              { icon: <Flame />, name: 'Streak Master', desc: '365 day streak', rarity: 'legendary' },
              { icon: <Brain />, name: 'Code Mentor', desc: 'Helped 10K+ developers', rarity: 'rare' },
              { icon: <Rocket />, name: 'Innovation Leader', desc: 'Created 50+ projects', rarity: 'epic' }
            ].map((achievement, i) => (
              <div 
                key={i} 
                className={`${styles.achievementCard} ${styles[achievement.rarity]}`}
                style={{ animationDelay: `${i * 0.1}s` }}
              >
                <div className={styles.achievementIcon}>
                  {achievement.icon}
                </div>
                <div className={styles.achievementContent}>
                  <div className={styles.achievementName}>{achievement.name}</div>
                  <div className={styles.achievementDesc}>{achievement.desc}</div>
                </div>
                <div className={styles.achievementGlow} />
              </div>
            ))}
          </div>
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className={styles.tabs}>
          <TabsList className={styles.tabsList}>
            <TabsTrigger value="overview">
              <Activity size={16} />
              Overview
            </TabsTrigger>
            <TabsTrigger value="skills">
              <Brain size={16} />
              Skills Matrix
            </TabsTrigger>
            <TabsTrigger value="github">
              <Github size={16} />
              GitHub
            </TabsTrigger>
            <TabsTrigger value="stackoverflow">
              <MessageSquare size={16} />
              Stack Overflow
            </TabsTrigger>
            <TabsTrigger value="blog">
              <FileText size={16} />
              Articles
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className={styles.tabContent}>
            <div className={styles.overviewGrid}>
              {/* Top Skills with 3D Effect */}
              <Card className={styles.skillsCard}>
                <CardHeader>
                  <CardTitle className={styles.cardTitleWithIcon}>
                    <Zap size={20} />
                    Top Verified Skills
                  </CardTitle>
                  <CardDescription>Skills backed by real contributions across platforms</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className={styles.skillsList}>
                    {profile.skills.slice(0, 5).map((skill, index) => (
                      <div 
                        key={skill.name} 
                        className={styles.skillItem3D}
                        style={{ animationDelay: `${index * 0.1}s` }}
                      >
                        <div className={styles.skillHeader}>
                          <div className={styles.skillName}>
                            <div className={styles.skillIcon} style={{ background: getSkillColor(skill.level) }}>
                              <Code2 size={16} />
                            </div>
                            <span>{skill.name}</span>
                            {skill.verified && <Shield size={14} className={styles.skillVerified} />}
                          </div>
                          <div className={styles.skillLevel}>
                            <span className={styles.skillLevelValue}>{skill.level}%</span>
                            {skill.trend === 'up' && <TrendingUp size={14} className={styles.trendUp} />}
                            {skill.trend === 'down' && <TrendingDown size={14} className={styles.trendDown} />}
                            {skill.trend === 'stable' && <Minus size={14} className={styles.trendStable} />}
                          </div>
                        </div>
                        <div className={styles.skillProgressWrapper}>
                          <Progress value={skill.level} className={styles.skillProgress} />
                          <div 
                            className={styles.skillProgressGlow}
                            style={{ width: `${skill.level}%` }}
                          />
                        </div>
                        <div className={styles.skillSources}>
                          <div className={styles.skillSource}>
                            <Github size={12} />
                            <span>{skill.sources.github}</span>
                          </div>
                          <div className={styles.skillSource}>
                            <MessageSquare size={12} />
                            <span>{skill.sources.stackoverflow}</span>
                          </div>
                          <div className={styles.skillSource}>
                            <FileText size={12} />
                            <span>{skill.sources.blog}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Recent Activity with Timeline */}
              <Card className={styles.activityCard}>
                <CardHeader>
                  <CardTitle className={styles.cardTitleWithIcon}>
                    <Activity size={20} />
                    Recent Activity
                  </CardTitle>
                  <CardDescription>Latest verified contributions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className={styles.activityTimeline}>
                    {profile.recentGitHubActivity.slice(0, 4).map((activity, index) => (
                      <div 
                        key={activity.id} 
                        className={styles.timelineItem}
                        style={{ animationDelay: `${index * 0.15}s` }}
                      >
                        <div className={styles.timelineDot}>
                          <div className={styles.timelineDotInner} />
                        </div>
                        <div className={styles.timelineContent}>
                          <div className={styles.activityType}>
                            {activity.type === 'pr' && <GitPullRequest size={16} />}
                            {activity.type === 'commit' && <GitCommit size={16} />}
                            {activity.type === 'review' && <MessageCircle size={16} />}
                            {activity.type === 'issue' && <MessageSquare size={16} />}
                            <span>{activity.type.toUpperCase()}</span>
                            <Badge variant={activity.impact === 'high' ? 'default' : 'outline'}>
                              {activity.impact}
                            </Badge>
                          </div>
                          <div className={styles.activityTitle}>{activity.title}</div>
                          <div className={styles.activityMeta}>
                            <span className={styles.activityRepo}>
                              <Github size={12} />
                              {activity.repository}
                            </span>
                            <span className={styles.activityDate}>
                              {new Date(activity.date).toLocaleDateString()}
                            </span>
                          </div>
                          <div className={styles.activityLanguages}>
                            {activity.languages.map((lang) => (
                              <Badge key={lang} variant="secondary">
                                {lang}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Skills Tab */}
          <TabsContent value="skills" className={styles.tabContent}>
            <Card>
              <CardHeader>
                <CardTitle className={styles.cardTitleWithIcon}>
                  <Brain size={24} />
                  Complete Skills Matrix
                </CardTitle>
                <CardDescription>
                  All skills verified across GitHub, Stack Overflow, and Blog platforms
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className={styles.skillsMatrix}>
                  {profile.skills.map((skill, index) => (
                    <div 
                      key={skill.name} 
                      className={styles.skillMatrixItem}
                      style={{ animationDelay: `${index * 0.05}s` }}
                    >
                      <div className={styles.skillMatrixHeader}>
                        <div className={styles.skillMatrixName}>
                          <div 
                            className={styles.skillMatrixIcon}
                            style={{ background: getSkillColor(skill.level) }}
                          >
                            <Code2 size={18} />
                          </div>
                          <span>{skill.name}</span>
                          <Badge variant="outline" className={styles.skillCategory}>
                            {skill.category}
                          </Badge>
                        </div>
                        <div className={styles.skillMatrixLevel}>
                          {skill.trend === 'up' && <TrendingUp size={16} className={styles.trendUp} />}
                          {skill.trend === 'down' && <TrendingDown size={16} className={styles.trendDown} />}
                          {skill.trend === 'stable' && <Minus size={16} className={styles.trendStable} />}
                          <span className={styles.skillLevelValue}>{skill.level}%</span>
                        </div>
                      </div>
                      <div className={styles.skillProgressWrapper}>
                        <Progress value={skill.level} className={styles.skillMatrixProgress} />
                        <div 
                          className={styles.skillProgressGlow}
                          style={{ width: `${skill.level}%` }}
                        />
                      </div>
                      <div className={styles.skillMatrixSources}>
                        <div className={styles.sourceItem}>
                          <Github size={14} />
                          <span>{skill.sources.github} contributions</span>
                        </div>
                        <div className={styles.sourceItem}>
                          <MessageSquare size={14} />
                          <span>{skill.sources.stackoverflow} answers</span>
                        </div>
                        <div className={styles.sourceItem}>
                          <FileText size={14} />
                          <span>{skill.sources.blog} articles</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* GitHub Tab */}
          <TabsContent value="github" className={styles.tabContent}>
            <Card>
              <CardHeader>
                <CardTitle className={styles.cardTitleWithIcon}>
                  <Github size={24} />
                  GitHub Contributions
                </CardTitle>
                <CardDescription>Verified open source contributions and projects</CardDescription>
              </CardHeader>
              <CardContent>
                <div className={styles.githubActivityList}>
                  {profile.recentGitHubActivity.map((activity, index) => (
                    <div 
                      key={activity.id} 
                      className={styles.githubActivityItem}
                      style={{ animationDelay: `${index * 0.1}s` }}
                    >
                      <div className={styles.githubActivityHeader}>
                        <div className={styles.githubActivityType}>
                          {activity.type === 'pr' && <GitPullRequest size={20} />}
                          {activity.type === 'commit' && <GitCommit size={20} />}
                          {activity.type === 'review' && <MessageCircle size={20} />}
                          {activity.type === 'issue' && <MessageSquare size={20} />}
                          <span className={styles.githubActivityTypeLabel}>{activity.type.toUpperCase()}</span>
                        </div>
                        <Badge variant={activity.impact === 'high' ? 'default' : 'outline'}>
                          {activity.impact} impact
                        </Badge>
                      </div>
                      
                      <h3 className={styles.githubActivityTitle}>{activity.title}</h3>
                      
                      <div className={styles.githubActivityMeta}>
                        <span className={styles.githubActivityRepo}>
                          <Github size={14} />
                          {activity.repository}
                        </span>
                        <span className={styles.githubActivityDate}>
                          {new Date(activity.date).toLocaleDateString('en-US', { 
                            month: 'long', 
                            day: 'numeric', 
                            year: 'numeric' 
                          })}
                        </span>
                      </div>
                      
                      {(activity.linesAdded > 0 || activity.linesRemoved > 0) && (
                        <div className={styles.githubActivityStats}>
                          <span className={styles.linesAdded}>+{activity.linesAdded}</span>
                          <span className={styles.linesRemoved}>-{activity.linesRemoved}</span>
                        </div>
                      )}
                      
                      <div className={styles.githubActivityLanguages}>
                        {activity.languages.map((lang) => (
                          <Badge key={lang} variant="secondary">{lang}</Badge>
                        ))}
                        {activity.verified && (
                          <div className={styles.verifiedIndicator}>
                            <CheckCircle2 size={14} />
                            <span>Verified</span>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Stack Overflow Tab */}
          <TabsContent value="stackoverflow" className={styles.tabContent}>
            <Card>
              <CardHeader>
                <CardTitle className={styles.cardTitleWithIcon}>
                  <MessageSquare size={24} />
                  Stack Overflow Activity
                </CardTitle>
                <CardDescription>Community contributions and expertise demonstrations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className={styles.stackOverflowList}>
                  {profile.stackOverflowActivity.map((activity, index) => (
                    <div 
                      key={activity.id} 
                      className={styles.stackOverflowItem}
                      style={{ animationDelay: `${index * 0.1}s` }}
                    >
                      <div className={styles.stackOverflowHeader}>
                        <Badge variant={activity.type === 'answer' ? 'default' : 'outline'}>
                          {activity.type}
                        </Badge>
                        {activity.accepted && (
                          <div className={styles.acceptedAnswer}>
                            <CheckCircle2 size={14} />
                            <span>Accepted</span>
                          </div>
                        )}
                      </div>
                      
                      <h3 className={styles.stackOverflowTitle}>{activity.title}</h3>
                      
                      <div className={styles.stackOverflowStats}>
                        <div className={styles.stackOverflowScore}>
                          <TrendingUp size={16} />
                          <span>{activity.score} score</span>
                        </div>
                        <div className={styles.stackOverflowViews}>
                          <Eye size={16} />
                          <span>{activity.views.toLocaleString()} views</span>
                        </div>
                        <span className={styles.stackOverflowDate}>
                          {new Date(activity.date).toLocaleDateString()}
                        </span>
                      </div>
                      
                      <div className={styles.stackOverflowTags}>
                        {activity.tags.map((tag) => (
                          <Badge key={tag} variant="secondary">{tag}</Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Blog Tab */}
          <TabsContent value="blog" className={styles.tabContent}>
            <Card>
              <CardHeader>
                <CardTitle className={styles.cardTitleWithIcon}>
                  <FileText size={24} />
                  Blog Posts & Articles
                </CardTitle>
                <CardDescription>Technical writing and knowledge sharing</CardDescription>
              </CardHeader>
              <CardContent>
                <div className={styles.blogPostsList}>
                  {profile.blogPosts.map((post, index) => (
                    <div 
                      key={post.id} 
                      className={styles.blogPostItem}
                      style={{ animationDelay: `${index * 0.1}s` }}
                    >
                      <div className={styles.blogPostHeader}>
                        <h3 className={styles.blogPostTitle}>{post.title}</h3>
                        <Button variant="outline" size="sm" asChild>
                          <a href={post.url} target="_blank" rel="noopener noreferrer">
                            <ExternalLink size={16} />
                          </a>
                        </Button>
                      </div>
                      
                      <div className={styles.blogPostMeta}>
                        <Badge variant="outline">{post.platform}</Badge>
                        <span className={styles.blogPostDate}>
                          {new Date(post.publishedDate).toLocaleDateString('en-US', {
                            month: 'long',
                            day: 'numeric',
                            year: 'numeric'
                          })}
                        </span>
                      </div>
                      
                      <div className={styles.blogPostStats}>
                        <div className={styles.blogPostStat}>
                          <Eye size={14} />
                          <span>{post.views.toLocaleString()} views</span>
                        </div>
                        <div className={styles.blogPostStat}>
                          <TrendingUp size={14} />
                          <span>{post.engagement} engagements</span>
                        </div>
                      </div>
                      
                      <div className={styles.blogPostTopics}>
                        {post.topics.map((topic) => (
                          <Badge key={topic} variant="secondary">{topic}</Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
