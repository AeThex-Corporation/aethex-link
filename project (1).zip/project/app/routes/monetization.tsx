import { useState, useEffect } from 'react';
import { Header } from '~/components/header/header';
import { RevenueDashboard } from '~/components/revenue-dashboard/revenue-dashboard';
import { LoadingState } from '~/components/loading-state/loading-state';
import { ErrorState } from '~/components/error-state/error-state';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '~/components/ui/card/card';
import { Button } from '~/components/ui/button/button';
import { Badge } from '~/components/ui/badge/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '~/components/ui/tabs/tabs';
import { DollarSign, CreditCard, FileText, TrendingUp } from 'lucide-react';
import styles from './monetization.module.css';

export function meta() {
  return [
    { title: 'Monetization - CreatorHub' },
    { name: 'description', content: 'Track earnings and revenue across all platforms' },
  ];
}

export default function Monetization() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [revenueData, setRevenueData] = useState<any>(null);

  useEffect(() => {
    fetchRevenueData();
  }, []);

  const fetchRevenueData = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/revenue');
      
      if (!response.ok) {
        throw new Error('Failed to fetch revenue data');
      }

      const data = await response.json();
      setRevenueData(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const generateTaxDocument = async () => {
    try {
      const year = new Date().getFullYear();
      const response = await fetch('/api/revenue', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'generate-tax-document', year }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate tax document');
      }

      const data = await response.json();
      
      // In production, this would download or email the document
      alert(`Tax document for ${year} generated successfully!`);
    } catch (err: any) {
      alert(`Error: ${err.message}`);
    }
  };

  if (loading) {
    return (
      <div className={styles.page}>
        <Header isAuthenticated={true} />
        <div className={styles.container}>
          <LoadingState message="Loading revenue data..." />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={styles.page}>
        <Header isAuthenticated={true} />
        <div className={styles.container}>
          <ErrorState 
            message={error}
            onRetry={fetchRevenueData}
          />
        </div>
      </div>
    );
  }

  return (
    <div className={styles.page}>
      <Header isAuthenticated={true} />

      <div className={styles.container}>
        <div className={styles.header}>
          <div>
            <h1 className={styles.title}>Monetization Dashboard</h1>
            <p className={styles.subtitle}>Track your earnings across all platforms</p>
          </div>
          <Badge variant="outline" className={styles.proBadge}>
            <TrendingUp size={14} />
            Pro Feature
          </Badge>
        </div>

        <Tabs defaultValue="overview" className={styles.tabs}>
          <TabsList>
            <TabsTrigger value="overview">
              <DollarSign size={16} />
              Overview
            </TabsTrigger>
            <TabsTrigger value="payments">
              <CreditCard size={16} />
              Payment Methods
            </TabsTrigger>
            <TabsTrigger value="taxes">
              <FileText size={16} />
              Tax Documents
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className={styles.tabContent}>
            {revenueData && (
              <RevenueDashboard
                revenue={revenueData.revenue}
                milestones={revenueData.milestones}
              />
            )}
          </TabsContent>

          <TabsContent value="payments" className={styles.tabContent}>
            <Card>
              <CardHeader>
                <CardTitle>Payment Methods</CardTitle>
                <CardDescription>Recommended payment options based on your revenue</CardDescription>
              </CardHeader>
              <CardContent>
                <div className={styles.paymentMethods}>
                  {revenueData?.paymentMethods?.map((method: any, index: number) => (
                    <div key={index} className={styles.paymentMethod}>
                      <div className={styles.paymentMethodHeader}>
                        <h3 className={styles.paymentMethodName}>{method.method}</h3>
                        {method.recommended && (
                          <Badge variant="default">Recommended</Badge>
                        )}
                      </div>
                      <p className={styles.paymentMethodDescription}>{method.description}</p>
                      <p className={styles.paymentMethodMinRevenue}>
                        Min. Revenue: ${method.minRevenue.toLocaleString()}
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="taxes" className={styles.tabContent}>
            <Card>
              <CardHeader>
                <CardTitle>Tax Documents</CardTitle>
                <CardDescription>Generate tax documents for your earnings</CardDescription>
              </CardHeader>
              <CardContent>
                <div className={styles.taxSection}>
                  <p className={styles.taxDescription}>
                    Generate comprehensive tax documents that include earnings from all connected platforms.
                    These documents can be used for tax filing and financial planning.
                  </p>
                  
                  <Button onClick={generateTaxDocument}>
                    <FileText size={16} />
                    Generate {new Date().getFullYear()} Tax Document
                  </Button>

                  <div className={styles.taxNote}>
                    <p>
                      <strong>Note:</strong> Always consult with a tax professional for accurate tax advice.
                      These documents are for informational purposes only.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
