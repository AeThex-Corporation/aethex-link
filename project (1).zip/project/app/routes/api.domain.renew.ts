import type { ActionFunctionArgs } from 'react-router';
import { auth } from '~/lib/auth.server';
import { db } from '~/lib/db.server';
import { freenameAPI } from '~/lib/freename.server';

/**
 * Renew a .aethex domain
 * POST /api/domain/renew
 */
export async function action({ request }: ActionFunctionArgs) {
  // Require authentication
  const user = await auth.requireAuth(request);

  const body = await request.json();
  const { years = 1 } = body;

  if (years < 1 || years > 10) {
    return Response.json({ error: 'Years must be between 1 and 10' }, { status: 400 });
  }

  try {
    // Get user's domain
    const domainRecord = await db.domain.findByUserId(user.id);
    if (!domainRecord) {
      return Response.json({ error: 'No domain found for user' }, { status: 404 });
    }

    // Renew via Freename API
    const renewal = await freenameAPI.renewDomain(domainRecord.domain, years);

    // Update domain record
    await db.domain.update(domainRecord.domain, {
      expiryDate: renewal.newExpiryDate,
      status: 'active',
    });

    // Create transaction record
    await db.domainTransaction.create({
      userId: user.id,
      domain: domainRecord.domain,
      type: 'renewal',
      amount: renewal.price,
      currency: renewal.currency,
      status: 'completed',
    });

    return Response.json({
      success: true,
      renewal,
      newExpiryDate: renewal.newExpiryDate,
    });
  } catch (error: any) {
    console.error('Domain renewal failed:', error);
    return Response.json({
      error: error.message || 'Failed to renew domain',
    }, { status: 500 });
  }
}
