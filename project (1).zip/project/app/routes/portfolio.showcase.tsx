import { useState, useEffect } from 'react';
import { Header } from '~/components/header/header';
import { PortfolioShowcase } from '~/components/portfolio-showcase/portfolio-showcase';
import { LoadingState } from '~/components/loading-state/loading-state';
import { ErrorState } from '~/components/error-state/error-state';
import { Button } from '~/components/ui/button/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '~/components/ui/tabs/tabs';
import { Gamepad2, Brain, Code2, Plus } from 'lucide-react';
import styles from './portfolio.showcase.module.css';

export function meta() {
  return [
    { title: 'Portfolio Showcase - CreatorHub' },
    { name: 'description', content: 'Showcase your games, AI models, and projects' },
  ];
}

// Mock data for demonstration
const mockPortfolioItems = [
  {
    id: '1',
    type: 'game' as const,
    title: 'Obby Challenge',
    description: 'A challenging obstacle course game with over 100 unique levels',
    platform: 'Roblox',
    url: 'https://www.roblox.com/games/123456',
    thumbnailUrl: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=800&h=450&fit=crop',
    stats: {
      views: 2400000,
      likes: 45000,
      plays: 1200000,
      rating: 4.8,
    },
    tags: ['Obby', 'Adventure', 'Multiplayer', 'Platformer'],
    featured: true,
  },
  {
    id: '2',
    type: 'game' as const,
    title: 'Racing Legends',
    description: 'High-speed racing game with customizable vehicles',
    platform: 'Roblox',
    url: 'https://www.roblox.com/games/789012',
    thumbnailUrl: 'https://images.unsplash.com/photo-1511919884226-fd3cad34687c?w=800&h=450&fit=crop',
    stats: {
      views: 850000,
      likes: 12000,
      plays: 450000,
      rating: 4.6,
    },
    tags: ['Racing', 'Multiplayer', 'Competitive'],
    featured: false,
  },
  {
    id: '3',
    type: 'game' as const,
    title: 'Fantasy Quest',
    description: 'Epic RPG adventure built with Unity',
    platform: 'Steam',
    url: 'https://store.steampowered.com/app/12345',
    thumbnailUrl: 'https://images.unsplash.com/photo-1534423861386-85a16f5d13fd?w=800&h=450&fit=crop',
    stats: {
      views: 125000,
      downloads: 35000,
      rating: 4.9,
    },
    tags: ['RPG', 'Adventure', 'Singleplayer'],
    featured: true,
  },
  {
    id: '4',
    type: 'ai_model' as const,
    title: 'Sentiment Analyzer V2',
    description: 'Advanced sentiment analysis model for social media text',
    platform: 'Hugging Face',
    url: 'https://huggingface.co/username/sentiment-analyzer-v2',
    thumbnailUrl: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&h=450&fit=crop',
    stats: {
      downloads: 125000,
      likes: 2400,
    },
    tags: ['NLP', 'Sentiment Analysis', 'Transformers', 'PyTorch'],
    featured: true,
  },
  {
    id: '5',
    type: 'ai_model' as const,
    title: 'Image Classification Pro',
    description: 'High-accuracy image classification for 1000+ categories',
    platform: 'Hugging Face',
    url: 'https://huggingface.co/username/image-classifier-pro',
    thumbnailUrl: 'https://images.unsplash.com/photo-1655720828018-edd2daec9349?w=800&h=450&fit=crop',
    stats: {
      downloads: 87000,
      likes: 1850,
    },
    tags: ['Computer Vision', 'Classification', 'ResNet', 'TensorFlow'],
    featured: false,
  },
  {
    id: '6',
    type: 'asset' as const,
    title: 'Procedural Terrain Generator',
    description: 'Unity asset for generating realistic terrain procedurally',
    platform: 'Unity Asset Store',
    url: 'https://assetstore.unity.com/packages/12345',
    thumbnailUrl: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&h=450&fit=crop',
    stats: {
      downloads: 5400,
      rating: 4.7,
    },
    tags: ['Terrain', 'Procedural', 'Unity', 'Tool'],
    featured: false,
  },
];

export default function PortfolioShowcasePage() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [portfolioItems, setPortfolioItems] = useState(mockPortfolioItems);

  const fetchPortfolioItems = async () => {
    try {
      setLoading(true);
      // In production, fetch from API
      // const response = await fetch('/api/portfolio');
      // const data = await response.json();
      // setPortfolioItems(data.items);
      
      // For now, use mock data
      setPortfolioItems(mockPortfolioItems);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className={styles.page}>
        <Header isAuthenticated={true} />
        <div className={styles.container}>
          <LoadingState message="Loading portfolio..." />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className={styles.page}>
        <Header isAuthenticated={true} />
        <div className={styles.container}>
          <ErrorState 
            message={error}
            onRetry={fetchPortfolioItems}
          />
        </div>
      </div>
    );
  }

  return (
    <div className={styles.page}>
      <Header isAuthenticated={true} />

      <div className={styles.container}>
        <div className={styles.header}>
          <div>
            <h1 className={styles.title}>Portfolio Showcase</h1>
            <p className={styles.subtitle}>Your games, AI models, and creative projects</p>
          </div>
          <Button>
            <Plus size={16} />
            Add Project
          </Button>
        </div>

        <Tabs defaultValue="all" className={styles.tabs}>
          <TabsList>
            <TabsTrigger value="all">
              All Projects
            </TabsTrigger>
            <TabsTrigger value="game">
              <Gamepad2 size={16} />
              Games
            </TabsTrigger>
            <TabsTrigger value="ai_model">
              <Brain size={16} />
              AI Models
            </TabsTrigger>
            <TabsTrigger value="asset">
              <Code2 size={16} />
              Assets
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all" className={styles.tabContent}>
            <PortfolioShowcase items={portfolioItems} />
          </TabsContent>

          <TabsContent value="game" className={styles.tabContent}>
            <PortfolioShowcase items={portfolioItems} type="game" />
          </TabsContent>

          <TabsContent value="ai_model" className={styles.tabContent}>
            <PortfolioShowcase items={portfolioItems} type="ai_model" />
          </TabsContent>

          <TabsContent value="asset" className={styles.tabContent}>
            <PortfolioShowcase items={portfolioItems} type="asset" />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
