import type { Route } from './+types/social';
import { Header } from '~/components/header/header';
import { DeveloperFeed } from '~/components/developer-feed/developer-feed';
import { useAuth } from '~/hooks/use-auth';
import styles from './social.module.css';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '~/components/ui/tabs/tabs';
import { Card } from '~/components/ui/card/card';
import { Avatar } from '~/components/ui/avatar/avatar';
import { Button } from '~/components/ui/button/button';
import { Users, TrendingUp, Sparkles } from 'lucide-react';

export function meta({}: Route.MetaArgs) {
  return [
    { title: 'Social - CreatorHub' },
    { name: 'description', content: 'Connect with other creators' },
  ];
}

const suggestedCreators = [
  {
    id: '1',
    name: 'Maya Patel',
    username: 'mayapatel',
    avatar: 'https://i.pravatar.cc/150?img=3',
    title: 'Unity Developer',
    followers: 1200,
    platforms: ['Unity', 'GitHub'],
  },
  {
    id: '2',
    name: 'Chris Anderson',
    username: 'canderson',
    avatar: 'https://i.pravatar.cc/150?img=7',
    title: 'Roblox Creator',
    followers: 3400,
    platforms: ['Roblox', 'Lua'],
  },
  {
    id: '3',
    name: 'Emma Liu',
    username: 'emmaliu',
    avatar: 'https://i.pravatar.cc/150?img=9',
    title: 'AI Researcher',
    followers: 890,
    platforms: ['Hugging Face', 'Kaggle'],
  },
];

export default function Social() {
  const { user } = useAuth();

  return (
    <div className={styles.page}>
      <Header isAuthenticated={!!user} />
      
      <div className={styles.container}>
        <div className={styles.sidebar}>
          <Card className={styles.sidebarCard}>
            <div className={styles.sidebarHeader}>
              <Users className={styles.sidebarIcon} />
              <h3>Suggested Creators</h3>
            </div>
            
            <div className={styles.creatorsList}>
              {suggestedCreators.map(creator => (
                <div key={creator.id} className={styles.creatorItem}>
                  <Avatar
                    src={creator.avatar}
                    alt={creator.name}
                    fallback={creator.name[0]}
                    size="md"
                  />
                  <div className={styles.creatorInfo}>
                    <div className={styles.creatorName}>{creator.name}</div>
                    <div className={styles.creatorTitle}>{creator.title}</div>
                    <div className={styles.creatorStats}>
                      {creator.followers.toLocaleString()} followers
                    </div>
                  </div>
                  <Button size="sm" variant="outline">
                    Follow
                  </Button>
                </div>
              ))}
            </div>
          </Card>

          <Card className={styles.sidebarCard}>
            <div className={styles.sidebarHeader}>
              <TrendingUp className={styles.sidebarIcon} />
              <h3>Trending Topics</h3>
            </div>
            <div className={styles.trendingList}>
              <div className={styles.trendingItem}>
                <span className={styles.trendingTag}>#RobloxDev</span>
                <span className={styles.trendingCount}>234 posts</span>
              </div>
              <div className={styles.trendingItem}>
                <span className={styles.trendingTag}>#UnityTips</span>
                <span className={styles.trendingCount}>189 posts</span>
              </div>
              <div className={styles.trendingItem}>
                <span className={styles.trendingTag}>#AIModels</span>
                <span className={styles.trendingCount}>156 posts</span>
              </div>
              <div className={styles.trendingItem}>
                <span className={styles.trendingTag}>#GameDev</span>
                <span className={styles.trendingCount}>412 posts</span>
              </div>
            </div>
          </Card>
        </div>

        <div className={styles.main}>
          <Tabs defaultValue="feed" className={styles.tabs}>
            <TabsList>
              <TabsTrigger value="feed">
                <Sparkles />
                Feed
              </TabsTrigger>
              <TabsTrigger value="following">
                <Users />
                Following
              </TabsTrigger>
              <TabsTrigger value="trending">
                <TrendingUp />
                Trending
              </TabsTrigger>
            </TabsList>

            <TabsContent value="feed">
              <DeveloperFeed />
            </TabsContent>

            <TabsContent value="following">
              <div className={styles.emptyState}>
                <p>You're not following anyone yet. Start following creators to see their updates here!</p>
              </div>
            </TabsContent>

            <TabsContent value="trending">
              <DeveloperFeed />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
