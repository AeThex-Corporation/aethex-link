import type { Route } from './+types/api.keys';
import { auth } from '~/lib/auth.server';
import { db } from '~/lib/db.server';
import crypto from 'crypto';

export async function loader({ request }: Route.LoaderArgs) {
  try {
    const user = await auth.requireAuth(request);
    const keys = await db.apiKey.findByUserId(user.id);

    // Don't return full keys, only partial for security
    const safeKeys = keys.map(key => ({
      id: key.id,
      name: key.name,
      keyPreview: `${key.key.substring(0, 8)}...${key.key.substring(key.key.length - 4)}`,
      permissions: key.permissions,
      lastUsedAt: key.lastUsedAt,
      createdAt: key.createdAt,
      expiresAt: key.expiresAt,
    }));

    return Response.json({ keys: safeKeys });
  } catch (error: any) {
    return Response.json(
      { error: error.message || 'Failed to fetch API keys' },
      { status: 500 }
    );
  }
}

export async function action({ request }: Route.ActionArgs) {
  try {
    const user = await auth.requireAuth(request);
    const body = await request.json();
    const { action, name, permissions, expiresInDays, keyId } = body;

    if (action === 'create') {
      // Generate secure API key
      const key = `aethex_${crypto.randomBytes(32).toString('hex')}`;
      
      const expiresAt = expiresInDays 
        ? new Date(Date.now() + expiresInDays * 24 * 60 * 60 * 1000)
        : undefined;

      const apiKey = await db.apiKey.create({
        userId: user.id,
        name,
        key,
        permissions: permissions || ['profile:read'],
        expiresAt,
      });

      // Return full key only on creation
      return Response.json({ 
        success: true, 
        apiKey: {
          ...apiKey,
          fullKey: key, // Only shown once
        }
      });
    }

    if (action === 'delete') {
      const apiKey = (await db.apiKey.findByUserId(user.id))
        .find(k => k.id === keyId);
      
      if (!apiKey) {
        return Response.json({ error: 'API key not found' }, { status: 404 });
      }

      await db.apiKey.delete(keyId);
      return Response.json({ success: true });
    }

    return Response.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error: any) {
    console.error('API key error:', error);
    return Response.json(
      { error: error.message || 'API key operation failed' },
      { status: 500 }
    );
  }
}
