import type { LoaderFunctionArgs } from 'react-router';
import { auth } from '~/lib/auth.server';
import { db } from '~/lib/db.server';

/**
 * Get domain information for current user
 * GET /api/domain/info
 */
export async function loader({ request }: LoaderFunctionArgs) {
  // Require authentication
  const user = await auth.requireAuth(request);

  try {
    // Get user's domain record
    const domainRecord = await db.domain.findByUserId(user.id);
    if (!domainRecord) {
      return Response.json({ domain: null });
    }

    // Get transaction history
    const transactions = await db.domainTransaction.findByDomain(domainRecord.domain);

    return Response.json({
      domain: domainRecord,
      transactions: transactions.sort((a, b) => 
        b.createdAt.getTime() - a.createdAt.getTime()
      ),
    });
  } catch (error: any) {
    console.error('Failed to get domain info:', error);
    return Response.json({
      error: error.message || 'Failed to get domain information',
    }, { status: 500 });
  }
}
