import type { ActionFunctionArgs } from 'react-router';
import { auth } from '~/lib/auth.server';
import { db } from '~/lib/db.server';
import { freenameAPI } from '~/lib/freename.server';

/**
 * Register a new .aethex domain
 * POST /api/domain/register
 */
export async function action({ request }: ActionFunctionArgs) {
  // Require authentication
  const user = await auth.requireAuth(request);

  const body = await request.json();
  const { username, walletAddress } = body;

  if (!username) {
    return Response.json({ error: 'Username is required' }, { status: 400 });
  }

  // Validate username format
  if (!/^[a-zA-Z0-9_-]{3,20}$/.test(username)) {
    return Response.json({
      error: 'Username must be 3-20 characters and contain only letters, numbers, hyphens, and underscores',
    }, { status: 400 });
  }

  try {
    // Check if user already has a domain
    const existingDomain = await db.domain.findByUserId(user.id);
    if (existingDomain) {
      return Response.json({ error: 'User already has a registered domain' }, { status: 400 });
    }

    // Check availability
    const availability = await freenameAPI.checkAvailability(username);
    if (!availability.available) {
      return Response.json({ error: 'Domain is not available' }, { status: 400 });
    }

    // Register domain via Freename API
    const registration = await freenameAPI.registerDomain(
      username,
      user.id,
      walletAddress
    );

    // Create domain record in database
    const domainRecord = await db.domain.create({
      userId: user.id,
      domain: registration.domain,
      walletAddress: registration.walletAddress,
      registrationDate: registration.registrationDate,
      expiryDate: registration.expiryDate,
      status: registration.status,
      transactionHash: registration.transactionHash,
      blockchain: registration.blockchain,
      autoRenew: true,
    });

    // Create transaction record
    await db.domainTransaction.create({
      userId: user.id,
      domain: registration.domain,
      type: 'registration',
      amount: availability.price || 10,
      currency: availability.currency || 'USD',
      status: 'completed',
      transactionHash: registration.transactionHash,
    });

    // Update user record with domain
    await db.user.update(user.id, {
      aethexDomain: registration.domain,
      aethexDomainVerified: registration.status === 'active',
      walletAddress: registration.walletAddress,
    });

    return Response.json({
      success: true,
      domain: domainRecord,
      registration,
    });
  } catch (error: any) {
    console.error('Domain registration failed:', error);
    return Response.json({
      error: error.message || 'Failed to register domain',
    }, { status: 500 });
  }
}
