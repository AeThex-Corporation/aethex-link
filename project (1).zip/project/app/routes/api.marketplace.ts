import type { Route } from './+types/api.marketplace';
import { auth } from '~/lib/auth.server';
import { db } from '~/lib/db.server';

export async function loader({ request }: Route.LoaderArgs) {
  // Get all active marketplace listings
  try {
    const listings = await db.marketplace.findActive();
    
    // Enrich with seller info
    const enrichedListings = await Promise.all(
      listings.map(async (listing) => {
        const seller = await db.user.findById(listing.sellerId);
        return {
          ...listing,
          seller: seller ? {
            id: seller.id,
            username: seller.username,
            name: seller.name,
            avatar: seller.avatar,
          } : null,
        };
      })
    );

    return Response.json({ listings: enrichedListings });
  } catch (error: any) {
    return Response.json(
      { error: error.message || 'Failed to fetch marketplace listings' },
      { status: 500 }
    );
  }
}

export async function action({ request }: Route.ActionArgs) {
  try {
    const user = await auth.requireAuth(request);
    const body = await request.json();
    const { action, domain, price, description, listingId, buyerId } = body;

    if (action === 'create') {
      // List domain for sale
      const domainRecord = await db.domain.findByDomain(domain);
      
      if (!domainRecord) {
        return Response.json({ error: 'Domain not found' }, { status: 404 });
      }

      if (domainRecord.userId !== user.id) {
        return Response.json({ error: 'Unauthorized' }, { status: 403 });
      }

      const listing = await db.marketplace.create({
        domain,
        sellerId: user.id,
        price,
        currency: 'USD',
        description,
        status: 'active',
      });

      return Response.json({ success: true, listing });
    }

    if (action === 'cancel') {
      const listing = await db.marketplace.findById(listingId);
      
      if (!listing) {
        return Response.json({ error: 'Listing not found' }, { status: 404 });
      }

      if (listing.sellerId !== user.id) {
        return Response.json({ error: 'Unauthorized' }, { status: 403 });
      }

      await db.marketplace.update(listingId, { status: 'cancelled' });
      return Response.json({ success: true });
    }

    if (action === 'buy') {
      const listing = await db.marketplace.findById(listingId);
      
      if (!listing) {
        return Response.json({ error: 'Listing not found' }, { status: 404 });
      }

      if (listing.status !== 'active') {
        return Response.json({ error: 'Listing not active' }, { status: 400 });
      }

      // Transfer domain
      const domainRecord = await db.domain.findByDomain(listing.domain);
      if (domainRecord) {
        await db.domain.update(listing.domain, { userId: user.id });
      }

      // Update listing
      await db.marketplace.update(listingId, { status: 'sold' });

      // Create transaction record
      await db.domainTransaction.create({
        userId: user.id,
        domain: listing.domain,
        type: 'transfer',
        amount: listing.price,
        currency: listing.currency,
        status: 'completed',
        metadata: { fromUserId: listing.sellerId },
      });

      return Response.json({ success: true });
    }

    return Response.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error: any) {
    console.error('Marketplace error:', error);
    return Response.json(
      { error: error.message || 'Marketplace operation failed' },
      { status: 500 }
    );
  }
}
