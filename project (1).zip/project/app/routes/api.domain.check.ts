import type { LoaderFunctionArgs } from 'react-router';
import { freenameAPI } from '~/lib/freename.server';

/**
 * Check domain availability
 * GET /api/domain/check?username=example
 */
export async function loader({ request }: LoaderFunctionArgs) {
  const url = new URL(request.url);
  const username = url.searchParams.get('username');

  if (!username) {
    return Response.json({ error: 'Username is required' }, { status: 400 });
  }

  // Validate username format
  if (!/^[a-zA-Z0-9_-]{3,20}$/.test(username)) {
    return Response.json({
      error: 'Username must be 3-20 characters and contain only letters, numbers, hyphens, and underscores',
    }, { status: 400 });
  }

  try {
    const availability = await freenameAPI.checkAvailability(username);
    return Response.json(availability);
  } catch (error: any) {
    console.error('Domain check failed:', error);
    return Response.json({ error: error.message || 'Failed to check domain availability' }, { status: 500 });
  }
}
