import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import type { Route } from './+types/onboarding';
import { OnboardingWizard } from '~/components/onboarding-wizard/onboarding-wizard';
import { useAuth } from '~/hooks/use-auth';
import { LoadingState } from '~/components/loading-state/loading-state';

export function meta({}: Route.MetaArgs) {
  return [
    { title: 'Get Started - CreatorHub' },
    { name: 'description', content: 'Set up your CreatorHub profile' },
  ];
}

export default function Onboarding() {
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const [shouldShowOnboarding, setShouldShowOnboarding] = useState(true);

  useEffect(() => {
    // Redirect to auth if not logged in
    if (!loading && !user) {
      navigate('/auth');
    }
  }, [user, loading, navigate]);

  const handleComplete = () => {
    // Mark onboarding as complete (could save to user preferences)
    localStorage.setItem('onboarding_completed', 'true');
    navigate('/dashboard');
  };

  const handleSkip = () => {
    // Allow users to skip onboarding
    localStorage.setItem('onboarding_skipped', 'true');
    navigate('/dashboard');
  };

  if (loading) {
    return <LoadingState text="Loading your profile" fullPage />;
  }

  if (!user) {
    return null;
  }

  return <OnboardingWizard onComplete={handleComplete} onSkip={handleSkip} />;
}
