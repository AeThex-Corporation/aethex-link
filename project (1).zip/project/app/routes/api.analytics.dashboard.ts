import type { Route } from './+types/api.analytics.dashboard';
import { analytics } from '~/lib/analytics.server';
import { auth } from '~/lib/auth.server';

export async function loader({ request }: Route.LoaderArgs) {
  const session = await auth.getSession(request.headers.get('Cookie'));
  const userId = session.get('userId');

  if (!userId) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const url = new URL(request.url);
  const range = url.searchParams.get('range') || '30d';

  // Calculate timeframe based on range
  const end = new Date();
  const start = new Date();
  
  switch (range) {
    case '7d':
      start.setDate(start.getDate() - 7);
      break;
    case '30d':
      start.setDate(start.getDate() - 30);
      break;
    case '90d':
      start.setDate(start.getDate() - 90);
      break;
    case '1y':
      start.setFullYear(start.getFullYear() - 1);
      break;
    default:
      start.setDate(start.getDate() - 30);
  }

  try {
    const data = await analytics.getComprehensiveAnalytics(userId, { start, end });
    return Response.json(data);
  } catch (error) {
    console.error('Analytics error:', error);
    return Response.json({ error: 'Failed to load analytics' }, { status: 500 });
  }
}
