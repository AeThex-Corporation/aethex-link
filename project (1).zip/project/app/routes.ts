import { type RouteConfig, index, route } from "@react-router/dev/routes";

export default [
  index("routes/home.tsx"),
  route("auth", "routes/auth.tsx"),
  route("onboarding", "routes/onboarding.tsx"),
  route("dashboard", "routes/dashboard.tsx"),
  route("profile", "routes/profile.tsx"),
  route("monetization", "routes/monetization.tsx"),
  route("premium", "routes/premium.tsx"),
  route("social", "routes/social.tsx"),
  route("portfolio/showcase", "routes/portfolio.showcase.tsx"),
  route("marketplace", "routes/marketplace.tsx"),
  route("teams", "routes/teams.tsx"),
  route("widgets", "routes/widgets.tsx"),
  route("career-hub", "routes/career-hub.tsx"),
  
  // Subdomain routing for custom portfolio pages
  route(":username", "routes/subdomain.$username.tsx"),
  
  // API routes
  route("api/auth/register", "routes/api.auth.register.ts"),
  route("api/auth/login", "routes/api.auth.login.ts"),
  route("api/auth/logout", "routes/api.auth.logout.ts"),
  route("api/auth/me", "routes/api.auth.me.ts"),
  route("api/profile/update", "routes/api.profile.update.ts"),
  route("api/profile/sync", "routes/api.profile.sync.ts"),
  route("api/profile/:userId", "routes/api.profile.$userId.ts"),
  route("api/analytics/dashboard", "routes/api.analytics.dashboard.ts"),
  route("api/analytics/export", "routes/api.analytics.export.ts"),
  route("api/connections", "routes/api.connections.ts"),
  route("api/revenue", "routes/api.revenue.ts"),
  route("api/portfolio", "routes/api.portfolio.ts"),
  route("api/platforms/sync", "routes/api.platforms.sync.ts"),
  route("api/marketplace", "routes/api.marketplace.ts"),
  route("api/teams", "routes/api.teams.ts"),
  route("api/recruiters", "routes/api.recruiters.ts"),
  route("api/keys", "routes/api.keys.ts"),
  
  // Public API for third-party integrations
  route("api/public/profile/:username", "routes/api.public.profile.$username.ts"),
  route("api/widget/embed", "routes/api.widget.embed.ts"),
  
  // Domain routes
  route("api/domain/check", "routes/api.domain.check.ts"),
  route("api/domain/register", "routes/api.domain.register.ts"),
  route("api/domain/verify", "routes/api.domain.verify.ts"),
  route("api/domain/renew", "routes/api.domain.renew.ts"),
  route("api/domain/info", "routes/api.domain.info.ts"),
  route("api/domain/analytics", "routes/api.domain.analytics.ts"),
  
  // AI-Powered Career Features
  route("api/ai/recommendations", "routes/api.ai.recommendations.ts"),
  route("api/ai/career-prediction", "routes/api.ai.career-prediction.ts"),
  route("api/resume/generate", "routes/api.resume.generate.ts"),
  route("api/jobs/match", "routes/api.jobs.match.ts"),
] satisfies RouteConfig;
