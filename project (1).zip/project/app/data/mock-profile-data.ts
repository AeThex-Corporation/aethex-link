// Mock data for a developer profile aggregated from multiple sources

export interface GitHubContribution {
  id: string;
  repository: string;
  type: 'commit' | 'pr' | 'issue' | 'review';
  title: string;
  languages: string[];
  date: string;
  impact: 'high' | 'medium' | 'low';
  linesAdded: number;
  linesRemoved: number;
  verified: boolean;
}

export interface StackOverflowActivity {
  id: string;
  type: 'answer' | 'question';
  title: string;
  tags: string[];
  score: number;
  accepted: boolean;
  date: string;
  views: number;
  verified: boolean;
}

export interface BlogPost {
  id: string;
  title: string;
  platform: string;
  url: string;
  topics: string[];
  publishedDate: string;
  views: number;
  engagement: number;
  verified: boolean;
}

export interface Skill {
  name: string;
  category: 'language' | 'framework' | 'tool' | 'concept';
  level: number; // 0-100
  sources: {
    github: number;
    stackoverflow: number;
    blog: number;
  };
  verified: boolean;
  trend: 'up' | 'down' | 'stable';
}

export interface DeveloperProfile {
  id: string;
  name: string;
  username: string;
  avatar: string;
  title: string;
  location: string;
  bio: string;
  joinedDate: string;
  verified: boolean;
  
  stats: {
    totalContributions: number;
    repositories: number;
    stackOverflowReputation: number;
    blogPosts: number;
    yearsOfExperience: number;
  };
  
  skills: Skill[];
  recentGitHubActivity: GitHubContribution[];
  stackOverflowActivity: StackOverflowActivity[];
  blogPosts: BlogPost[];
}

// Mock profile data
export const mockProfile: DeveloperProfile = {
  id: '1',
  name: 'Sarah Chen',
  username: 'sarahchen',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400',
  title: 'Game Developer, AI Engineer & Full-Stack Developer',
  location: 'San Francisco, CA',
  bio: 'Multi-platform creator building games on Roblox and Unity, training AI models on Hugging Face, and contributing to open source. Passionate about TypeScript, game development, and machine learning.',
  joinedDate: '2024-01-15',
  verified: true,
  
  stats: {
    totalContributions: 2847,
    repositories: 156,
    stackOverflowReputation: 12450,
    blogPosts: 23,
    yearsOfExperience: 8,
  },
  
  skills: [
    {
      name: 'TypeScript',
      category: 'language',
      level: 95,
      sources: { github: 850, stackoverflow: 45, blog: 12 },
      verified: true,
      trend: 'up',
    },
    {
      name: 'React',
      category: 'framework',
      level: 92,
      sources: { github: 720, stackoverflow: 38, blog: 15 },
      verified: true,
      trend: 'stable',
    },
    {
      name: 'Node.js',
      category: 'framework',
      level: 88,
      sources: { github: 640, stackoverflow: 52, blog: 8 },
      verified: true,
      trend: 'up',
    },
    {
      name: 'PostgreSQL',
      category: 'tool',
      level: 82,
      sources: { github: 320, stackoverflow: 28, blog: 5 },
      verified: true,
      trend: 'stable',
    },
    {
      name: 'Docker',
      category: 'tool',
      level: 78,
      sources: { github: 280, stackoverflow: 15, blog: 4 },
      verified: true,
      trend: 'up',
    },
    {
      name: 'GraphQL',
      category: 'tool',
      level: 75,
      sources: { github: 210, stackoverflow: 12, blog: 6 },
      verified: true,
      trend: 'stable',
    },
    {
      name: 'System Design',
      category: 'concept',
      level: 85,
      sources: { github: 0, stackoverflow: 22, blog: 9 },
      verified: true,
      trend: 'up',
    },
    {
      name: 'AWS',
      category: 'tool',
      level: 72,
      sources: { github: 180, stackoverflow: 8, blog: 3 },
      verified: true,
      trend: 'stable',
    },
  ],
  
  recentGitHubActivity: [
    {
      id: 'gh-1',
      repository: 'vercel/next.js',
      type: 'pr',
      title: 'feat: Add support for React Server Components in middleware',
      languages: ['TypeScript', 'JavaScript'],
      date: '2024-03-15',
      impact: 'high',
      linesAdded: 342,
      linesRemoved: 87,
      verified: true,
    },
    {
      id: 'gh-2',
      repository: 'facebook/react',
      type: 'review',
      title: 'Review: Optimize useEffect cleanup in concurrent mode',
      languages: ['JavaScript'],
      date: '2024-03-12',
      impact: 'medium',
      linesAdded: 0,
      linesRemoved: 0,
      verified: true,
    },
    {
      id: 'gh-3',
      repository: 'sarahchen/dev-tools',
      type: 'commit',
      title: 'Add TypeScript type inference improvements',
      languages: ['TypeScript'],
      date: '2024-03-10',
      impact: 'medium',
      linesAdded: 156,
      linesRemoved: 42,
      verified: true,
    },
    {
      id: 'gh-4',
      repository: 'tanstack/query',
      type: 'issue',
      title: 'Bug: Query invalidation not working with suspense',
      languages: ['TypeScript'],
      date: '2024-03-08',
      impact: 'low',
      linesAdded: 0,
      linesRemoved: 0,
      verified: true,
    },
    {
      id: 'gh-5',
      repository: 'prisma/prisma',
      type: 'pr',
      title: 'feat: Add support for PostgreSQL array operations',
      languages: ['TypeScript', 'SQL'],
      date: '2024-03-05',
      impact: 'high',
      linesAdded: 428,
      linesRemoved: 124,
      verified: true,
    },
  ],
  
  stackOverflowActivity: [
    {
      id: 'so-1',
      type: 'answer',
      title: 'How to properly type React Server Components with TypeScript?',
      tags: ['typescript', 'react', 'server-components'],
      score: 142,
      accepted: true,
      date: '2024-03-14',
      views: 8450,
      verified: true,
    },
    {
      id: 'so-2',
      type: 'answer',
      title: 'Best practices for managing database connections in Node.js',
      tags: ['node.js', 'postgresql', 'connection-pooling'],
      score: 89,
      accepted: true,
      date: '2024-03-10',
      views: 4230,
      verified: true,
    },
    {
      id: 'so-3',
      type: 'question',
      title: 'Performance impact of React.memo with complex props',
      tags: ['react', 'performance', 'optimization'],
      score: 56,
      accepted: false,
      date: '2024-03-07',
      views: 2890,
      verified: true,
    },
    {
      id: 'so-4',
      type: 'answer',
      title: 'GraphQL vs REST: When to use each approach?',
      tags: ['graphql', 'rest', 'api-design'],
      score: 234,
      accepted: true,
      date: '2024-02-28',
      views: 15600,
      verified: true,
    },
  ],
  
  blogPosts: [
    {
      id: 'blog-1',
      title: 'Building Type-Safe APIs with TypeScript and tRPC',
      platform: 'Medium',
      url: 'https://medium.com/@sarahchen/type-safe-apis',
      topics: ['TypeScript', 'tRPC', 'API Design'],
      publishedDate: '2024-03-01',
      views: 12500,
      engagement: 856,
      verified: true,
    },
    {
      id: 'blog-2',
      title: 'Deep Dive: React Server Components Architecture',
      platform: 'Dev.to',
      url: 'https://dev.to/sarahchen/rsc-architecture',
      topics: ['React', 'Server Components', 'Architecture'],
      publishedDate: '2024-02-15',
      views: 18700,
      engagement: 1240,
      verified: true,
    },
    {
      id: 'blog-3',
      title: 'Scaling Node.js Applications: Lessons from Production',
      platform: 'Personal Blog',
      url: 'https://sarahchen.dev/scaling-nodejs',
      topics: ['Node.js', 'Scalability', 'Performance'],
      publishedDate: '2024-01-20',
      views: 9300,
      engagement: 624,
      verified: true,
    },
  ],
};
