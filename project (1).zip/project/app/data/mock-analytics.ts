export const mockProfileViews = [
  { date: "Jan", views: 1200, uniqueVisitors: 890 },
  { date: "Feb", views: 1450, uniqueVisitors: 1020 },
  { date: "Mar", views: 1680, uniqueVisitors: 1180 },
  { date: "Apr", views: 2100, uniqueVisitors: 1450 },
  { date: "May", views: 2450, uniqueVisitors: 1680 },
  { date: "Jun", views: 2890, uniqueVisitors: 1950 }
];

export const mockSkillGrowth = [
  { month: "Jan", contributions: 45, skillScore: 72 },
  { month: "Feb", contributions: 52, skillScore: 75 },
  { month: "Mar", contributions: 68, skillScore: 78 },
  { month: "Apr", contributions: 71, skillScore: 82 },
  { month: "May", contributions: 85, skillScore: 86 },
  { month: "Jun", contributions: 92, skillScore: 90 }
];

export const mockSourceBreakdown = [
  { source: "GitHub", contributions: 3245, percentage: 45 },
  { source: "Stack Overflow", contributions: 1876, percentage: 26 },
  { source: "Blog", contributions: 1345, percentage: 19 },
  { source: "npm", contributions: 734, percentage: 10 }
];

export const mockNetworkGrowth = [
  { month: "Jan", connections: 120, profileViews: 890 },
  { month: "Feb", connections: 145, profileViews: 1020 },
  { month: "Mar", connections: 178, profileViews: 1180 },
  { month: "Apr", connections: 215, profileViews: 1450 },
  { month: "May", connections: 268, profileViews: 1680 },
  { month: "Jun", connections: 312, profileViews: 1950 }
];

export const mockRecruiterViews = [
  {
    id: 1,
    name: "Sarah Chen",
    company: "Meta",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop",
    timesViewed: 5
  },
  {
    id: 2,
    name: "James Miller",
    company: "Google",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop",
    timesViewed: 3
  },
  {
    id: 3,
    name: "Maria Garcia",
    company: "Amazon",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop",
    timesViewed: 2
  }
];

export function exportAllAnalytics(data: any) {
  // Convert to CSV
  const csv = [
    "Category,Metric,Value",
    `Profile Views,Total,${data.profileViews.reduce((sum: number, item: any) => sum + item.views, 0)}`,
    `Profile Views,Unique,${data.profileViews.reduce((sum: number, item: any) => sum + item.uniqueVisitors, 0)}`,
    `Skills,Growth,${data.skillGrowth[data.skillGrowth.length - 1].skillScore}%`,
    `Network,Connections,${data.networkGrowth[data.networkGrowth.length - 1].connections}`,
  ].join("\n");

  // Create download
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'analytics-export.csv';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
