import { createCookie, createCookieSessionStorage } from 'react-router';

const sessionSecret = process.env.SESSION_SECRET || 'default-secret-change-in-production';

// Session cookie configuration
const sessionCookie = createCookie('__session', {
  secrets: [sessionSecret],
  sameSite: 'lax',
  path: '/',
  maxAge: 60 * 60 * 24 * 7, // 7 days
  httpOnly: true,
  secure: process.env.NODE_ENV === 'production',
});

// Create session storage
export const sessionStorage = createCookieSessionStorage({
  cookie: sessionCookie,
});

export async function createUserSession(userId: string, redirectTo: string) {
  const session = await sessionStorage.getSession();
  session.set('userId', userId);
  
  return new Response(null, {
    status: 302,
    headers: {
      'Set-Cookie': await sessionStorage.commitSession(session),
      Location: redirectTo,
    },
  });
}

export async function getUserSession(request: Request) {
  return sessionStorage.getSession(request.headers.get('Cookie'));
}

export async function getUserId(request: Request): Promise<string | null> {
  const session = await getUserSession(request);
  const userId = session.get('userId');
  if (!userId || typeof userId !== 'string') return null;
  return userId;
}

export async function requireUserId(request: Request): Promise<string> {
  const userId = await getUserId(request);
  if (!userId) {
    throw new Response('Unauthorized', { status: 401 });
  }
  return userId;
}

export async function logout(request: Request) {
  const session = await getUserSession(request);
  return new Response(null, {
    status: 302,
    headers: {
      'Set-Cookie': await sessionStorage.destroySession(session),
      Location: '/',
    },
  });
}
