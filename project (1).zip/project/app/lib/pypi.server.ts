/**
 * PyPI (Python Package Index) integration
 */

export interface PyPiPackage {
  name: string;
  version: string;
  description: string;
  downloads: number;
  stars: number;
  lastRelease: string;
  homepageUrl?: string;
}

export interface PyPiProfile {
  username: string;
  packages: PyPiPackage[];
  totalDownloads: number;
  totalPackages: number;
}

export class PyPiService {
  private readonly baseUrl = 'https://pypi.org/pypi';

  async getUserPackages(username: string): Promise<PyPiProfile> {
    try {
      // PyPI doesn't have a direct user search API, so we'll use the RSS feed
      const searchResponse = await fetch(
        `https://pypi.org/user/${username}/`
      );

      if (!searchResponse.ok) {
        throw new Error('Failed to fetch PyPI user data');
      }

      // For now, we'll return mock data structure
      // In production, you'd parse the HTML or use a dedicated PyPI stats service
      const packages: PyPiPackage[] = [];
      
      // Alternative: Use pypistats.org API for download stats
      // This is a simplified implementation
      
      return {
        username,
        packages,
        totalDownloads: 0,
        totalPackages: packages.length,
      };
    } catch (error: any) {
      console.error('PyPI API Error:', error);
      throw new Error(`Failed to fetch PyPI data: ${error.message}`);
    }
  }

  async getPackageStats(packageName: string): Promise<PyPiPackage | null> {
    try {
      const response = await fetch(`${this.baseUrl}/${packageName}/json`);
      
      if (!response.ok) {
        return null;
      }

      const data = await response.json();
      const info = data.info;

      return {
        name: packageName,
        version: info.version,
        description: info.summary || '',
        downloads: 0, // Would need pypistats.org for actual download counts
        stars: 0,
        lastRelease: data.releases?.[info.version]?.[0]?.upload_time || '',
        homepageUrl: info.home_page,
      };
    } catch (error) {
      console.error(`Failed to fetch package ${packageName}:`, error);
      return null;
    }
  }
}

// Export singleton instance
export const pypi = new PyPiService();
