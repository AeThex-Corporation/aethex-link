import axios from 'axios';

const STACK_OVERFLOW_API = 'https://api.stackexchange.com/2.3';
const API_KEY = process.env.STACKOVERFLOW_API_KEY;

export interface StackOverflowUser {
  userId: number;
  displayName: string;
  reputation: number;
  badges: {
    gold: number;
    silver: number;
    bronze: number;
  };
  location: string;
  profileImage: string;
  link: string;
  createdAt: number;
}

export interface StackOverflowAnswer {
  id: number;
  questionId: number;
  title: string;
  score: number;
  isAccepted: boolean;
  createdAt: number;
  lastActivityDate: number;
  tags: string[];
  link: string;
}

export interface StackOverflowQuestion {
  id: number;
  title: string;
  score: number;
  viewCount: number;
  answerCount: number;
  createdAt: number;
  tags: string[];
  link: string;
}

export interface StackOverflowActivity {
  id: number;
  type: 'answer' | 'question';
  title: string;
  score: number;
  views: number;
  accepted: boolean;
  tags: string[];
  date: string;
  url: string;
}

export class StackOverflowService {
  private apiKey: string;

  constructor() {
    this.apiKey = API_KEY || '';
  }

  /**
   * Get user profile
   */
  async getUser(userId: string): Promise<StackOverflowUser> {
    const response = await axios.get(`${STACK_OVERFLOW_API}/users/${userId}`, {
      params: {
        site: 'stackoverflow',
        key: this.apiKey,
      },
    });

    const user = response.data.items[0];

    return {
      userId: user.user_id,
      displayName: user.display_name,
      reputation: user.reputation,
      badges: {
        gold: user.badge_counts.gold,
        silver: user.badge_counts.silver,
        bronze: user.badge_counts.bronze,
      },
      location: user.location || '',
      profileImage: user.profile_image,
      link: user.link,
      createdAt: user.creation_date,
    };
  }

  /**
   * Get user answers
   */
  async getAnswers(userId: string, limit = 30): Promise<StackOverflowAnswer[]> {
    const response = await axios.get(`${STACK_OVERFLOW_API}/users/${userId}/answers`, {
      params: {
        site: 'stackoverflow',
        sort: 'votes',
        order: 'desc',
        pagesize: limit,
        filter: 'withbody',
        key: this.apiKey,
      },
    });

    return response.data.items.map((answer: any) => ({
      id: answer.answer_id,
      questionId: answer.question_id,
      title: answer.title || '',
      score: answer.score,
      isAccepted: answer.is_accepted,
      createdAt: answer.creation_date,
      lastActivityDate: answer.last_activity_date,
      tags: answer.tags || [],
      link: answer.link,
    }));
  }

  /**
   * Get user questions
   */
  async getQuestions(userId: string, limit = 30): Promise<StackOverflowQuestion[]> {
    const response = await axios.get(`${STACK_OVERFLOW_API}/users/${userId}/questions`, {
      params: {
        site: 'stackoverflow',
        sort: 'votes',
        order: 'desc',
        pagesize: limit,
        key: this.apiKey,
      },
    });

    return response.data.items.map((question: any) => ({
      id: question.question_id,
      title: question.title,
      score: question.score,
      viewCount: question.view_count,
      answerCount: question.answer_count,
      createdAt: question.creation_date,
      tags: question.tags,
      link: question.link,
    }));
  }

  /**
   * Get combined activity
   */
  async getActivity(userId: string, limit = 50): Promise<StackOverflowActivity[]> {
    const [answers, questions] = await Promise.all([
      this.getAnswers(userId, Math.floor(limit / 2)),
      this.getQuestions(userId, Math.floor(limit / 2)),
    ]);

    const activities: StackOverflowActivity[] = [];

    // Add answers
    for (const answer of answers) {
      activities.push({
        id: answer.id,
        type: 'answer',
        title: answer.title || `Answer to question #${answer.questionId}`,
        score: answer.score,
        views: 0, // Not available for answers
        accepted: answer.isAccepted,
        tags: answer.tags,
        date: new Date(answer.createdAt * 1000).toISOString(),
        url: answer.link,
      });
    }

    // Add questions
    for (const question of questions) {
      activities.push({
        id: question.id,
        type: 'question',
        title: question.title,
        score: question.score,
        views: question.viewCount,
        accepted: question.answerCount > 0,
        tags: question.tags,
        date: new Date(question.createdAt * 1000).toISOString(),
        url: question.link,
      });
    }

    // Sort by date
    return activities.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  /**
   * Calculate skill scores from Stack Overflow tags
   */
  async calculateSkillScores(userId: string): Promise<Record<string, number>> {
    const activity = await this.getActivity(userId, 100);
    const tagScores: Record<string, number> = {};

    for (const item of activity) {
      for (const tag of item.tags) {
        const weight = item.score + (item.accepted ? 10 : 0);
        tagScores[tag] = (tagScores[tag] || 0) + weight;
      }
    }

    // Normalize scores
    const maxScore = Math.max(...Object.values(tagScores));
    for (const tag in tagScores) {
      tagScores[tag] = Math.min(100, Math.round((tagScores[tag] / maxScore) * 100));
    }

    return tagScores;
  }

  /**
   * Get top tags for user
   */
  async getTopTags(userId: string, limit = 10): Promise<Array<{ tag: string; score: number }>> {
    const response = await axios.get(`${STACK_OVERFLOW_API}/users/${userId}/top-tags`, {
      params: {
        site: 'stackoverflow',
        pagesize: limit,
        key: this.apiKey,
      },
    });

    return response.data.items.map((item: any) => ({
      tag: item.tag_name,
      score: item.answer_score,
    }));
  }
}

// Export singleton instance
export const stackoverflow = new StackOverflowService();
