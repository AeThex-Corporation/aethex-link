/**
 * Medium integration (via RSS feed - no official API for user stats)
 */

export interface MediumArticle {
  title: string;
  url: string;
  publishedAt: string;
  description: string;
  categories: string[];
  thumbnail?: string;
}

export interface MediumProfile {
  username: string;
  articles: MediumArticle[];
  totalArticles: number;
}

export class MediumService {
  async getUserProfile(username: string): Promise<MediumProfile> {
    try {
      // Medium RSS feed
      const rssUrl = `https://medium.com/feed/@${username}`;
      const response = await fetch(rssUrl);

      if (!response.ok) {
        throw new Error('Failed to fetch Medium RSS feed');
      }

      const rssText = await response.text();
      
      // Parse RSS XML (simplified - in production use proper XML parser)
      const articles = this.parseRSS(rssText);

      return {
        username,
        articles,
        totalArticles: articles.length,
      };
    } catch (error: any) {
      console.error('Medium RSS Error:', error);
      throw new Error(`Failed to fetch Medium data: ${error.message}`);
    }
  }

  private parseRSS(rssText: string): MediumArticle[] {
    const articles: MediumArticle[] = [];
    
    // Extract items using regex (simplified parser)
    const itemRegex = /<item>([\s\S]*?)<\/item>/g;
    let match;

    while ((match = itemRegex.exec(rssText)) !== null) {
      const itemContent = match[1];
      
      const title = this.extractTag(itemContent, 'title');
      const url = this.extractTag(itemContent, 'link');
      const publishedAt = this.extractTag(itemContent, 'pubDate');
      const description = this.extractTag(itemContent, 'description');
      const categoriesMatch = itemContent.matchAll(/<category>(.*?)<\/category>/g);
      const categories = Array.from(categoriesMatch).map(m => m[1]);
      
      // Extract thumbnail from content:encoded
      const contentEncoded = this.extractTag(itemContent, 'content:encoded');
      const imgMatch = contentEncoded.match(/<img[^>]+src="([^">]+)"/);
      const thumbnail = imgMatch ? imgMatch[1] : undefined;

      if (title && url) {
        articles.push({
          title,
          url,
          publishedAt,
          description: this.stripHtml(description),
          categories,
          thumbnail,
        });
      }
    }

    return articles;
  }

  private extractTag(content: string, tagName: string): string {
    const regex = new RegExp(`<${tagName}[^>]*><!\\[CDATA\\[(.*?)\\]\\]><\/${tagName}>|<${tagName}[^>]*>(.*?)<\/${tagName}>`, 's');
    const match = content.match(regex);
    return match ? (match[1] || match[2] || '').trim() : '';
  }

  private stripHtml(html: string): string {
    return html.replace(/<[^>]*>/g, '').trim();
  }
}

// Export singleton instance
export const medium = new MediumService();
