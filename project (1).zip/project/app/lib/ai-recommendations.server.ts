/**
 * AI-Powered Skill Recommendations Engine
 * Analyzes user skills and provides personalized learning recommendations
 */

export interface SkillRecommendation {
  skill: string;
  reason: string;
  marketDemand: 'high' | 'medium' | 'low';
  timeToLearn: string; // e.g., "2-3 months"
  relatedToCurrentSkills: string[];
  averageSalaryImpact: number; // percentage increase
  resources: LearningResource[];
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  trendingScore: number; // 0-100
}

export interface LearningResource {
  title: string;
  type: 'course' | 'book' | 'tutorial' | 'documentation';
  url: string;
  platform: string;
  rating: number;
  duration?: string;
  isFree: boolean;
}

export interface CareerPathPrediction {
  currentLevel: string;
  nextLevel: string;
  estimatedTimeToNextLevel: string;
  confidenceScore: number; // 0-100
  requiredSkills: string[];
  skillGaps: string[];
  salaryProjection: {
    current: number;
    projected: number;
    timeframe: string;
  };
}

export interface SkillGrowthAnalysis {
  skill: string;
  currentLevel: number;
  growthRate: number; // per month
  projectedLevel6Months: number;
  projectedLevel12Months: number;
  trend: 'accelerating' | 'steady' | 'declining';
  benchmarkComparison: {
    vsTopPerformers: number; // percentage difference
    vsIndustryAverage: number;
  };
}

// Market demand data (in production, this would come from APIs)
const SKILL_MARKET_DATA: Record<string, {
  demand: 'high' | 'medium' | 'low';
  avgSalaryImpact: number;
  trendingScore: number;
  timeToLearn: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
}> = {
  'Rust': { demand: 'high', avgSalaryImpact: 18, trendingScore: 95, timeToLearn: '4-6 months', difficulty: 'advanced' },
  'Go': { demand: 'high', avgSalaryImpact: 15, trendingScore: 92, timeToLearn: '3-4 months', difficulty: 'intermediate' },
  'Kubernetes': { demand: 'high', avgSalaryImpact: 20, trendingScore: 94, timeToLearn: '4-5 months', difficulty: 'advanced' },
  'TypeScript': { demand: 'high', avgSalaryImpact: 12, trendingScore: 96, timeToLearn: '2-3 months', difficulty: 'intermediate' },
  'React': { demand: 'high', avgSalaryImpact: 10, trendingScore: 88, timeToLearn: '3-4 months', difficulty: 'intermediate' },
  'Next.js': { demand: 'high', avgSalaryImpact: 14, trendingScore: 90, timeToLearn: '2-3 months', difficulty: 'intermediate' },
  'GraphQL': { demand: 'high', avgSalaryImpact: 16, trendingScore: 85, timeToLearn: '2-3 months', difficulty: 'intermediate' },
  'AWS': { demand: 'high', avgSalaryImpact: 22, trendingScore: 93, timeToLearn: '6-12 months', difficulty: 'advanced' },
  'Docker': { demand: 'high', avgSalaryImpact: 14, trendingScore: 89, timeToLearn: '2-3 months', difficulty: 'intermediate' },
  'TensorFlow': { demand: 'high', avgSalaryImpact: 25, trendingScore: 87, timeToLearn: '6-9 months', difficulty: 'advanced' },
  'PyTorch': { demand: 'high', avgSalaryImpact: 24, trendingScore: 91, timeToLearn: '6-9 months', difficulty: 'advanced' },
  'Python': { demand: 'high', avgSalaryImpact: 8, trendingScore: 85, timeToLearn: '3-4 months', difficulty: 'beginner' },
  'Machine Learning': { demand: 'high', avgSalaryImpact: 30, trendingScore: 98, timeToLearn: '9-12 months', difficulty: 'advanced' },
  'System Design': { demand: 'high', avgSalaryImpact: 28, trendingScore: 92, timeToLearn: '6-12 months', difficulty: 'advanced' },
  'Microservices': { demand: 'high', avgSalaryImpact: 18, trendingScore: 86, timeToLearn: '4-6 months', difficulty: 'advanced' },
  'PostgreSQL': { demand: 'medium', avgSalaryImpact: 10, trendingScore: 78, timeToLearn: '2-3 months', difficulty: 'intermediate' },
  'MongoDB': { demand: 'medium', avgSalaryImpact: 8, trendingScore: 75, timeToLearn: '2-3 months', difficulty: 'intermediate' },
  'Vue.js': { demand: 'medium', avgSalaryImpact: 9, trendingScore: 72, timeToLearn: '2-3 months', difficulty: 'intermediate' },
  'Angular': { demand: 'medium', avgSalaryImpact: 10, trendingScore: 68, timeToLearn: '3-4 months', difficulty: 'intermediate' },
  'Svelte': { demand: 'medium', avgSalaryImpact: 12, trendingScore: 82, timeToLearn: '2-3 months', difficulty: 'intermediate' },
};

// Skill relationship graph (for recommendations)
const SKILL_RELATIONSHIPS: Record<string, string[]> = {
  'JavaScript': ['TypeScript', 'React', 'Next.js', 'Node.js'],
  'TypeScript': ['React', 'Next.js', 'GraphQL'],
  'React': ['Next.js', 'GraphQL', 'React Native'],
  'Python': ['Machine Learning', 'TensorFlow', 'PyTorch', 'Django'],
  'Node.js': ['GraphQL', 'Microservices', 'Docker'],
  'Docker': ['Kubernetes', 'AWS', 'Microservices'],
  'AWS': ['Kubernetes', 'Microservices', 'System Design'],
  'SQL': ['PostgreSQL', 'System Design'],
};

export class AIRecommendationsService {
  /**
   * Generate personalized skill recommendations based on user's current skills
   */
  async generateSkillRecommendations(
    currentSkills: Array<{ name: string; level: number; category: string }>,
    careerGoal?: string,
    experienceLevel?: 'junior' | 'mid' | 'senior'
  ): Promise<SkillRecommendation[]> {
    const recommendations: SkillRecommendation[] = [];
    const currentSkillNames = new Set(currentSkills.map(s => s.name));

    // Find complementary skills based on existing skills
    for (const skill of currentSkills) {
      const relatedSkills = SKILL_RELATIONSHIPS[skill.name] || [];
      
      for (const relatedSkill of relatedSkills) {
        if (!currentSkillNames.has(relatedSkill) && SKILL_MARKET_DATA[relatedSkill]) {
          const marketData = SKILL_MARKET_DATA[relatedSkill];
          
          recommendations.push({
            skill: relatedSkill,
            reason: `Complements your ${skill.name} expertise. High synergy with your existing skills.`,
            marketDemand: marketData.demand,
            timeToLearn: marketData.timeToLearn,
            relatedToCurrentSkills: [skill.name],
            averageSalaryImpact: marketData.avgSalaryImpact,
            resources: this.getLearningResources(relatedSkill),
            difficulty: marketData.difficulty,
            trendingScore: marketData.trendingScore,
          });
        }
      }
    }

    // Add trending skills with high market demand
    const trendingSkills = Object.entries(SKILL_MARKET_DATA)
      .filter(([skillName]) => !currentSkillNames.has(skillName))
      .sort((a, b) => b[1].trendingScore - a[1].trendingScore)
      .slice(0, 5);

    for (const [skillName, marketData] of trendingSkills) {
      const relatedCurrent = currentSkills.filter(s => 
        SKILL_RELATIONSHIPS[s.name]?.includes(skillName)
      );

      if (!recommendations.find(r => r.skill === skillName)) {
        recommendations.push({
          skill: skillName,
          reason: `Highly trending skill with ${marketData.demand} market demand. ${marketData.avgSalaryImpact}% average salary increase.`,
          marketDemand: marketData.demand,
          timeToLearn: marketData.timeToLearn,
          relatedToCurrentSkills: relatedCurrent.map(s => s.name),
          averageSalaryImpact: marketData.avgSalaryImpact,
          resources: this.getLearningResources(skillName),
          difficulty: marketData.difficulty,
          trendingScore: marketData.trendingScore,
        });
      }
    }

    // Sort by a weighted score (trending, salary impact, relevance)
    return recommendations
      .sort((a, b) => {
        const scoreA = a.trendingScore * 0.4 + a.averageSalaryImpact * 0.4 + a.relatedToCurrentSkills.length * 10 * 0.2;
        const scoreB = b.trendingScore * 0.4 + b.averageSalaryImpact * 0.4 + b.relatedToCurrentSkills.length * 10 * 0.2;
        return scoreB - scoreA;
      })
      .slice(0, 10);
  }

  /**
   * Predict career progression based on current trajectory
   */
  async predictCareerPath(
    currentSkills: Array<{ name: string; level: number }>,
    currentExperience: number, // years
    currentTitle: string
  ): Promise<CareerPathPrediction> {
    // Simple career ladder
    const careerLevels = ['Junior', 'Mid-Level', 'Senior', 'Staff', 'Principal', 'Distinguished'];
    
    const currentLevelIndex = this.estimateCareerLevel(currentExperience, currentSkills);
    const currentLevel = careerLevels[currentLevelIndex];
    const nextLevel = careerLevels[Math.min(currentLevelIndex + 1, careerLevels.length - 1)];

    // Calculate average skill level
    const avgSkillLevel = currentSkills.reduce((sum, s) => sum + s.level, 0) / currentSkills.length;

    // Estimate time to next level based on skill proficiency and experience
    const skillGrowthRate = this.calculateSkillGrowthRate(currentSkills);
    const monthsToNextLevel = this.estimateTimeToNextLevel(currentLevelIndex, avgSkillLevel, skillGrowthRate);

    // Identify required skills for next level
    const requiredSkills = this.getRequiredSkillsForLevel(currentLevelIndex + 1);
    const skillGaps = requiredSkills.filter(
      skill => !currentSkills.find(s => s.name === skill && s.level >= 70)
    );

    // Salary projection
    const baseSalary = this.estimateBaseSalary(currentLevelIndex, currentExperience);
    const projectedSalary = this.estimateBaseSalary(currentLevelIndex + 1, currentExperience + monthsToNextLevel / 12);

    return {
      currentLevel,
      nextLevel,
      estimatedTimeToNextLevel: this.formatTimeEstimate(monthsToNextLevel),
      confidenceScore: Math.min(95, 60 + avgSkillLevel * 0.3),
      requiredSkills,
      skillGaps,
      salaryProjection: {
        current: baseSalary,
        projected: projectedSalary,
        timeframe: this.formatTimeEstimate(monthsToNextLevel),
      },
    };
  }

  /**
   * Analyze skill growth trajectory
   */
  async analyzeSkillGrowth(
    skillHistory: Array<{ skill: string; level: number; timestamp: Date }>
  ): Promise<SkillGrowthAnalysis[]> {
    const skillGroups = new Map<string, Array<{ level: number; timestamp: Date }>>();

    // Group by skill
    for (const entry of skillHistory) {
      if (!skillGroups.has(entry.skill)) {
        skillGroups.set(entry.skill, []);
      }
      skillGroups.get(entry.skill)!.push({ level: entry.level, timestamp: entry.timestamp });
    }

    const analyses: SkillGrowthAnalysis[] = [];

    for (const [skill, history] of skillGroups) {
      if (history.length < 2) continue;

      // Sort by timestamp
      history.sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());

      const currentLevel = history[history.length - 1].level;
      const growthRate = this.calculateGrowthRate(history);
      
      // Project future levels
      const projectedLevel6Months = Math.min(100, currentLevel + growthRate * 6);
      const projectedLevel12Months = Math.min(100, currentLevel + growthRate * 12);

      // Determine trend
      const recentGrowth = history.slice(-3);
      const trend = this.determineTrend(recentGrowth);

      analyses.push({
        skill,
        currentLevel,
        growthRate,
        projectedLevel6Months,
        projectedLevel12Months,
        trend,
        benchmarkComparison: {
          vsTopPerformers: this.compareToTopPerformers(skill, currentLevel),
          vsIndustryAverage: this.compareToIndustryAverage(skill, currentLevel),
        },
      });
    }

    return analyses.sort((a, b) => b.growthRate - a.growthRate);
  }

  // Helper methods

  private getLearningResources(skill: string): LearningResource[] {
    // In production, this would fetch from a real database or API
    const resources: Record<string, LearningResource[]> = {
      'Rust': [
        { title: 'The Rust Programming Language', type: 'book', url: 'https://doc.rust-lang.org/book/', platform: 'Official Docs', rating: 4.9, isFree: true },
        { title: 'Rust by Example', type: 'tutorial', url: 'https://doc.rust-lang.org/rust-by-example/', platform: 'Official', rating: 4.8, isFree: true },
      ],
      'Kubernetes': [
        { title: 'Kubernetes Fundamentals', type: 'course', url: 'https://www.udemy.com/kubernetes', platform: 'Udemy', rating: 4.7, duration: '12 hours', isFree: false },
        { title: 'Kubernetes Documentation', type: 'documentation', url: 'https://kubernetes.io/docs/', platform: 'Official', rating: 4.9, isFree: true },
      ],
    };

    return resources[skill] || [
      { title: `Learn ${skill}`, type: 'course', url: '#', platform: 'Multiple', rating: 4.5, isFree: false },
    ];
  }

  private estimateCareerLevel(experience: number, skills: Array<{ level: number }>): number {
    const avgSkillLevel = skills.reduce((sum, s) => sum + s.level, 0) / skills.length;
    
    if (experience < 2 || avgSkillLevel < 50) return 0; // Junior
    if (experience < 4 || avgSkillLevel < 65) return 1; // Mid-Level
    if (experience < 7 || avgSkillLevel < 80) return 2; // Senior
    if (experience < 10 || avgSkillLevel < 90) return 3; // Staff
    if (experience < 15) return 4; // Principal
    return 5; // Distinguished
  }

  private calculateSkillGrowthRate(skills: Array<{ level: number }>): number {
    // Simplified: assume 2-5% monthly growth depending on current level
    const avgLevel = skills.reduce((sum, s) => sum + s.level, 0) / skills.length;
    if (avgLevel < 50) return 4; // Rapid growth for beginners
    if (avgLevel < 75) return 2.5; // Moderate growth
    return 1.5; // Slower growth at advanced levels
  }

  private estimateTimeToNextLevel(currentLevel: number, avgSkillLevel: number, growthRate: number): number {
    // Base months needed, adjusted by skill proficiency
    const baseMonths = [18, 24, 36, 48, 60, 72]; // months for each level transition
    const adjustment = (80 - avgSkillLevel) / 100; // penalty for lower skills
    return Math.ceil(baseMonths[currentLevel] * (1 + adjustment));
  }

  private getRequiredSkillsForLevel(level: number): string[] {
    const levelSkills = [
      ['JavaScript', 'HTML', 'CSS', 'Git'],
      ['React', 'TypeScript', 'Node.js', 'SQL'],
      ['System Design', 'Microservices', 'AWS', 'Docker'],
      ['Kubernetes', 'GraphQL', 'System Design', 'Team Leadership'],
      ['Architecture', 'Strategic Planning', 'Team Management'],
      ['Industry Influence', 'Innovation', 'Thought Leadership'],
    ];
    return levelSkills[level] || [];
  }

  private estimateBaseSalary(level: number, experience: number): number {
    // Simplified salary estimation (in USD)
    const baseSalaries = [65000, 90000, 130000, 175000, 225000, 300000];
    const experienceMultiplier = 1 + (experience * 0.03); // 3% per year
    return Math.round(baseSalaries[level] * experienceMultiplier);
  }

  private formatTimeEstimate(months: number): string {
    if (months < 6) return `${months} months`;
    if (months < 12) return `${Math.floor(months)} months`;
    const years = Math.floor(months / 12);
    const remainingMonths = months % 12;
    if (remainingMonths === 0) return `${years} year${years > 1 ? 's' : ''}`;
    return `${years} year${years > 1 ? 's' : ''} ${remainingMonths} months`;
  }

  private calculateGrowthRate(history: Array<{ level: number; timestamp: Date }>): number {
    if (history.length < 2) return 0;

    const first = history[0];
    const last = history[history.length - 1];
    const levelGain = last.level - first.level;
    const monthsElapsed = (last.timestamp.getTime() - first.timestamp.getTime()) / (1000 * 60 * 60 * 24 * 30);

    return monthsElapsed > 0 ? levelGain / monthsElapsed : 0;
  }

  private determineTrend(recentData: Array<{ level: number }>): 'accelerating' | 'steady' | 'declining' {
    if (recentData.length < 2) return 'steady';

    const growthRates = [];
    for (let i = 1; i < recentData.length; i++) {
      growthRates.push(recentData[i].level - recentData[i - 1].level);
    }

    const avgRate = growthRates.reduce((sum, r) => sum + r, 0) / growthRates.length;
    const lastRate = growthRates[growthRates.length - 1];

    if (lastRate > avgRate * 1.2) return 'accelerating';
    if (lastRate < avgRate * 0.8) return 'declining';
    return 'steady';
  }

  private compareToTopPerformers(skill: string, currentLevel: number): number {
    // Top performers average around 90-95
    const topPerformerLevel = 92;
    return ((currentLevel - topPerformerLevel) / topPerformerLevel) * 100;
  }

  private compareToIndustryAverage(skill: string, currentLevel: number): number {
    // Industry average around 65-70
    const industryAverage = 68;
    return ((currentLevel - industryAverage) / industryAverage) * 100;
  }
}

export const aiRecommendations = new AIRecommendationsService();
