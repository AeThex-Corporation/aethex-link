/**
 * Database abstraction layer
 * In production, replace with PostgreSQL, MongoDB, or your preferred database
 */

// Types for our database models
export interface User {
  id: string;
  email: string;
  name: string;
  username: string;
  passwordHash: string;
  avatar?: string;
  bio?: string;
  location?: string;
  title?: string;
  githubToken?: string;
  stackOverflowId?: string;
  // .aethex domain
  // Domain tier: 'free' for username.aethex.me, 'premium' for username.aethex
  domainTier: 'free' | 'premium';
  // Premium blockchain domain
  aethexDomain?: string;
  aethexDomainVerified?: boolean;
  walletAddress?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface UserProfile {
  userId: string;
  // Software Dev Platforms
  githubUsername?: string;
  stackOverflowId?: string;
  blogUrl?: string;
  npmUsername?: string;
  pypiUsername?: string;
  gitlabUsername?: string;
  devtoUsername?: string;
  mediumUsername?: string;
  // Game Dev Platforms
  robloxUsername?: string;
  robloxUserId?: number;
  unityPublisherId?: string;
  unrealMarketplaceId?: string;
  steamDeveloperId?: string;
  itchioUsername?: string;
  // AI Platforms
  huggingFaceUsername?: string;
  kaggleUsername?: string;
  arxivAuthorId?: string;
  // Tokens/Keys (encrypted in production)
  robloxApiKey?: string;
  unityApiKey?: string;
  huggingFaceToken?: string;
  kaggleApiKey?: string;
  kaggleUsername_api?: string;
  gitlabToken?: string;
  devtoApiKey?: string;
  lastSyncedAt?: Date;
}

export interface AnalyticsEvent {
  id: string;
  userId: string;
  eventType: string;
  metadata: Record<string, any>;
  timestamp: Date;
}

export interface RevenueRecord {
  id: string;
  userId: string;
  platform: string;
  amount: number;
  currency: string;
  source?: string;
  transactionDate: Date;
  createdAt: Date;
}

export interface DomainRecord {
  id: string;
  userId: string;
  domain: string;
  walletAddress?: string;
  registrationDate: Date;
  expiryDate: Date;
  status: 'pending' | 'active' | 'expired' | 'suspended';
  transactionHash?: string;
  blockchain?: string;
  autoRenew: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface DomainTransaction {
  id: string;
  userId: string;
  domain: string;
  type: 'registration' | 'renewal' | 'transfer';
  amount: number;
  currency: string;
  status: 'pending' | 'completed' | 'failed';
  transactionHash?: string;
  metadata?: Record<string, any>;
  createdAt: Date;
}

export interface Portfolio {
  id: string;
  userId: string;
  type: 'game' | 'ai_model' | 'asset' | 'project';
  title: string;
  description: string;
  platform: string;
  url?: string;
  thumbnailUrl?: string;
  videoUrl?: string;
  stats?: Record<string, any>;
  tags: string[];
  featured: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface Connection {
  id: string;
  userId: string;
  connectedUserId: string;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: Date;
}

export interface Team {
  id: string;
  name: string;
  description: string;
  ownerId: string;
  avatarUrl?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface TeamMember {
  id: string;
  teamId: string;
  userId: string;
  role: 'owner' | 'admin' | 'member';
  joinedAt: Date;
}

export interface MarketplaceListing {
  id: string;
  domain: string;
  sellerId: string;
  price: number;
  currency: string;
  description?: string;
  status: 'active' | 'sold' | 'cancelled';
  createdAt: Date;
  updatedAt: Date;
}

export interface RecruiterProfile {
  id: string;
  userId: string;
  company: string;
  position: string;
  lookingFor: string[];
  industries: string[];
  verified: boolean;
  createdAt: Date;
}

export interface ApiKey {
  id: string;
  userId: string;
  name: string;
  key: string;
  permissions: string[];
  lastUsedAt?: Date;
  createdAt: Date;
  expiresAt?: Date;
}

// In-memory storage for demo purposes
// Replace with actual database in production
const users = new Map<string, User>();
const profiles = new Map<string, UserProfile>();
const analyticsEvents: AnalyticsEvent[] = [];
const connections: Connection[] = [];
const revenueRecords: RevenueRecord[] = [];
const portfolioItems: Portfolio[] = [];
const domainRecords = new Map<string, DomainRecord>();
const domainTransactions: DomainTransaction[] = [];
const teams = new Map<string, Team>();
const teamMembers: TeamMember[] = [];
const marketplaceListings: MarketplaceListing[] = [];
const recruiterProfiles = new Map<string, RecruiterProfile>();
const apiKeys: ApiKey[] = [];

// User operations
export const db = {
  user: {
    async create(data: Omit<User, 'id' | 'createdAt' | 'updatedAt'>): Promise<User> {
      const user: User = {
        ...data,
        id: crypto.randomUUID(),
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      users.set(user.id, user);
      return user;
    },

    async findById(id: string): Promise<User | null> {
      return users.get(id) || null;
    },

    async findByEmail(email: string): Promise<User | null> {
      for (const user of users.values()) {
        if (user.email === email) {
          return user;
        }
      }
      return null;
    },

    async findByUsername(username: string): Promise<User | null> {
      for (const user of users.values()) {
        if (user.username === username) {
          return user;
        }
      }
      return null;
    },

    async update(id: string, data: Partial<User>): Promise<User | null> {
      const user = users.get(id);
      if (!user) return null;

      const updated = {
        ...user,
        ...data,
        id,
        updatedAt: new Date(),
      };
      users.set(id, updated);
      return updated;
    },

    async delete(id: string): Promise<boolean> {
      return users.delete(id);
    },

    async findAll(): Promise<User[]> {
      return Array.from(users.values());
    },
  },

  profile: {
    async create(data: UserProfile): Promise<UserProfile> {
      profiles.set(data.userId, data);
      return data;
    },

    async findByUserId(userId: string): Promise<UserProfile | null> {
      return profiles.get(userId) || null;
    },

    async update(userId: string, data: Partial<UserProfile>): Promise<UserProfile | null> {
      const profile = profiles.get(userId);
      if (!profile) return null;

      const updated = { ...profile, ...data };
      profiles.set(userId, updated);
      return updated;
    },
  },

  analytics: {
    async create(event: Omit<AnalyticsEvent, 'id'>): Promise<AnalyticsEvent> {
      const newEvent: AnalyticsEvent = {
        ...event,
        id: crypto.randomUUID(),
      };
      analyticsEvents.push(newEvent);
      return newEvent;
    },

    async findByUserId(userId: string, limit = 100): Promise<AnalyticsEvent[]> {
      return analyticsEvents
        .filter(e => e.userId === userId)
        .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
        .slice(0, limit);
    },

    async aggregate(userId: string, startDate: Date, endDate: Date) {
      const userEvents = analyticsEvents.filter(
        e => e.userId === userId && 
        e.timestamp >= startDate && 
        e.timestamp <= endDate
      );

      return {
        total: userEvents.length,
        byType: userEvents.reduce((acc, e) => {
          acc[e.eventType] = (acc[e.eventType] || 0) + 1;
          return acc;
        }, {} as Record<string, number>),
        events: userEvents,
      };
    },
  },

  connection: {
    async create(userId: string, connectedUserId: string): Promise<Connection> {
      const connection: Connection = {
        id: crypto.randomUUID(),
        userId,
        connectedUserId,
        status: 'pending',
        createdAt: new Date(),
      };
      connections.push(connection);
      return connection;
    },

    async findByUserId(userId: string): Promise<Connection[]> {
      return connections.filter(c => c.userId === userId || c.connectedUserId === userId);
    },

    async updateStatus(id: string, status: Connection['status']): Promise<Connection | null> {
      const connection = connections.find(c => c.id === id);
      if (!connection) return null;
      connection.status = status;
      return connection;
    },
  },

  revenue: {
    async create(data: Omit<RevenueRecord, 'id' | 'createdAt'>): Promise<RevenueRecord> {
      const record: RevenueRecord = {
        ...data,
        id: crypto.randomUUID(),
        createdAt: new Date(),
      };
      revenueRecords.push(record);
      return record;
    },

    async findByUserId(userId: string): Promise<RevenueRecord[]> {
      return revenueRecords.filter(r => r.userId === userId);
    },

    async findByUserAndPlatform(userId: string, platform: string): Promise<RevenueRecord[]> {
      return revenueRecords.filter(r => r.userId === userId && r.platform === platform);
    },

    async getTotalRevenue(userId: string): Promise<number> {
      return revenueRecords
        .filter(r => r.userId === userId)
        .reduce((sum, r) => sum + r.amount, 0);
    },
  },

  portfolio: {
    async create(data: Omit<Portfolio, 'id' | 'createdAt' | 'updatedAt'>): Promise<Portfolio> {
      const item: Portfolio = {
        ...data,
        id: crypto.randomUUID(),
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      portfolioItems.push(item);
      return item;
    },

    async findByUserId(userId: string): Promise<Portfolio[]> {
      return portfolioItems.filter(p => p.userId === userId);
    },

    async findByUserAndType(userId: string, type: Portfolio['type']): Promise<Portfolio[]> {
      return portfolioItems.filter(p => p.userId === userId && p.type === type);
    },

    async findById(id: string): Promise<Portfolio | null> {
      return portfolioItems.find(p => p.id === id) || null;
    },

    async update(id: string, data: Partial<Portfolio>): Promise<Portfolio | null> {
      const index = portfolioItems.findIndex(p => p.id === id);
      if (index === -1) return null;

      portfolioItems[index] = {
        ...portfolioItems[index],
        ...data,
        updatedAt: new Date(),
      };
      return portfolioItems[index];
    },

    async delete(id: string): Promise<boolean> {
      const index = portfolioItems.findIndex(p => p.id === id);
      if (index === -1) return false;
      portfolioItems.splice(index, 1);
      return true;
    },
  },

  domain: {
    async create(data: Omit<DomainRecord, 'id' | 'createdAt' | 'updatedAt'>): Promise<DomainRecord> {
      const record: DomainRecord = {
        ...data,
        id: crypto.randomUUID(),
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      domainRecords.set(record.domain, record);
      return record;
    },

    async findByDomain(domain: string): Promise<DomainRecord | null> {
      return domainRecords.get(domain) || null;
    },

    async findByUserId(userId: string): Promise<DomainRecord | null> {
      for (const record of domainRecords.values()) {
        if (record.userId === userId) {
          return record;
        }
      }
      return null;
    },

    async update(domain: string, data: Partial<DomainRecord>): Promise<DomainRecord | null> {
      const record = domainRecords.get(domain);
      if (!record) return null;

      const updated = {
        ...record,
        ...data,
        updatedAt: new Date(),
      };
      domainRecords.set(domain, updated);
      return updated;
    },

    async delete(domain: string): Promise<boolean> {
      return domainRecords.delete(domain);
    },
  },

  domainTransaction: {
    async create(data: Omit<DomainTransaction, 'id' | 'createdAt'>): Promise<DomainTransaction> {
      const transaction: DomainTransaction = {
        ...data,
        id: crypto.randomUUID(),
        createdAt: new Date(),
      };
      domainTransactions.push(transaction);
      return transaction;
    },

    async findByUserId(userId: string): Promise<DomainTransaction[]> {
      return domainTransactions.filter(t => t.userId === userId);
    },

    async findByDomain(domain: string): Promise<DomainTransaction[]> {
      return domainTransactions.filter(t => t.domain === domain);
    },

    async getTotalRevenue(): Promise<number> {
      return domainTransactions
        .filter(t => t.status === 'completed' && t.type !== 'transfer')
        .reduce((sum, t) => sum + t.amount, 0);
    },
  },

  team: {
    async create(data: Omit<Team, 'id' | 'createdAt' | 'updatedAt'>): Promise<Team> {
      const team: Team = {
        ...data,
        id: crypto.randomUUID(),
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      teams.set(team.id, team);
      return team;
    },

    async findById(id: string): Promise<Team | null> {
      return teams.get(id) || null;
    },

    async findByOwnerId(ownerId: string): Promise<Team[]> {
      return Array.from(teams.values()).filter(t => t.ownerId === ownerId);
    },

    async update(id: string, data: Partial<Team>): Promise<Team | null> {
      const team = teams.get(id);
      if (!team) return null;

      const updated = {
        ...team,
        ...data,
        updatedAt: new Date(),
      };
      teams.set(id, updated);
      return updated;
    },

    async delete(id: string): Promise<boolean> {
      return teams.delete(id);
    },
  },

  teamMember: {
    async create(data: Omit<TeamMember, 'id'>): Promise<TeamMember> {
      const member: TeamMember = {
        ...data,
        id: crypto.randomUUID(),
      };
      teamMembers.push(member);
      return member;
    },

    async findByTeamId(teamId: string): Promise<TeamMember[]> {
      return teamMembers.filter(m => m.teamId === teamId);
    },

    async findByUserId(userId: string): Promise<TeamMember[]> {
      return teamMembers.filter(m => m.userId === userId);
    },

    async remove(teamId: string, userId: string): Promise<boolean> {
      const index = teamMembers.findIndex(m => m.teamId === teamId && m.userId === userId);
      if (index === -1) return false;
      teamMembers.splice(index, 1);
      return true;
    },
  },

  marketplace: {
    async create(data: Omit<MarketplaceListing, 'id' | 'createdAt' | 'updatedAt'>): Promise<MarketplaceListing> {
      const listing: MarketplaceListing = {
        ...data,
        id: crypto.randomUUID(),
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      marketplaceListings.push(listing);
      return listing;
    },

    async findById(id: string): Promise<MarketplaceListing | null> {
      return marketplaceListings.find(l => l.id === id) || null;
    },

    async findByDomain(domain: string): Promise<MarketplaceListing | null> {
      return marketplaceListings.find(l => l.domain === domain && l.status === 'active') || null;
    },

    async findActive(): Promise<MarketplaceListing[]> {
      return marketplaceListings.filter(l => l.status === 'active');
    },

    async findBySellerId(sellerId: string): Promise<MarketplaceListing[]> {
      return marketplaceListings.filter(l => l.sellerId === sellerId);
    },

    async update(id: string, data: Partial<MarketplaceListing>): Promise<MarketplaceListing | null> {
      const index = marketplaceListings.findIndex(l => l.id === id);
      if (index === -1) return null;

      marketplaceListings[index] = {
        ...marketplaceListings[index],
        ...data,
        updatedAt: new Date(),
      };
      return marketplaceListings[index];
    },
  },

  recruiter: {
    async create(data: Omit<RecruiterProfile, 'id' | 'createdAt'>): Promise<RecruiterProfile> {
      const profile: RecruiterProfile = {
        ...data,
        id: crypto.randomUUID(),
        createdAt: new Date(),
      };
      recruiterProfiles.set(data.userId, profile);
      return profile;
    },

    async findByUserId(userId: string): Promise<RecruiterProfile | null> {
      return recruiterProfiles.get(userId) || null;
    },

    async findAll(): Promise<RecruiterProfile[]> {
      return Array.from(recruiterProfiles.values());
    },

    async update(userId: string, data: Partial<RecruiterProfile>): Promise<RecruiterProfile | null> {
      const profile = recruiterProfiles.get(userId);
      if (!profile) return null;

      const updated = { ...profile, ...data };
      recruiterProfiles.set(userId, updated);
      return updated;
    },
  },

  apiKey: {
    async create(data: Omit<ApiKey, 'id' | 'createdAt'>): Promise<ApiKey> {
      const key: ApiKey = {
        ...data,
        id: crypto.randomUUID(),
        createdAt: new Date(),
      };
      apiKeys.push(key);
      return key;
    },

    async findByKey(key: string): Promise<ApiKey | null> {
      return apiKeys.find(k => k.key === key) || null;
    },

    async findByUserId(userId: string): Promise<ApiKey[]> {
      return apiKeys.filter(k => k.userId === userId);
    },

    async updateLastUsed(key: string): Promise<void> {
      const apiKey = apiKeys.find(k => k.key === key);
      if (apiKey) {
        apiKey.lastUsedAt = new Date();
      }
    },

    async delete(id: string): Promise<boolean> {
      const index = apiKeys.findIndex(k => k.id === id);
      if (index === -1) return false;
      apiKeys.splice(index, 1);
      return true;
    },
  },
};

