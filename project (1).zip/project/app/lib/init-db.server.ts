/**
 * Database initialization for development
 * Creates some test users on first load
 */

import { db } from './db.server';
import bcrypt from 'bcryptjs';

let initialized = false;

export async function initializeDatabase() {
  if (initialized) return;
  initialized = true;

  // Check if any users exist
  const existingUser = await db.user.findByEmail('test@example.com');
  if (existingUser) {
    console.log('Database already initialized');
    return;
  }

  console.log('Initializing database with test users...');

  // Create test user 1
  const passwordHash1 = await bcrypt.hash('password123', 10);
  const user1 = await db.user.create({
    email: 'test@example.com',
    name: 'Test User',
    username: 'testuser',
    passwordHash: passwordHash1,
    bio: 'Full-stack developer passionate about open source',
    location: 'San Francisco, CA',
    title: 'Senior Full-Stack Developer',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=testuser',
    domainTier: 'free',
  });

  await db.profile.create({
    userId: user1.id,
    githubUsername: 'testuser',
    stackOverflowId: '12345',
  });

  // Create test user 2
  const passwordHash2 = await bcrypt.hash('password123', 10);
  const user2 = await db.user.create({
    email: 'demo@example.com',
    name: 'Demo User',
    username: 'demouser',
    passwordHash: passwordHash2,
    bio: 'Game developer and AI enthusiast',
    location: 'New York, NY',
    title: 'Game Developer',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=demouser',
    domainTier: 'free',
  });

  await db.profile.create({
    userId: user2.id,
    robloxUsername: 'demouser',
    huggingFaceUsername: 'demouser',
  });

  console.log('Database initialized with test users:');
  console.log('- test@example.com / password123');
  console.log('- demo@example.com / password123');
}
