/**
 * NPM Registry integration
 */

export interface NpmPackage {
  name: string;
  version: string;
  description: string;
  downloads: number;
  weeklyDownloads: number;
  stars: number;
  publishedDate: string;
}

export interface NpmProfile {
  username: string;
  packages: NpmPackage[];
  totalDownloads: number;
  totalPackages: number;
}

export class NpmService {
  private readonly baseUrl = 'https://registry.npmjs.org';
  private readonly apiUrl = 'https://api.npmjs.org';

  async getUserPackages(username: string): Promise<NpmProfile> {
    try {
      // Get user's packages
      const response = await fetch(`${this.apiUrl}/downloads/range/last-week/${username}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch NPM data');
      }

      // Fetch package details
      const searchResponse = await fetch(
        `https://registry.npmjs.org/-/v1/search?text=maintainer:${username}&size=250`
      );
      
      if (!searchResponse.ok) {
        throw new Error('Failed to fetch package list');
      }

      const searchData = await searchResponse.json();
      const packages: NpmPackage[] = [];
      let totalDownloads = 0;

      for (const pkg of searchData.objects || []) {
        const packageData = pkg.package;
        
        // Get download stats for each package
        try {
          const downloadsResponse = await fetch(
            `https://api.npmjs.org/downloads/point/last-week/${packageData.name}`
          );
          const downloadsData = await downloadsResponse.json();
          const weeklyDownloads = downloadsData.downloads || 0;
          totalDownloads += weeklyDownloads;

          packages.push({
            name: packageData.name,
            version: packageData.version,
            description: packageData.description || '',
            downloads: weeklyDownloads,
            weeklyDownloads,
            stars: packageData.score?.detail?.quality || 0,
            publishedDate: packageData.date,
          });
        } catch (err) {
          console.warn(`Failed to fetch downloads for ${packageData.name}`);
        }
      }

      return {
        username,
        packages: packages.sort((a, b) => b.downloads - a.downloads),
        totalDownloads,
        totalPackages: packages.length,
      };
    } catch (error: any) {
      console.error('NPM API Error:', error);
      throw new Error(`Failed to fetch NPM data: ${error.message}`);
    }
  }
}

// Export singleton instance
export const npm = new NpmService();
