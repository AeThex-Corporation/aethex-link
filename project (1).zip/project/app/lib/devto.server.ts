/**
 * Dev.to API integration
 */

export interface DevToArticle {
  id: number;
  title: string;
  description: string;
  url: string;
  publishedAt: string;
  reactions: number;
  comments: number;
  readingTime: number;
  coverImage?: string;
  tags: string[];
}

export interface DevToProfile {
  username: string;
  name: string;
  bio: string;
  avatarUrl: string;
  articles: DevToArticle[];
  totalReactions: number;
  totalComments: number;
  totalViews: number;
  followers: number;
}

export class DevToService {
  private readonly baseUrl = 'https://dev.to/api';
  private apiKey?: string;

  constructor(apiKey?: string) {
    this.apiKey = apiKey;
  }

  private async request<T>(endpoint: string): Promise<T> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    if (this.apiKey) {
      headers['api-key'] = this.apiKey;
    }

    const response = await fetch(`${this.baseUrl}${endpoint}`, { headers });

    if (!response.ok) {
      throw new Error(`Dev.to API error: ${response.statusText}`);
    }

    return response.json();
  }

  async getUserProfile(username: string): Promise<DevToProfile> {
    try {
      // Get user's articles
      const articles = await this.request<any[]>(
        `/articles?username=${username}&per_page=100`
      );

      const mappedArticles: DevToArticle[] = articles.map(article => ({
        id: article.id,
        title: article.title,
        description: article.description,
        url: article.url,
        publishedAt: article.published_at,
        reactions: article.public_reactions_count,
        comments: article.comments_count,
        readingTime: article.reading_time_minutes,
        coverImage: article.cover_image,
        tags: article.tag_list,
      }));

      const totalReactions = mappedArticles.reduce((sum, a) => sum + a.reactions, 0);
      const totalComments = mappedArticles.reduce((sum, a) => sum + a.comments, 0);

      // Get user info
      let userInfo: any = {};
      try {
        userInfo = await this.request<any>(`/users/by_username?url=${username}`);
      } catch (err) {
        console.warn('Failed to fetch Dev.to user info');
      }

      return {
        username,
        name: userInfo.name || username,
        bio: userInfo.summary || '',
        avatarUrl: userInfo.profile_image || '',
        articles: mappedArticles.sort((a, b) => b.reactions - a.reactions),
        totalReactions,
        totalComments,
        totalViews: 0, // Dev.to doesn't provide view counts via public API
        followers: 0, // Not available via public API
      };
    } catch (error: any) {
      console.error('Dev.to API Error:', error);
      throw new Error(`Failed to fetch Dev.to data: ${error.message}`);
    }
  }
}

// Export singleton instance
export const devto = new DevToService();
