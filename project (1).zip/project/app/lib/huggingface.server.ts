/**
 * Hugging Face API Integration Service
 * Fetches AI model stats, downloads, and performance metrics
 */

export interface HuggingFaceModel {
  id: string;
  modelId: string;
  author: string;
  sha: string;
  lastModified: string;
  private: boolean;
  downloads: number;
  likes: number;
  tags: string[];
  pipeline_tag?: string;
  library_name?: string;
  cardData?: {
    language?: string[];
    license?: string;
    datasets?: string[];
  };
}

export interface HuggingFaceUser {
  name: string;
  fullname: string;
  avatarUrl?: string;
  totalModels: number;
  totalDatasets: number;
  totalSpaces: number;
}

export interface ModelMetrics {
  totalDownloads: number;
  totalLikes: number;
  averageDownloads: number;
  averageLikes: number;
  topModels: Array<{
    name: string;
    downloads: number;
    likes: number;
    task: string;
  }>;
  taskBreakdown: Record<string, number>;
}

export class HuggingFaceService {
  private apiKey?: string;
  private baseUrl = 'https://huggingface.co/api';

  constructor(apiKey?: string) {
    this.apiKey = apiKey;
  }

  /**
   * Get user's models
   */
  async getUserModels(username: string): Promise<HuggingFaceModel[]> {
    try {
      const headers: HeadersInit = {};
      if (this.apiKey) {
        headers['Authorization'] = `Bearer ${this.apiKey}`;
      }

      const response = await fetch(
        `${this.baseUrl}/models?author=${encodeURIComponent(username)}&limit=100`,
        { headers }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch models');
      }

      return await response.json();
    } catch (error) {
      console.error('Hugging Face models fetch error:', error);
      return [];
    }
  }

  /**
   * Get specific model details
   */
  async getModelDetails(modelId: string): Promise<HuggingFaceModel | null> {
    try {
      const headers: HeadersInit = {};
      if (this.apiKey) {
        headers['Authorization'] = `Bearer ${this.apiKey}`;
      }

      const response = await fetch(
        `${this.baseUrl}/models/${modelId}`,
        { headers }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch model details');
      }

      return await response.json();
    } catch (error) {
      console.error('Hugging Face model details fetch error:', error);
      return null;
    }
  }

  /**
   * Get user's datasets
   */
  async getUserDatasets(username: string): Promise<any[]> {
    try {
      const headers: HeadersInit = {};
      if (this.apiKey) {
        headers['Authorization'] = `Bearer ${this.apiKey}`;
      }

      const response = await fetch(
        `${this.baseUrl}/datasets?author=${encodeURIComponent(username)}&limit=100`,
        { headers }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch datasets');
      }

      return await response.json();
    } catch (error) {
      console.error('Hugging Face datasets fetch error:', error);
      return [];
    }
  }

  /**
   * Calculate aggregate metrics for user's models
   */
  async calculateUserMetrics(username: string): Promise<ModelMetrics> {
    const models = await this.getUserModels(username);

    const totalDownloads = models.reduce((sum, model) => sum + (model.downloads || 0), 0);
    const totalLikes = models.reduce((sum, model) => sum + (model.likes || 0), 0);

    const topModels = models
      .sort((a, b) => (b.downloads || 0) - (a.downloads || 0))
      .slice(0, 10)
      .map(model => ({
        name: model.modelId,
        downloads: model.downloads || 0,
        likes: model.likes || 0,
        task: model.pipeline_tag || 'unknown',
      }));

    const taskBreakdown: Record<string, number> = {};
    models.forEach(model => {
      const task = model.pipeline_tag || 'other';
      taskBreakdown[task] = (taskBreakdown[task] || 0) + 1;
    });

    return {
      totalDownloads,
      totalLikes,
      averageDownloads: models.length > 0 ? Math.round(totalDownloads / models.length) : 0,
      averageLikes: models.length > 0 ? Math.round(totalLikes / models.length) : 0,
      topModels,
      taskBreakdown,
    };
  }

  /**
   * Get model performance tier
   */
  calculateModelTier(downloads: number, likes: number): string {
    const score = downloads + (likes * 100); // Weight likes more heavily

    if (score >= 1000000) return 'Elite';
    if (score >= 100000) return 'Professional';
    if (score >= 10000) return 'Advanced';
    if (score >= 1000) return 'Intermediate';
    return 'Beginner';
  }
}

// Export singleton instance
export const huggingface = new HuggingFaceService();
