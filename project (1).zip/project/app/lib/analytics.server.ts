/**
 * Advanced Analytics Service
 * 
 * Provides comprehensive analytics for user profiles including:
 * - Profile views and engagement metrics
 * - Skill growth tracking
 * - Platform activity trends
 * - Geographic distribution
 * - Revenue analytics
 */

import { db } from './db.server';

export interface AnalyticsTimeframe {
  start: Date;
  end: Date;
}

export interface ProfileViewMetrics {
  total: number;
  unique: number;
  bySource: Record<string, number>;
  byLocation: Record<string, number>;
  trend: Array<{ date: string; views: number }>;
}

export interface EngagementMetrics {
  profileClicks: number;
  platformClicks: number;
  widgetViews: number;
  apiRequests: number;
  shareCount: number;
}

export interface SkillGrowthMetrics {
  skillName: string;
  level: number;
  change: number;
  trend: Array<{ date: string; level: number }>;
  source: string;
}

export interface RevenueMetrics {
  total: number;
  bySource: Record<string, number>;
  trend: Array<{ date: string; revenue: number }>;
  projectedAnnual: number;
}

export interface GeographicDistribution {
  country: string;
  views: number;
  percentage: number;
}

export interface ComprehensiveAnalytics {
  profileViews: ProfileViewMetrics;
  engagement: EngagementMetrics;
  skillGrowth: SkillGrowthMetrics[];
  revenue: RevenueMetrics;
  geographic: GeographicDistribution[];
  marketValue: {
    estimated: number;
    percentile: number;
    trend: string;
  };
}

class AnalyticsService {
  /**
   * Track a profile view
   */
  async trackProfileView(userId: string, data: {
    source?: string;
    location?: string;
    referrer?: string;
    userAgent?: string;
  }): Promise<void> {
    try {
      await db.profileView.create({
        data: {
          userId,
          source: data.source || 'direct',
          location: data.location || 'unknown',
          referrer: data.referrer,
          userAgent: data.userAgent,
          timestamp: new Date(),
        },
      });
    } catch (error) {
      console.error('Failed to track profile view:', error);
    }
  }

  /**
   * Track platform click
   */
  async trackPlatformClick(userId: string, platform: string): Promise<void> {
    try {
      await db.platformClick.create({
        data: {
          userId,
          platform,
          timestamp: new Date(),
        },
      });
    } catch (error) {
      console.error('Failed to track platform click:', error);
    }
  }

  /**
   * Get comprehensive analytics for a user
   */
  async getComprehensiveAnalytics(
    userId: string,
    timeframe: AnalyticsTimeframe
  ): Promise<ComprehensiveAnalytics> {
    const [profileViews, engagement, skillGrowth, revenue, geographic] = await Promise.all([
      this.getProfileViewMetrics(userId, timeframe),
      this.getEngagementMetrics(userId, timeframe),
      this.getSkillGrowthMetrics(userId, timeframe),
      this.getRevenueMetrics(userId, timeframe),
      this.getGeographicDistribution(userId, timeframe),
    ]);

    const marketValue = await this.calculateMarketValue(userId);

    return {
      profileViews,
      engagement,
      skillGrowth,
      revenue,
      geographic,
      marketValue,
    };
  }

  /**
   * Get profile view metrics
   */
  private async getProfileViewMetrics(
    userId: string,
    timeframe: AnalyticsTimeframe
  ): Promise<ProfileViewMetrics> {
    // Mock implementation - replace with real database queries
    const mockData: ProfileViewMetrics = {
      total: 15234,
      unique: 12891,
      bySource: {
        'direct': 5234,
        'github': 3891,
        'linkedin': 2345,
        'twitter': 1876,
        'search': 1888,
      },
      byLocation: {
        'United States': 6234,
        'United Kingdom': 2891,
        'Germany': 1876,
        'Canada': 1543,
        'India': 1234,
        'Other': 1456,
      },
      trend: this.generateTrendData(30, 300, 600),
    };

    return mockData;
  }

  /**
   * Get engagement metrics
   */
  private async getEngagementMetrics(
    userId: string,
    timeframe: AnalyticsTimeframe
  ): Promise<EngagementMetrics> {
    // Mock implementation
    return {
      profileClicks: 8234,
      platformClicks: 4521,
      widgetViews: 23456,
      apiRequests: 12345,
      shareCount: 234,
    };
  }

  /**
   * Get skill growth metrics
   */
  private async getSkillGrowthMetrics(
    userId: string,
    timeframe: AnalyticsTimeframe
  ): Promise<SkillGrowthMetrics[]> {
    // Mock implementation
    return [
      {
        skillName: 'TypeScript',
        level: 92,
        change: +8,
        trend: this.generateTrendData(30, 84, 92),
        source: 'GitHub',
      },
      {
        skillName: 'React',
        level: 89,
        change: +5,
        trend: this.generateTrendData(30, 84, 89),
        source: 'GitHub',
      },
      {
        skillName: 'Node.js',
        level: 87,
        change: +3,
        trend: this.generateTrendData(30, 84, 87),
        source: 'GitHub',
      },
      {
        skillName: 'Machine Learning',
        level: 76,
        change: +12,
        trend: this.generateTrendData(30, 64, 76),
        source: 'Kaggle',
      },
      {
        skillName: 'Game Development',
        level: 82,
        change: +6,
        trend: this.generateTrendData(30, 76, 82),
        source: 'Unity',
      },
    ];
  }

  /**
   * Get revenue metrics
   */
  private async getRevenueMetrics(
    userId: string,
    timeframe: AnalyticsTimeframe
  ): Promise<RevenueMetrics> {
    // Mock implementation
    const monthlyRevenue = 2847;
    return {
      total: monthlyRevenue,
      bySource: {
        'Roblox': 1234,
        'Unity Asset Store': 876,
        'Domain Sales': 543,
        'Consulting': 194,
      },
      trend: this.generateRevenueTrend(12),
      projectedAnnual: monthlyRevenue * 12,
    };
  }

  /**
   * Get geographic distribution
   */
  private async getGeographicDistribution(
    userId: string,
    timeframe: AnalyticsTimeframe
  ): Promise<GeographicDistribution[]> {
    // Mock implementation
    const total = 15234;
    return [
      { country: 'United States', views: 6234, percentage: 40.9 },
      { country: 'United Kingdom', views: 2891, percentage: 19.0 },
      { country: 'Germany', views: 1876, percentage: 12.3 },
      { country: 'Canada', views: 1543, percentage: 10.1 },
      { country: 'India', views: 1234, percentage: 8.1 },
      { country: 'Other', views: 1456, percentage: 9.6 },
    ];
  }

  /**
   * Calculate market value
   */
  private async calculateMarketValue(userId: string): Promise<{
    estimated: number;
    percentile: number;
    trend: string;
  }> {
    // Mock implementation - would use real skill/experience data
    return {
      estimated: 145000,
      percentile: 92,
      trend: 'up',
    };
  }

  /**
   * Generate trend data for charts
   */
  private generateTrendData(days: number, min: number, max: number): Array<{ date: string; views: number }> {
    const data = [];
    const increment = (max - min) / days;
    
    for (let i = 0; i < days; i++) {
      const date = new Date();
      date.setDate(date.getDate() - (days - i));
      const value = Math.round(min + (increment * i) + (Math.random() * increment * 0.2));
      
      data.push({
        date: date.toISOString().split('T')[0],
        views: value,
      });
    }
    
    return data;
  }

  /**
   * Generate revenue trend
   */
  private generateRevenueTrend(months: number): Array<{ date: string; revenue: number }> {
    const data = [];
    const baseRevenue = 1500;
    
    for (let i = 0; i < months; i++) {
      const date = new Date();
      date.setMonth(date.getMonth() - (months - i));
      const growth = 1 + (i / months) * 0.5;
      const variance = 0.8 + Math.random() * 0.4;
      const revenue = Math.round(baseRevenue * growth * variance);
      
      data.push({
        date: date.toISOString().split('T')[0].substring(0, 7),
        revenue,
      });
    }
    
    return data;
  }

  /**
   * Export analytics data to CSV
   */
  async exportToCSV(userId: string, timeframe: AnalyticsTimeframe): Promise<string> {
    const analytics = await this.getComprehensiveAnalytics(userId, timeframe);
    
    let csv = 'Category,Metric,Value\n';
    
    // Profile Views
    csv += `Profile Views,Total,${analytics.profileViews.total}\n`;
    csv += `Profile Views,Unique,${analytics.profileViews.unique}\n`;
    
    // Revenue
    csv += `Revenue,Total,${analytics.revenue.total}\n`;
    csv += `Revenue,Projected Annual,${analytics.revenue.projectedAnnual}\n`;
    
    // Market Value
    csv += `Market Value,Estimated,${analytics.marketValue.estimated}\n`;
    csv += `Market Value,Percentile,${analytics.marketValue.percentile}\n`;
    
    return csv;
  }

  /**
   * Export analytics data to JSON
   */
  async exportToJSON(userId: string, timeframe: AnalyticsTimeframe): Promise<string> {
    const analytics = await this.getComprehensiveAnalytics(userId, timeframe);
    return JSON.stringify(analytics, null, 2);
  }
}

export const analytics = new AnalyticsService();
