import { Octokit } from '@octokit/rest';

export interface GitHubProfile {
  username: string;
  name: string;
  bio: string;
  avatar: string;
  location: string;
  publicRepos: number;
  followers: number;
  following: number;
  createdAt: string;
}

export interface GitHubRepo {
  id: number;
  name: string;
  fullName: string;
  description: string;
  language: string;
  stars: number;
  forks: number;
  openIssues: number;
  updatedAt: string;
  url: string;
}

export interface GitHubActivity {
  id: string;
  type: 'commit' | 'pr' | 'issue' | 'review';
  title: string;
  repository: string;
  date: string;
  languages: string[];
  impact: 'low' | 'medium' | 'high';
  linesAdded: number;
  linesRemoved: number;
  verified: boolean;
}

export interface GitHubContributions {
  totalCommits: number;
  totalPRs: number;
  totalIssues: number;
  totalReviews: number;
  languageBreakdown: Record<string, number>;
}

export class GitHubService {
  private octokit: Octokit;

  constructor(token?: string) {
    this.octokit = new Octokit({
      auth: token || process.env.GITHUB_TOKEN,
    });
  }

  /**
   * Fetch user profile from GitHub
   */
  async getProfile(username: string): Promise<GitHubProfile> {
    const { data } = await this.octokit.users.getByUsername({ username });

    return {
      username: data.login,
      name: data.name || data.login,
      bio: data.bio || '',
      avatar: data.avatar_url,
      location: data.location || '',
      publicRepos: data.public_repos,
      followers: data.followers,
      following: data.following,
      createdAt: data.created_at,
    };
  }

  /**
   * Fetch user repositories
   */
  async getRepositories(username: string, limit = 30): Promise<GitHubRepo[]> {
    const { data } = await this.octokit.repos.listForUser({
      username,
      sort: 'updated',
      per_page: limit,
    });

    return data.map(repo => ({
      id: repo.id,
      name: repo.name,
      fullName: repo.full_name,
      description: repo.description || '',
      language: repo.language || 'Unknown',
      stars: repo.stargazers_count || 0,
      forks: repo.forks_count || 0,
      openIssues: repo.open_issues_count || 0,
      updatedAt: repo.updated_at || new Date().toISOString(),
      url: repo.html_url,
    }));
  }

  /**
   * Fetch user activity
   */
  async getActivity(username: string, limit = 50): Promise<GitHubActivity[]> {
    const { data: events } = await this.octokit.activity.listPublicEventsForUser({
      username,
      per_page: limit,
    });

    const activities: GitHubActivity[] = [];

    for (const event of events) {
      let activity: GitHubActivity | null = null;

      switch (event.type) {
        case 'PushEvent':
          if ('commits' in event.payload && Array.isArray(event.payload.commits) && event.payload.commits.length > 0) {
            activity = {
              id: event.id,
              type: 'commit',
              title: event.payload.commits[0]?.message || 'Commit',
              repository: event.repo.name,
              date: event.created_at || new Date().toISOString(),
              languages: ['Unknown'],
              impact: event.payload.commits.length > 5 ? 'high' : 'medium',
              linesAdded: ('size' in event.payload && typeof event.payload.size === 'number') ? event.payload.size * 10 : 0,
              linesRemoved: ('size' in event.payload && typeof event.payload.size === 'number') ? event.payload.size * 5 : 0,
              verified: true,
            };
          }
          break;

        case 'PullRequestEvent':
          activity = {
            id: event.id,
            type: 'pr',
            title: ('pull_request' in event.payload && typeof event.payload.pull_request === 'object' && event.payload.pull_request && 'title' in event.payload.pull_request) ? String(event.payload.pull_request.title) : 'Pull Request',
            repository: event.repo.name,
            date: event.created_at || new Date().toISOString(),
            languages: [],
            impact: 'high',
            linesAdded: 0,
            linesRemoved: 0,
            verified: true,
          };
          break;

        case 'IssuesEvent':
          activity = {
            id: event.id,
            type: 'issue',
            title: ('issue' in event.payload && event.payload.issue?.title) || 'Issue',
            repository: event.repo.name,
            date: event.created_at || new Date().toISOString(),
            languages: [],
            impact: 'medium',
            linesAdded: 0,
            linesRemoved: 0,
            verified: true,
          };
          break;

        case 'PullRequestReviewEvent':
          activity = {
            id: event.id,
            type: 'review',
            title: 'Code Review',
            repository: event.repo.name,
            date: event.created_at || new Date().toISOString(),
            languages: [],
            impact: 'medium',
            linesAdded: 0,
            linesRemoved: 0,
            verified: true,
          };
          break;
      }

      if (activity) {
        activities.push(activity);
      }
    }

    return activities;
  }

  /**
   * Get contribution statistics
   */
  async getContributions(username: string): Promise<GitHubContributions> {
    const activity = await this.getActivity(username, 100);

    const stats = {
      totalCommits: 0,
      totalPRs: 0,
      totalIssues: 0,
      totalReviews: 0,
      languageBreakdown: {} as Record<string, number>,
    };

    for (const act of activity) {
      switch (act.type) {
        case 'commit':
          stats.totalCommits++;
          break;
        case 'pr':
          stats.totalPRs++;
          break;
        case 'issue':
          stats.totalIssues++;
          break;
        case 'review':
          stats.totalReviews++;
          break;
      }

      for (const lang of act.languages) {
        stats.languageBreakdown[lang] = (stats.languageBreakdown[lang] || 0) + 1;
      }
    }

    return stats;
  }

  /**
   * Calculate skill scores based on contributions
   */
  async calculateSkillScores(username: string): Promise<Record<string, number>> {
    const repos = await this.getRepositories(username);
    const contributions = await this.getContributions(username);

    const skills: Record<string, number> = {};

    // Analyze languages from repos
    for (const repo of repos) {
      if (repo.language && repo.language !== 'Unknown') {
        const weight = repo.stars + repo.forks + 1;
        skills[repo.language] = (skills[repo.language] || 0) + weight;
      }
    }

    // Normalize scores to 0-100
    const maxScore = Math.max(...Object.values(skills));
    for (const lang in skills) {
      skills[lang] = Math.min(100, Math.round((skills[lang] / maxScore) * 100));
    }

    return skills;
  }
}

// Export singleton instance
export const github = new GitHubService();
