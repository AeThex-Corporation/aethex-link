/**
 * Roblox API Integration Service
 * Fetches game stats, Robux earnings, and creator analytics
 */

export interface RobloxUser {
  id: number;
  username: string;
  displayName: string;
  description: string;
  created: string;
  isBanned: boolean;
  hasVerifiedBadge: boolean;
}

export interface RobloxGame {
  id: number;
  name: string;
  description: string;
  creator: {
    id: number;
    name: string;
    type: 'User' | 'Group';
  };
  rootPlaceId: number;
  totalUpVotes: number;
  totalDownVotes: number;
  created: string;
  updated: string;
  placeVisits: number;
  playing: number;
  visits: number;
  favoritedCount: number;
  thumbnailUrl?: string;
}

export interface RobloxEarnings {
  robuxEarned: number;
  pendingRobux: number;
  lifetimeEarnings: number;
  revenueByGame: Array<{
    gameId: number;
    gameName: string;
    revenue: number;
  }>;
}

export interface RobloxGroup {
  id: number;
  name: string;
  description: string;
  owner: {
    userId: number;
    username: string;
  };
  memberCount: number;
}

export class RobloxService {
  private apiKey?: string;
  private baseUrl = 'https://games.roblox.com/v1';
  private usersUrl = 'https://users.roblox.com/v1';
  private groupsUrl = 'https://groups.roblox.com/v1';

  constructor(apiKey?: string) {
    this.apiKey = apiKey;
  }

  /**
   * Get user profile information
   */
  async getUserProfile(username: string): Promise<RobloxUser | null> {
    try {
      // Search for user by username
      const searchResponse = await fetch(
        `${this.usersUrl}/users/search?keyword=${encodeURIComponent(username)}&limit=10`
      );
      
      if (!searchResponse.ok) {
        throw new Error('Failed to search for user');
      }

      const searchData = await searchResponse.json();
      const user = searchData.data?.find(
        (u: any) => u.name.toLowerCase() === username.toLowerCase()
      );

      if (!user) {
        return null;
      }

      // Get detailed user info
      const userResponse = await fetch(`${this.usersUrl}/users/${user.id}`);
      if (!userResponse.ok) {
        throw new Error('Failed to fetch user details');
      }

      return await userResponse.json();
    } catch (error) {
      console.error('Roblox user profile fetch error:', error);
      return null;
    }
  }

  /**
   * Get games created by user
   */
  async getUserGames(userId: number): Promise<RobloxGame[]> {
    try {
      const response = await fetch(
        `${this.baseUrl}/games?universeIds=&userId=${userId}&limit=50&sortOrder=Desc`
      );

      if (!response.ok) {
        throw new Error('Failed to fetch user games');
      }

      const data = await response.json();
      return data.data || [];
    } catch (error) {
      console.error('Roblox games fetch error:', error);
      return [];
    }
  }

  /**
   * Get game statistics
   */
  async getGameStats(universeId: number): Promise<any> {
    try {
      const response = await fetch(
        `${this.baseUrl}/games?universeIds=${universeId}`
      );

      if (!response.ok) {
        throw new Error('Failed to fetch game stats');
      }

      const data = await response.json();
      return data.data?.[0] || null;
    } catch (error) {
      console.error('Roblox game stats fetch error:', error);
      return null;
    }
  }

  /**
   * Get user groups (for verification of ownership)
   */
  async getUserGroups(userId: number): Promise<RobloxGroup[]> {
    try {
      const response = await fetch(
        `${this.groupsUrl}/users/${userId}/groups/roles`
      );

      if (!response.ok) {
        throw new Error('Failed to fetch user groups');
      }

      const data = await response.json();
      return data.data?.map((item: any) => item.group) || [];
    } catch (error) {
      console.error('Roblox groups fetch error:', error);
      return [];
    }
  }

  /**
   * Calculate aggregate statistics for a user
   */
  async calculateUserStats(username: string) {
    const user = await this.getUserProfile(username);
    if (!user) {
      return null;
    }

    const games = await this.getUserGames(user.id);
    const groups = await this.getUserGroups(user.id);

    const totalVisits = games.reduce((sum, game) => sum + (game.visits || 0), 0);
    const totalFavorites = games.reduce((sum, game) => sum + (game.favoritedCount || 0), 0);
    const totalUpvotes = games.reduce((sum, game) => sum + (game.totalUpVotes || 0), 0);

    return {
      user,
      games,
      groups,
      stats: {
        totalGames: games.length,
        totalVisits,
        totalFavorites,
        totalUpvotes,
        totalGroups: groups.length,
        avgVisitsPerGame: games.length > 0 ? Math.round(totalVisits / games.length) : 0,
      },
    };
  }

  /**
   * Get DevEx eligibility status
   */
  calculateDevExStatus(robuxEarned: number): {
    eligible: boolean;
    milestone: string;
    nextMilestone: number;
  } {
    const milestones = [
      { threshold: 100000, name: 'DevEx Eligible', next: 100000 },
      { threshold: 500000, name: 'Advanced Creator', next: 1000000 },
      { threshold: 1000000, name: 'Elite Creator', next: 5000000 },
      { threshold: 5000000, name: 'Top Creator', next: 10000000 },
      { threshold: 10000000, name: 'Master Creator', next: Infinity },
    ];

    for (let i = milestones.length - 1; i >= 0; i--) {
      if (robuxEarned >= milestones[i].threshold) {
        return {
          eligible: true,
          milestone: milestones[i].name,
          nextMilestone: milestones[i].next,
        };
      }
    }

    return {
      eligible: false,
      milestone: 'Not Eligible',
      nextMilestone: 100000,
    };
  }
}

// Export singleton instance
export const roblox = new RobloxService();
