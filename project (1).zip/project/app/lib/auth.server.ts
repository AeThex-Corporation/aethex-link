import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { db } from './db.server';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
const TOKEN_EXPIRY = '7d';

export interface AuthToken {
  userId: string;
  email: string;
}

export interface RegisterData {
  email: string;
  password: string;
  name: string;
  username: string;
}

export interface LoginData {
  email: string;
  password: string;
}

export const auth = {
  /**
   * Register a new user
   */
  async register(data: RegisterData) {
    // Check if user already exists
    const existingUser = await db.user.findByEmail(data.email);
    if (existingUser) {
      throw new Error('User with this email already exists');
    }

    const existingUsername = await db.user.findByUsername(data.username);
    if (existingUsername) {
      throw new Error('Username already taken');
    }

    // Hash password
    const passwordHash = await bcrypt.hash(data.password, 10);

    // Create user
    const user = await db.user.create({
      email: data.email,
      name: data.name,
      username: data.username,
      passwordHash,
      domainTier: 'free', // All new users start with free tier
    });

    // Create empty profile
    await db.profile.create({
      userId: user.id,
    });

    // Generate token
    const token = this.generateToken({
      userId: user.id,
      email: user.email,
    });

    return {
      user: this.sanitizeUser(user),
      token,
    };
  },

  /**
   * Login user
   */
  async login(data: LoginData) {
    const user = await db.user.findByEmail(data.email);
    if (!user) {
      throw new Error('Invalid email or password');
    }

    const isValidPassword = await bcrypt.compare(data.password, user.passwordHash);
    if (!isValidPassword) {
      throw new Error('Invalid email or password');
    }

    const token = this.generateToken({
      userId: user.id,
      email: user.email,
    });

    return {
      user: this.sanitizeUser(user),
      token,
    };
  },

  /**
   * Verify JWT token
   */
  async verifyToken(token: string): Promise<AuthToken | null> {
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as AuthToken;
      return decoded;
    } catch (error) {
      return null;
    }
  },

  /**
   * Get user from token
   */
  async getUserFromToken(token: string) {
    const decoded = await this.verifyToken(token);
    if (!decoded) return null;

    const user = await db.user.findById(decoded.userId);
    return user ? this.sanitizeUser(user) : null;
  },

  /**
   * Generate JWT token
   */
  generateToken(payload: AuthToken): string {
    return jwt.sign(payload, JWT_SECRET, { expiresIn: TOKEN_EXPIRY });
  },

  /**
   * Remove sensitive data from user object
   */
  sanitizeUser(user: any) {
    const { passwordHash, githubToken, ...sanitized } = user;
    return sanitized;
  },

  /**
   * Extract token from request headers
   */
  extractTokenFromRequest(request: Request): string | null {
    const authHeader = request.headers.get('Authorization');
    if (!authHeader) return null;

    const [type, token] = authHeader.split(' ');
    return type === 'Bearer' ? token : null;
  },

  /**
   * Require authentication middleware
   */
  async requireAuth(request: Request) {
    const token = this.extractTokenFromRequest(request);
    if (!token) {
      throw new Response('Unauthorized', { status: 401 });
    }

    const user = await this.getUserFromToken(token);
    if (!user) {
      throw new Response('Unauthorized', { status: 401 });
    }

    return user;
  },

  /**
   * Get optional user from request
   */
  async getOptionalUser(request: Request) {
    const token = this.extractTokenFromRequest(request);
    if (!token) return null;
    return this.getUserFromToken(token);
  },
};
