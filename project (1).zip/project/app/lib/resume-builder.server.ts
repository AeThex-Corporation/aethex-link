/**
 * Resume Builder Service
 * Auto-generates professional resumes from verified profile data
 */

export interface ResumeData {
  personalInfo: {
    name: string;
    title: string;
    email: string;
    phone?: string;
    location: string;
    website?: string;
    linkedin?: string;
    github?: string;
  };
  summary: string;
  experience: WorkExperience[];
  education: Education[];
  skills: SkillCategory[];
  projects: Project[];
  achievements: Achievement[];
  certifications?: Certification[];
}

export interface WorkExperience {
  company: string;
  position: string;
  startDate: string;
  endDate?: string;
  location: string;
  description: string;
  highlights: string[];
  technologies: string[];
}

export interface Education {
  institution: string;
  degree: string;
  field: string;
  startDate: string;
  endDate: string;
  gpa?: number;
  honors?: string[];
}

export interface SkillCategory {
  category: string;
  skills: string[];
}

export interface Project {
  name: string;
  description: string;
  role: string;
  technologies: string[];
  highlights: string[];
  url?: string;
  github?: string;
}

export interface Achievement {
  title: string;
  description: string;
  date: string;
  platform?: string;
}

export interface Certification {
  name: string;
  issuer: string;
  date: string;
  expiryDate?: string;
  credentialId?: string;
  url?: string;
}

export type ResumeTemplate = 'modern' | 'classic' | 'minimal' | 'technical' | 'executive';

export interface ResumeOptions {
  template: ResumeTemplate;
  includePhoto: boolean;
  colorScheme: 'blue' | 'green' | 'purple' | 'red' | 'black';
  fontSize: 'small' | 'medium' | 'large';
  includeLinks: boolean;
  atsOptimized: boolean; // Applicant Tracking System optimization
}

export class ResumeBuilderService {
  /**
   * Generate resume data from user profile
   */
  async generateResumeData(profileData: any): Promise<ResumeData> {
    return {
      personalInfo: {
        name: profileData.name,
        title: profileData.title,
        email: profileData.email || '',
        location: profileData.location,
        website: profileData.website,
        github: profileData.githubUsername,
      },
      summary: this.generateProfessionalSummary(profileData),
      experience: this.extractWorkExperience(profileData),
      education: this.extractEducation(profileData),
      skills: this.categorizeSkills(profileData.skills || []),
      projects: this.extractTopProjects(profileData),
      achievements: this.extractAchievements(profileData),
      certifications: this.extractCertifications(profileData),
    };
  }

  /**
   * Generate AI-powered professional summary
   */
  private generateProfessionalSummary(profileData: any): string {
    const experience = profileData.stats?.yearsOfExperience || 0;
    const topSkills = (profileData.skills || [])
      .sort((a: any, b: any) => b.level - a.level)
      .slice(0, 5)
      .map((s: any) => s.name);

    const contributions = profileData.stats?.totalContributions || 0;
    const reputation = profileData.stats?.stackOverflowReputation || 0;

    let summary = '';

    if (experience >= 5) {
      summary = `Experienced ${profileData.title} with ${experience}+ years of expertise in ${topSkills.slice(0, 3).join(', ')}. `;
    } else {
      summary = `${profileData.title} specializing in ${topSkills.slice(0, 3).join(', ')}. `;
    }

    if (contributions > 1000) {
      summary += `Proven track record with ${contributions.toLocaleString()}+ open source contributions. `;
    }

    if (reputation > 10000) {
      summary += `Active technical community member with ${reputation.toLocaleString()} Stack Overflow reputation. `;
    }

    summary += `Passionate about building scalable, high-performance applications and solving complex technical challenges.`;

    return summary;
  }

  /**
   * Extract and format work experience
   */
  private extractWorkExperience(profileData: any): WorkExperience[] {
    // In production, this would come from LinkedIn sync or manual entry
    // For now, generate from GitHub activity
    const experiences: WorkExperience[] = [];

    if (profileData.recentGitHubActivity && profileData.recentGitHubActivity.length > 0) {
      // Group by repository/organization
      const orgProjects = new Map<string, any[]>();
      
      for (const activity of profileData.recentGitHubActivity) {
        const org = activity.repository.split('/')[0];
        if (!orgProjects.has(org)) {
          orgProjects.set(org, []);
        }
        orgProjects.get(org)!.push(activity);
      }

      // Create experience entries for major contributions
      for (const [org, activities] of orgProjects) {
        if (activities.length >= 5) { // Significant contribution threshold
          const languages = [...new Set(activities.flatMap(a => a.languages))];
          const highlights = activities
            .filter(a => a.impact === 'high')
            .slice(0, 3)
            .map(a => a.title);

          experiences.push({
            company: org,
            position: 'Open Source Contributor',
            startDate: new Date(activities[activities.length - 1].date).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }),
            endDate: new Date(activities[0].date).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }),
            location: 'Remote',
            description: `Contributing to open source projects with ${activities.length} significant contributions`,
            highlights,
            technologies: languages,
          });
        }
      }
    }

    return experiences;
  }

  /**
   * Extract education information
   */
  private extractEducation(profileData: any): Education[] {
    // In production, this would come from LinkedIn or manual entry
    return profileData.education || [];
  }

  /**
   * Categorize skills by type
   */
  private categorizeSkills(skills: Array<{ name: string; category: string; level: number }>): SkillCategory[] {
    const categories = new Map<string, string[]>();

    for (const skill of skills) {
      if (skill.level >= 60) { // Only include proficient skills
        if (!categories.has(skill.category)) {
          categories.set(skill.category, []);
        }
        categories.get(skill.category)!.push(skill.name);
      }
    }

    return Array.from(categories.entries()).map(([category, skillList]) => ({
      category,
      skills: skillList,
    }));
  }

  /**
   * Extract top projects
   */
  private extractTopProjects(profileData: any): Project[] {
    const projects: Project[] = [];

    // From GitHub (high-impact contributions)
    if (profileData.recentGitHubActivity) {
      const highImpactProjects = profileData.recentGitHubActivity
        .filter((a: any) => a.impact === 'high')
        .slice(0, 5);

      for (const activity of highImpactProjects) {
        projects.push({
          name: activity.repository,
          description: activity.title,
          role: 'Contributor',
          technologies: activity.languages,
          highlights: [`${activity.linesAdded || 0} lines added, ${activity.linesRemoved || 0} removed`],
          github: `https://github.com/${activity.repository}`,
        });
      }
    }

    return projects;
  }

  /**
   * Extract notable achievements
   */
  private extractAchievements(profileData: any): Achievement[] {
    const achievements: Achievement[] = [];

    // GitHub contributions
    if (profileData.stats?.totalContributions > 500) {
      achievements.push({
        title: `${profileData.stats.totalContributions}+ Open Source Contributions`,
        description: 'Active contributor to open source projects on GitHub',
        date: new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' }),
        platform: 'GitHub',
      });
    }

    // Stack Overflow reputation
    if (profileData.stats?.stackOverflowReputation > 1000) {
      achievements.push({
        title: `${profileData.stats.stackOverflowReputation.toLocaleString()} Stack Overflow Reputation`,
        description: 'Top contributor in technical Q&A community',
        date: new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' }),
        platform: 'Stack Overflow',
      });
    }

    // Blog/articles
    if (profileData.stats?.blogPosts > 10) {
      achievements.push({
        title: `${profileData.stats.blogPosts} Technical Articles Published`,
        description: 'Technical writing and knowledge sharing',
        date: new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' }),
      });
    }

    return achievements;
  }

  /**
   * Extract certifications
   */
  private extractCertifications(profileData: any): Certification[] {
    return profileData.certifications || [];
  }

  /**
   * Generate resume as HTML (for PDF conversion)
   */
  async generateHTML(resumeData: ResumeData, options: ResumeOptions): Promise<string> {
    const template = this.getTemplate(options.template);
    return this.renderTemplate(template, resumeData, options);
  }

  /**
   * Optimize resume for ATS (Applicant Tracking Systems)
   */
  optimizeForATS(resumeData: ResumeData): ResumeData {
    // ATS optimization rules:
    // 1. Remove complex formatting
    // 2. Use standard section headers
    // 3. Include keywords from job description
    // 4. Simple, linear layout
    // 5. Standard fonts
    // 6. No graphics, tables, or columns

    return {
      ...resumeData,
      // Flatten skills for better ATS parsing
      skills: resumeData.skills.map(category => ({
        ...category,
        skills: category.skills.sort(), // Alphabetical order
      })),
    };
  }

  /**
   * Tailor resume to specific job description
   */
  async tailorToJobDescription(
    resumeData: ResumeData,
    jobDescription: string
  ): Promise<ResumeData> {
    // Extract keywords from job description
    const keywords = this.extractKeywords(jobDescription);
    
    // Prioritize relevant skills
    const relevantSkills = resumeData.skills.map(category => ({
      ...category,
      skills: category.skills.sort((a, b) => {
        const aRelevant = keywords.some(kw => a.toLowerCase().includes(kw.toLowerCase()));
        const bRelevant = keywords.some(kw => b.toLowerCase().includes(kw.toLowerCase()));
        if (aRelevant && !bRelevant) return -1;
        if (!aRelevant && bRelevant) return 1;
        return 0;
      }),
    }));

    // Highlight relevant experience
    const relevantExperience = resumeData.experience.map(exp => ({
      ...exp,
      highlights: exp.highlights.filter(h => 
        keywords.some(kw => h.toLowerCase().includes(kw.toLowerCase()))
      ),
    }));

    return {
      ...resumeData,
      skills: relevantSkills,
      experience: relevantExperience,
    };
  }

  /**
   * Calculate resume match score for job description
   */
  calculateMatchScore(resumeData: ResumeData, jobDescription: string): {
    score: number;
    matchedKeywords: string[];
    missingKeywords: string[];
    suggestions: string[];
  } {
    const jobKeywords = this.extractKeywords(jobDescription);
    const resumeText = JSON.stringify(resumeData).toLowerCase();
    
    const matchedKeywords = jobKeywords.filter(kw => 
      resumeText.includes(kw.toLowerCase())
    );
    
    const missingKeywords = jobKeywords.filter(kw => 
      !resumeText.includes(kw.toLowerCase())
    );

    const score = Math.round((matchedKeywords.length / jobKeywords.length) * 100);

    const suggestions = [];
    if (missingKeywords.length > 0) {
      suggestions.push(`Consider highlighting these skills: ${missingKeywords.slice(0, 5).join(', ')}`);
    }
    if (score < 70) {
      suggestions.push('Tailor your experience descriptions to match job requirements');
    }

    return {
      score,
      matchedKeywords,
      missingKeywords,
      suggestions,
    };
  }

  // Helper methods

  private getTemplate(templateName: ResumeTemplate): string {
    // In production, these would be full HTML templates
    return templateName;
  }

  private renderTemplate(template: string, data: ResumeData, options: ResumeOptions): string {
    // In production, this would use a templating engine
    return `<html><!-- Resume for ${data.personalInfo.name} --></html>`;
  }

  private extractKeywords(text: string): string[] {
    // Simple keyword extraction (in production, use NLP)
    const words = text.toLowerCase().split(/\W+/);
    const commonWords = new Set(['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for']);
    const keywords = words.filter(w => w.length > 3 && !commonWords.has(w));
    
    // Return unique keywords
    return [...new Set(keywords)];
  }
}

export const resumeBuilder = new ResumeBuilderService();
