/**
 * GitLab API integration
 */

export interface GitLabProject {
  id: number;
  name: string;
  description: string;
  stars: number;
  forks: number;
  url: string;
  language: string;
  lastActivity: string;
}

export interface GitLabProfile {
  username: string;
  name: string;
  bio: string;
  avatarUrl: string;
  projects: GitLabProject[];
  totalStars: number;
  totalCommits: number;
  followers: number;
}

export class GitLabService {
  private readonly baseUrl = 'https://gitlab.com/api/v4';
  private token?: string;

  constructor(token?: string) {
    this.token = token;
  }

  private async request<T>(endpoint: string): Promise<T> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    const response = await fetch(`${this.baseUrl}${endpoint}`, { headers });

    if (!response.ok) {
      throw new Error(`GitLab API error: ${response.statusText}`);
    }

    return response.json();
  }

  async getUserProfile(username: string): Promise<GitLabProfile> {
    try {
      // Get user data
      const users = await this.request<any[]>(`/users?username=${username}`);
      
      if (!users || users.length === 0) {
        throw new Error('User not found');
      }

      const user = users[0];
      const userId = user.id;

      // Get user's projects
      const projects = await this.request<any[]>(
        `/users/${userId}/projects?per_page=100&order_by=updated_at`
      );

      const mappedProjects: GitLabProject[] = projects.map(project => ({
        id: project.id,
        name: project.name,
        description: project.description || '',
        stars: project.star_count || 0,
        forks: project.forks_count || 0,
        url: project.web_url,
        language: project.languages?.[0] || 'Unknown',
        lastActivity: project.last_activity_at,
      }));

      const totalStars = mappedProjects.reduce((sum, p) => sum + p.stars, 0);

      // Get contribution stats
      let totalCommits = 0;
      try {
        const events = await this.request<any[]>(
          `/users/${userId}/events?per_page=100`
        );
        totalCommits = events.filter(e => e.action_name === 'pushed to').length;
      } catch (err) {
        console.warn('Failed to fetch GitLab events');
      }

      return {
        username: user.username,
        name: user.name,
        bio: user.bio || '',
        avatarUrl: user.avatar_url,
        projects: mappedProjects.sort((a, b) => b.stars - a.stars),
        totalStars,
        totalCommits,
        followers: 0, // GitLab API doesn't expose follower count easily
      };
    } catch (error: any) {
      console.error('GitLab API Error:', error);
      throw new Error(`Failed to fetch GitLab data: ${error.message}`);
    }
  }
}

// Export singleton instance
export const gitlab = new GitLabService();
