/**
 * Smart Job Matching Service
 * ML-based algorithm to match developers with job opportunities
 */

export interface JobPosting {
  id: string;
  title: string;
  company: string;
  location: string;
  remote: boolean;
  salary: {
    min: number;
    max: number;
    currency: string;
  };
  requiredSkills: string[];
  preferredSkills: string[];
  experience: {
    min: number;
    max: number;
  };
  description: string;
  benefits: string[];
  postedDate: Date;
  applicationDeadline?: Date;
}

export interface JobMatchResult {
  job: JobPosting;
  matchScore: number; // 0-100
  breakdown: {
    skillsMatch: number;
    experienceMatch: number;
    locationMatch: number;
    salaryMatch: number;
  };
  strengths: string[];
  gaps: SkillGap[];
  recommendations: string[];
  estimatedTimeToQualify?: string;
}

export interface SkillGap {
  skill: string;
  required: boolean; // vs preferred
  currentLevel: number;
  requiredLevel: number;
  timeToLearn: string;
  resources: LearningResource[];
}

export interface LearningResource {
  title: string;
  type: 'course' | 'book' | 'tutorial' | 'documentation';
  url: string;
  platform: string;
  duration?: string;
}

export interface DeveloperProfile {
  skills: Array<{ name: string; level: number }>;
  experience: number; // years
  location: string;
  remotePreference: boolean;
  salaryExpectation: {
    min: number;
    max: number;
    currency: string;
  };
  willingToRelocate: boolean;
}

export class JobMatchingService {
  /**
   * Find best matching jobs for a developer
   */
  async findMatchingJobs(
    profile: DeveloperProfile,
    availableJobs: JobPosting[],
    limit = 20
  ): Promise<JobMatchResult[]> {
    const matches: JobMatchResult[] = [];

    for (const job of availableJobs) {
      const matchResult = this.calculateMatch(profile, job);
      
      if (matchResult.matchScore >= 50) { // Minimum threshold
        matches.push(matchResult);
      }
    }

    // Sort by match score
    matches.sort((a, b) => b.matchScore - a.matchScore);

    return matches.slice(0, limit);
  }

  /**
   * Calculate detailed match score between profile and job
   */
  private calculateMatch(profile: DeveloperProfile, job: JobPosting): JobMatchResult {
    // Calculate component scores
    const skillsMatch = this.calculateSkillsMatch(profile.skills, job);
    const experienceMatch = this.calculateExperienceMatch(profile.experience, job.experience);
    const locationMatch = this.calculateLocationMatch(profile, job);
    const salaryMatch = this.calculateSalaryMatch(profile.salaryExpectation, job.salary);

    // Weighted overall score
    const weights = {
      skills: 0.45,
      experience: 0.25,
      location: 0.15,
      salary: 0.15,
    };

    const matchScore = Math.round(
      skillsMatch * weights.skills +
      experienceMatch * weights.experience +
      locationMatch * weights.location +
      salaryMatch * weights.salary
    );

    // Identify strengths and gaps
    const { strengths, gaps } = this.analyzeSkillAlignment(profile.skills, job);

    // Generate recommendations
    const recommendations = this.generateRecommendations(matchScore, gaps, job);

    // Estimate time to qualify if not fully qualified
    const estimatedTimeToQualify = gaps.length > 0 
      ? this.estimateTimeToQualify(gaps)
      : undefined;

    return {
      job,
      matchScore,
      breakdown: {
        skillsMatch,
        experienceMatch,
        locationMatch,
        salaryMatch,
      },
      strengths,
      gaps,
      recommendations,
      estimatedTimeToQualify,
    };
  }

  /**
   * Calculate skills match score using cosine similarity
   */
  private calculateSkillsMatch(
    profileSkills: Array<{ name: string; level: number }>,
    job: JobPosting
  ): number {
    const allSkills = [...job.requiredSkills, ...job.preferredSkills];
    const profileSkillMap = new Map(
      profileSkills.map(s => [s.name.toLowerCase(), s.level])
    );

    let totalMatch = 0;
    let totalWeight = 0;

    // Required skills have higher weight
    for (const skill of job.requiredSkills) {
      const weight = 2;
      const profileLevel = profileSkillMap.get(skill.toLowerCase()) || 0;
      const match = Math.min(profileLevel, 100);
      totalMatch += match * weight;
      totalWeight += 100 * weight;
    }

    // Preferred skills
    for (const skill of job.preferredSkills) {
      const weight = 1;
      const profileLevel = profileSkillMap.get(skill.toLowerCase()) || 0;
      const match = Math.min(profileLevel, 100);
      totalMatch += match * weight;
      totalWeight += 100 * weight;
    }

    return totalWeight > 0 ? Math.round((totalMatch / totalWeight) * 100) : 0;
  }

  /**
   * Calculate experience match
   */
  private calculateExperienceMatch(
    profileExperience: number,
    jobExperience: { min: number; max: number }
  ): number {
    if (profileExperience >= jobExperience.min && profileExperience <= jobExperience.max) {
      return 100; // Perfect match
    }

    if (profileExperience < jobExperience.min) {
      const gap = jobExperience.min - profileExperience;
      return Math.max(0, 100 - (gap * 15)); // 15% penalty per year under
    }

    if (profileExperience > jobExperience.max) {
      const excess = profileExperience - jobExperience.max;
      return Math.max(70, 100 - (excess * 5)); // 5% penalty per year over (capped at 70)
    }

    return 0;
  }

  /**
   * Calculate location match
   */
  private calculateLocationMatch(profile: DeveloperProfile, job: JobPosting): number {
    if (job.remote && profile.remotePreference) {
      return 100; // Perfect match for remote
    }

    if (job.remote && !profile.remotePreference) {
      return 90; // Remote available but not preferred
    }

    if (!job.remote && profile.remotePreference && !profile.willingToRelocate) {
      return 30; // Location mismatch
    }

    if (profile.location.toLowerCase() === job.location.toLowerCase()) {
      return 100; // Same location
    }

    if (profile.willingToRelocate) {
      return 70; // Willing to relocate
    }

    return 20; // Location mismatch, not willing to relocate
  }

  /**
   * Calculate salary match
   */
  private calculateSalaryMatch(
    profileExpectation: { min: number; max: number; currency: string },
    jobSalary: { min: number; max: number; currency: string }
  ): number {
    if (profileExpectation.currency !== jobSalary.currency) {
      return 50; // Currency mismatch (would need conversion in production)
    }

    // Check for overlap in ranges
    const overlapMin = Math.max(profileExpectation.min, jobSalary.min);
    const overlapMax = Math.min(profileExpectation.max, jobSalary.max);

    if (overlapMax >= overlapMin) {
      // There's an overlap
      const overlapSize = overlapMax - overlapMin;
      const profileRange = profileExpectation.max - profileExpectation.min;
      const overlapPercentage = (overlapSize / profileRange) * 100;
      return Math.min(100, 70 + overlapPercentage * 0.3); // 70-100 based on overlap
    }

    // No overlap
    if (jobSalary.max < profileExpectation.min) {
      const gap = profileExpectation.min - jobSalary.max;
      const gapPercentage = (gap / profileExpectation.min) * 100;
      return Math.max(0, 50 - gapPercentage); // Job pays too little
    }

    // Job pays more than expected
    return 80;
  }

  /**
   * Analyze skill alignment
   */
  private analyzeSkillAlignment(
    profileSkills: Array<{ name: string; level: number }>,
    job: JobPosting
  ): { strengths: string[]; gaps: SkillGap[] } {
    const strengths: string[] = [];
    const gaps: SkillGap[] = [];
    const profileSkillMap = new Map(
      profileSkills.map(s => [s.name.toLowerCase(), s.level])
    );

    // Check required skills
    for (const skill of job.requiredSkills) {
      const profileLevel = profileSkillMap.get(skill.toLowerCase()) || 0;
      
      if (profileLevel >= 70) {
        strengths.push(`Strong ${skill} skills (${profileLevel}%)`);
      } else {
        gaps.push({
          skill,
          required: true,
          currentLevel: profileLevel,
          requiredLevel: 70,
          timeToLearn: this.estimateTimeToLearnSkill(profileLevel, 70),
          resources: this.findLearningResources(skill),
        });
      }
    }

    // Check preferred skills
    for (const skill of job.preferredSkills) {
      const profileLevel = profileSkillMap.get(skill.toLowerCase()) || 0;
      
      if (profileLevel >= 60) {
        strengths.push(`Good ${skill} knowledge (${profileLevel}%)`);
      } else if (profileLevel < 40) {
        gaps.push({
          skill,
          required: false,
          currentLevel: profileLevel,
          requiredLevel: 60,
          timeToLearn: this.estimateTimeToLearnSkill(profileLevel, 60),
          resources: this.findLearningResources(skill),
        });
      }
    }

    return { strengths, gaps };
  }

  /**
   * Generate personalized recommendations
   */
  private generateRecommendations(
    matchScore: number,
    gaps: SkillGap[],
    job: JobPosting
  ): string[] {
    const recommendations: string[] = [];

    if (matchScore >= 80) {
      recommendations.push('Excellent match! You should definitely apply.');
      recommendations.push('Highlight your strongest matching skills in your application.');
    } else if (matchScore >= 65) {
      recommendations.push('Good match. Consider applying with a strong cover letter.');
      if (gaps.length > 0) {
        const requiredGaps = gaps.filter(g => g.required);
        if (requiredGaps.length > 0) {
          recommendations.push(`Focus on improving: ${requiredGaps.map(g => g.skill).join(', ')}`);
        }
      }
    } else if (matchScore >= 50) {
      recommendations.push('Moderate match. Consider upskilling before applying.');
      const criticalGaps = gaps.filter(g => g.required && g.currentLevel < 50);
      if (criticalGaps.length > 0) {
        recommendations.push(`Critical skills to learn: ${criticalGaps.map(g => g.skill).join(', ')}`);
      }
    } else {
      recommendations.push('Not recommended to apply at this time.');
      recommendations.push('Focus on building foundational skills first.');
    }

    return recommendations;
  }

  /**
   * Estimate time to qualify for job
   */
  private estimateTimeToQualify(gaps: SkillGap[]): string {
    const requiredGaps = gaps.filter(g => g.required);
    
    if (requiredGaps.length === 0) {
      return 'Already qualified!';
    }

    // Parse time estimates and find max
    let maxMonths = 0;
    for (const gap of requiredGaps) {
      const months = this.parseTimeEstimate(gap.timeToLearn);
      if (months > maxMonths) {
        maxMonths = months;
      }
    }

    if (maxMonths < 3) return '1-2 months with focused learning';
    if (maxMonths < 6) return '3-5 months with consistent effort';
    if (maxMonths < 12) return '6-11 months of dedicated learning';
    return '1+ year of skill development needed';
  }

  /**
   * Estimate time to learn skill gap
   */
  private estimateTimeToLearnSkill(currentLevel: number, targetLevel: number): string {
    const gap = targetLevel - currentLevel;
    
    if (gap <= 10) return '2-4 weeks';
    if (gap <= 20) return '1-2 months';
    if (gap <= 40) return '2-4 months';
    if (gap <= 60) return '4-6 months';
    return '6-12 months';
  }

  /**
   * Parse time estimate to months
   */
  private parseTimeEstimate(estimate: string): number {
    if (estimate.includes('week')) {
      const weeks = parseInt(estimate) || 2;
      return weeks / 4;
    }
    if (estimate.includes('month')) {
      const match = estimate.match(/(\d+)/);
      return match ? parseInt(match[0]) : 3;
    }
    if (estimate.includes('year')) {
      return 12;
    }
    return 3; // default
  }

  /**
   * Find learning resources for a skill
   */
  private findLearningResources(skill: string): LearningResource[] {
    // In production, this would query a real database
    return [
      {
        title: `Learn ${skill}`,
        type: 'course',
        url: `https://www.udemy.com/courses/search/?q=${encodeURIComponent(skill)}`,
        platform: 'Udemy',
        duration: '10-20 hours',
      },
      {
        title: `${skill} Documentation`,
        type: 'documentation',
        url: `https://www.google.com/search?q=${encodeURIComponent(skill + ' documentation')}`,
        platform: 'Official Docs',
      },
    ];
  }

  /**
   * Get job recommendations based on career goals
   */
  async getCareerBasedRecommendations(
    profile: DeveloperProfile,
    careerGoal: 'senior' | 'lead' | 'architect' | 'manager',
    availableJobs: JobPosting[]
  ): Promise<JobMatchResult[]> {
    // Filter jobs that align with career progression
    const relevantJobs = availableJobs.filter(job => {
      const title = job.title.toLowerCase();
      
      switch (careerGoal) {
        case 'senior':
          return title.includes('senior') || title.includes('sr.');
        case 'lead':
          return title.includes('lead') || title.includes('principal');
        case 'architect':
          return title.includes('architect') || title.includes('principal');
        case 'manager':
          return title.includes('manager') || title.includes('director');
        default:
          return true;
      }
    });

    return this.findMatchingJobs(profile, relevantJobs);
  }
}

export const jobMatching = new JobMatchingService();
