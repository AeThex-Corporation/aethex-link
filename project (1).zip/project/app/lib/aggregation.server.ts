/**
 * Profile Aggregation Service
 * 
 * Automatically syncs and aggregates data from all connected platforms
 */

import { github } from './github.server';
import { stackoverflow } from './stackoverflow.server';
import { roblox } from './roblox.server';
import { unity } from './unity.server';
import { huggingface } from './huggingface.server';
import { kaggle } from './kaggle.server';
import { npm } from './npm.server';
import { pypi } from './pypi.server';
import { gitlab } from './gitlab.server';
import { devto } from './devto.server';
import { medium } from './medium.server';
import { db } from './db.server';

export interface AggregatedProfile {
  userId: string;
  platforms: {
    github?: any;
    stackoverflow?: any;
    roblox?: any;
    unity?: any;
    huggingface?: any;
    kaggle?: any;
    npm?: any;
    pypi?: any;
    gitlab?: any;
    devto?: any;
    medium?: any;
  };
  skills: Array<{
    name: string;
    level: number;
    sources: string[];
  }>;
  projects: Array<{
    title: string;
    description: string;
    url: string;
    platform: string;
    stars?: number;
    downloads?: number;
  }>;
  achievements: Array<{
    title: string;
    description: string;
    platform: string;
    date: Date;
    rarity: 'common' | 'rare' | 'epic' | 'legendary';
  }>;
  stats: {
    totalContributions: number;
    totalReach: number;
    totalRevenue: number;
    activeProjects: number;
  };
  lastSync: Date;
}

class AggregationService {
  /**
   * Sync all platform data for a user
   */
  async syncAllPlatforms(userId: string): Promise<AggregatedProfile> {
    console.log(`Starting full sync for user ${userId}...`);
    
    const user = await db.user.findUnique({
      where: { id: userId },
      include: { connections: true },
    });

    if (!user) {
      throw new Error('User not found');
    }

    const platformData: any = {};
    const connections = user.connections || [];

    // Sync all connected platforms in parallel
    const syncPromises = connections.map(async (connection) => {
      try {
        switch (connection.platform) {
          case 'github':
            if (connection.username) {
              platformData.github = await github.getUserProfile(connection.username);
            }
            break;
          case 'stackoverflow':
            if (connection.platformUserId) {
              platformData.stackoverflow = await stackoverflow.getUserProfile(connection.platformUserId);
            }
            break;
          case 'roblox':
            if (connection.username) {
              platformData.roblox = await roblox.getUserProfile(connection.username);
            }
            break;
          case 'unity':
            if (connection.username) {
              platformData.unity = await unity.getPublisherProfile(connection.username);
            }
            break;
          case 'huggingface':
            if (connection.username) {
              platformData.huggingface = await huggingface.getUserProfile(connection.username);
            }
            break;
          case 'kaggle':
            if (connection.username) {
              platformData.kaggle = await kaggle.getUserProfile(connection.username);
            }
            break;
          case 'npm':
            if (connection.username) {
              platformData.npm = await npm.getUserProfile(connection.username);
            }
            break;
          case 'pypi':
            if (connection.username) {
              platformData.pypi = await pypi.getUserProfile(connection.username);
            }
            break;
          case 'gitlab':
            if (connection.username) {
              platformData.gitlab = await gitlab.getUserProfile(connection.username);
            }
            break;
          case 'devto':
            if (connection.username) {
              platformData.devto = await devto.getUserProfile(connection.username);
            }
            break;
          case 'medium':
            if (connection.username) {
              platformData.medium = await medium.getUserProfile(connection.username);
            }
            break;
        }
        console.log(`✓ Synced ${connection.platform}`);
      } catch (error) {
        console.error(`✗ Failed to sync ${connection.platform}:`, error);
      }
    });

    await Promise.all(syncPromises);

    // Aggregate skills from all platforms
    const skills = this.aggregateSkills(platformData);
    
    // Aggregate projects
    const projects = this.aggregateProjects(platformData);
    
    // Detect achievements
    const achievements = this.detectAchievements(platformData);
    
    // Calculate stats
    const stats = this.calculateStats(platformData);

    const aggregatedProfile: AggregatedProfile = {
      userId,
      platforms: platformData,
      skills,
      projects,
      achievements,
      stats,
      lastSync: new Date(),
    };

    // Store aggregated data
    await this.storeAggregatedData(userId, aggregatedProfile);

    console.log(`✓ Full sync complete for user ${userId}`);
    return aggregatedProfile;
  }

  /**
   * Aggregate skills from all platforms
   */
  private aggregateSkills(platformData: any): Array<{ name: string; level: number; sources: string[] }> {
    const skillMap = new Map<string, { level: number; sources: Set<string> }>();

    // GitHub languages
    if (platformData.github?.languages) {
      Object.entries(platformData.github.languages).forEach(([lang, percentage]: [string, any]) => {
        const existing = skillMap.get(lang) || { level: 0, sources: new Set() };
        existing.level = Math.max(existing.level, Math.round(percentage as number));
        existing.sources.add('GitHub');
        skillMap.set(lang, existing);
      });
    }

    // Stack Overflow tags
    if (platformData.stackoverflow?.topTags) {
      platformData.stackoverflow.topTags.forEach((tag: any) => {
        const existing = skillMap.get(tag.name) || { level: 0, sources: new Set() };
        existing.level = Math.max(existing.level, Math.min(tag.count * 2, 100));
        existing.sources.add('Stack Overflow');
        skillMap.set(tag.name, existing);
      });
    }

    // Kaggle skills
    if (platformData.kaggle?.tier) {
      const mlLevel = platformData.kaggle.tier === 'Grandmaster' ? 95 : 
                      platformData.kaggle.tier === 'Master' ? 85 : 
                      platformData.kaggle.tier === 'Expert' ? 75 : 60;
      skillMap.set('Machine Learning', { level: mlLevel, sources: new Set(['Kaggle']) });
      skillMap.set('Data Science', { level: mlLevel - 5, sources: new Set(['Kaggle']) });
    }

    // Game dev skills
    if (platformData.roblox) {
      skillMap.set('Game Development', { level: 80, sources: new Set(['Roblox']) });
      skillMap.set('Lua', { level: 75, sources: new Set(['Roblox']) });
    }

    if (platformData.unity) {
      const existing = skillMap.get('Game Development') || { level: 0, sources: new Set() };
      existing.level = Math.max(existing.level, 85);
      existing.sources.add('Unity');
      skillMap.set('Game Development', existing);
      skillMap.set('C#', { level: 80, sources: new Set(['Unity']) });
    }

    return Array.from(skillMap.entries()).map(([name, data]) => ({
      name,
      level: data.level,
      sources: Array.from(data.sources),
    })).sort((a, b) => b.level - a.level);
  }

  /**
   * Aggregate projects from all platforms
   */
  private aggregateProjects(platformData: any): Array<{
    title: string;
    description: string;
    url: string;
    platform: string;
    stars?: number;
    downloads?: number;
  }> {
    const projects = [];

    // GitHub repos
    if (platformData.github?.topRepos) {
      platformData.github.topRepos.forEach((repo: any) => {
        projects.push({
          title: repo.name,
          description: repo.description,
          url: repo.url,
          platform: 'GitHub',
          stars: repo.stars,
        });
      });
    }

    // npm packages
    if (platformData.npm?.packages) {
      platformData.npm.packages.forEach((pkg: any) => {
        projects.push({
          title: pkg.name,
          description: pkg.description,
          url: `https://npmjs.com/package/${pkg.name}`,
          platform: 'npm',
          downloads: pkg.downloads,
        });
      });
    }

    // Unity assets
    if (platformData.unity?.assets) {
      platformData.unity.assets.forEach((asset: any) => {
        projects.push({
          title: asset.name,
          description: asset.description,
          url: asset.url,
          platform: 'Unity',
          downloads: asset.downloads,
        });
      });
    }

    // Roblox games
    if (platformData.roblox?.games) {
      platformData.roblox.games.forEach((game: any) => {
        projects.push({
          title: game.name,
          description: game.description,
          url: game.url,
          platform: 'Roblox',
          stars: game.visits,
        });
      });
    }

    return projects;
  }

  /**
   * Detect achievements based on platform data
   */
  private detectAchievements(platformData: any): Array<{
    title: string;
    description: string;
    platform: string;
    date: Date;
    rarity: 'common' | 'rare' | 'epic' | 'legendary';
  }> {
    const achievements = [];

    // GitHub achievements
    if (platformData.github) {
      if (platformData.github.followers > 1000) {
        achievements.push({
          title: 'GitHub Influencer',
          description: '1,000+ followers',
          platform: 'GitHub',
          date: new Date(),
          rarity: 'epic' as const,
        });
      }
      if (platformData.github.totalStars > 10000) {
        achievements.push({
          title: 'Star Collector',
          description: '10,000+ total stars',
          platform: 'GitHub',
          date: new Date(),
          rarity: 'legendary' as const,
        });
      }
    }

    // Stack Overflow achievements
    if (platformData.stackoverflow) {
      if (platformData.stackoverflow.reputation > 10000) {
        achievements.push({
          title: 'SO Expert',
          description: '10,000+ reputation',
          platform: 'Stack Overflow',
          date: new Date(),
          rarity: 'epic' as const,
        });
      }
    }

    // Kaggle achievements
    if (platformData.kaggle?.tier === 'Grandmaster') {
      achievements.push({
        title: 'Kaggle Grandmaster',
        description: 'Achieved Grandmaster rank',
        platform: 'Kaggle',
        date: new Date(),
        rarity: 'legendary' as const,
      });
    }

    return achievements;
  }

  /**
   * Calculate aggregate stats
   */
  private calculateStats(platformData: any): {
    totalContributions: number;
    totalReach: number;
    totalRevenue: number;
    activeProjects: number;
  } {
    let totalContributions = 0;
    let totalReach = 0;
    let totalRevenue = 0;
    let activeProjects = 0;

    if (platformData.github) {
      totalContributions += platformData.github.contributions || 0;
      totalReach += platformData.github.followers || 0;
      activeProjects += platformData.github.publicRepos || 0;
    }

    if (platformData.stackoverflow) {
      totalReach += platformData.stackoverflow.reputation || 0;
    }

    if (platformData.roblox) {
      totalReach += platformData.roblox.totalVisits || 0;
      totalRevenue += platformData.roblox.revenue || 0;
    }

    if (platformData.unity) {
      totalRevenue += platformData.unity.revenue || 0;
      activeProjects += platformData.unity.assetCount || 0;
    }

    return {
      totalContributions,
      totalReach,
      totalRevenue,
      activeProjects,
    };
  }

  /**
   * Store aggregated data in database
   */
  private async storeAggregatedData(userId: string, profile: AggregatedProfile): Promise<void> {
    try {
      // Update user's last sync timestamp
      await db.user.update({
        where: { id: userId },
        data: {
          lastSyncedAt: profile.lastSync,
        },
      });

      // Store could be expanded to cache aggregated data
      console.log('✓ Stored aggregated data');
    } catch (error) {
      console.error('Failed to store aggregated data:', error);
    }
  }

  /**
   * Schedule auto-sync for a user
   */
  async scheduleAutoSync(userId: string, intervalHours: number = 24): Promise<void> {
    // In production, this would use a job queue like Bull or Agenda
    console.log(`Scheduled auto-sync for user ${userId} every ${intervalHours} hours`);
  }
}

export const aggregation = new AggregationService();
