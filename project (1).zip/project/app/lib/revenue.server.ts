/**
 * Revenue Tracking Service
 * 
 * Aggregates revenue from all monetization sources
 */

import { roblox } from './roblox.server';
import { unity } from './unity.server';
import { db } from './db.server';

export interface RevenueSource {
  platform: string;
  amount: number;
  currency: string;
  period: 'daily' | 'weekly' | 'monthly' | 'yearly';
  lastUpdated: Date;
}

export interface RevenueBreakdown {
  total: number;
  byPlatform: Record<string, number>;
  byCategory: Record<string, number>;
  trend: Array<{ date: string; amount: number }>;
  projections: {
    nextMonth: number;
    nextQuarter: number;
    nextYear: number;
  };
}

class RevenueService {
  /**
   * Get comprehensive revenue data for a user
   */
  async getRevenueBreakdown(userId: string): Promise<RevenueBreakdown> {
    const user = await db.user.findUnique({
      where: { id: userId },
      include: { connections: true },
    });

    if (!user) {
      throw new Error('User not found');
    }

    const sources: RevenueSource[] = [];

    // Get Roblox revenue
    const robloxConnection = user.connections?.find(c => c.platform === 'roblox');
    if (robloxConnection?.username) {
      try {
        const robloxData = await roblox.getUserProfile(robloxConnection.username);
        if (robloxData.revenue) {
          sources.push({
            platform: 'Roblox',
            amount: robloxData.revenue,
            currency: 'USD',
            period: 'monthly',
            lastUpdated: new Date(),
          });
        }
      } catch (error) {
        console.error('Failed to fetch Roblox revenue:', error);
      }
    }

    // Get Unity revenue
    const unityConnection = user.connections?.find(c => c.platform === 'unity');
    if (unityConnection?.username) {
      try {
        const unityData = await unity.getPublisherProfile(unityConnection.username);
        if (unityData.revenue) {
          sources.push({
            platform: 'Unity',
            amount: unityData.revenue,
            currency: 'USD',
            period: 'monthly',
            lastUpdated: new Date(),
          });
        }
      } catch (error) {
        console.error('Failed to fetch Unity revenue:', error);
      }
    }

    // Get domain sales revenue
    const domainRevenue = await this.getDomainRevenue(userId);
    if (domainRevenue > 0) {
      sources.push({
        platform: 'Domain Sales',
        amount: domainRevenue,
        currency: 'USD',
        period: 'monthly',
        lastUpdated: new Date(),
      });
    }

    // Calculate totals and breakdown
    const total = sources.reduce((sum, source) => sum + source.amount, 0);
    
    const byPlatform: Record<string, number> = {};
    sources.forEach(source => {
      byPlatform[source.platform] = source.amount;
    });

    const byCategory = {
      'Game Development': (byPlatform['Roblox'] || 0) + (byPlatform['Unity'] || 0),
      'Domain Sales': byPlatform['Domain Sales'] || 0,
      'Consulting': 0, // Placeholder for future
      'Other': 0,
    };

    // Generate trend data (last 12 months)
    const trend = this.generateRevenueTrend(total, 12);

    // Calculate projections
    const projections = this.calculateProjections(total, trend);

    return {
      total,
      byPlatform,
      byCategory,
      trend,
      projections,
    };
  }

  /**
   * Get domain sales revenue
   */
  private async getDomainRevenue(userId: string): Promise<number> {
    try {
      const transactions = await db.domainTransaction.findMany({
        where: {
          userId,
          type: 'sale',
          createdAt: {
            gte: new Date(new Date().setDate(new Date().getDate() - 30)),
          },
        },
      });

      return transactions.reduce((sum, tx) => sum + tx.amount, 0);
    } catch (error) {
      console.error('Failed to fetch domain revenue:', error);
      return 0;
    }
  }

  /**
   * Generate revenue trend data
   */
  private generateRevenueTrend(currentMonthly: number, months: number): Array<{ date: string; amount: number }> {
    const trend = [];
    const baseRevenue = currentMonthly * 0.6; // Start at 60% of current
    const growth = (currentMonthly - baseRevenue) / months;

    for (let i = 0; i < months; i++) {
      const date = new Date();
      date.setMonth(date.getMonth() - (months - i - 1));
      
      const amount = Math.round(
        baseRevenue + (growth * i) + (Math.random() * currentMonthly * 0.1)
      );

      trend.push({
        date: date.toISOString().split('T')[0].substring(0, 7),
        amount,
      });
    }

    return trend;
  }

  /**
   * Calculate revenue projections
   */
  private calculateProjections(currentMonthly: number, trend: Array<{ date: string; amount: number }>): {
    nextMonth: number;
    nextQuarter: number;
    nextYear: number;
  } {
    // Calculate growth rate from trend
    const recentMonths = trend.slice(-3);
    const avgGrowth = recentMonths.length > 1
      ? (recentMonths[recentMonths.length - 1].amount - recentMonths[0].amount) / recentMonths[0].amount
      : 0.05; // Default 5% growth

    return {
      nextMonth: Math.round(currentMonthly * (1 + avgGrowth)),
      nextQuarter: Math.round(currentMonthly * 3 * (1 + avgGrowth * 1.5)),
      nextYear: Math.round(currentMonthly * 12 * (1 + avgGrowth * 2)),
    };
  }

  /**
   * Get revenue analytics for dashboard
   */
  async getRevenueAnalytics(userId: string): Promise<{
    current: RevenueBreakdown;
    topEarningProjects: Array<{ name: string; platform: string; revenue: number }>;
    revenuePerSkill: Array<{ skill: string; revenue: number }>;
  }> {
    const current = await this.getRevenueBreakdown(userId);

    // Mock top earning projects - would be real data in production
    const topEarningProjects = [
      { name: 'Super Racing Game', platform: 'Roblox', revenue: 1234 },
      { name: 'UI Framework Pro', platform: 'Unity', revenue: 876 },
      { name: 'premium.aethex', platform: 'Domain Sales', revenue: 543 },
    ];

    const revenuePerSkill = [
      { skill: 'Game Development', revenue: 2110 },
      { skill: 'Web3/Blockchain', revenue: 543 },
      { skill: '3D Modeling', revenue: 194 },
    ];

    return {
      current,
      topEarningProjects,
      revenuePerSkill,
    };
  }
}

export const revenue = new RevenueService();
