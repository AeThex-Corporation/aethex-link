/**
 * Client-side API utilities for making authenticated requests
 */

const API_BASE = '';

export class APIClient {
  private token: string | null = null;

  constructor() {
    // Load token from localStorage if available
    if (typeof window !== 'undefined') {
      this.token = localStorage.getItem('authToken');
    }
  }

  setToken(token: string) {
    this.token = token;
    if (typeof window !== 'undefined') {
      localStorage.setItem('authToken', token);
    }
  }

  clearToken() {
    this.token = null;
    if (typeof window !== 'undefined') {
      localStorage.removeItem('authToken');
    }
  }

  async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    if (options.headers) {
      Object.assign(headers, options.headers);
    }

    const response = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers,
      credentials: 'include', // Include cookies
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Request failed' }));
      throw new Error(error.error || `Request failed with status ${response.status}`);
    }

    return response.json();
  }

  // Auth endpoints
  async register(data: { email: string; password: string; name: string; username: string }) {
    const result = await this.request<{ user: any; token: string }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    this.setToken(result.token);
    return result;
  }

  async login(data: { email: string; password: string }) {
    const result = await this.request<{ user: any; token: string }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    this.setToken(result.token);
    return result;
  }

  async getMe() {
    return this.request<{ user: any }>('/api/auth/me');
  }

  async logout() {
    await this.request('/api/auth/logout', { method: 'POST' });
    this.clearToken();
  }

  // Profile endpoints
  async updateProfile(data: {
    name?: string;
    bio?: string;
    location?: string;
    title?: string;
    avatar?: string;
  }) {
    return this.request<{ success: boolean; user: any }>('/api/profile/update', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async syncProfile(data: { 
    githubUsername?: string; 
    stackOverflowId?: string;
    githubToken?: string;
    robloxUsername?: string;
    robloxApiKey?: string;
    unityPublisherId?: string;
    unityApiKey?: string;
    huggingFaceUsername?: string;
    huggingFaceToken?: string;
    kaggleUsername?: string;
    kaggleApiKey?: string;
    npmUsername?: string;
    pypiUsername?: string;
    gitlabUsername?: string;
    gitlabToken?: string;
    devtoUsername?: string;
    devtoApiKey?: string;
    mediumUsername?: string;
  }) {
    // Send game dev and AI platforms to separate endpoint
    const basePlatforms = {
      githubUsername: data.githubUsername,
      stackOverflowId: data.stackOverflowId,
      githubToken: data.githubToken,
    };

    const gamePlatforms = {
      robloxUsername: data.robloxUsername,
      robloxApiKey: data.robloxApiKey,
      unityPublisherId: data.unityPublisherId,
      unityApiKey: data.unityApiKey,
      huggingFaceUsername: data.huggingFaceUsername,
      huggingFaceToken: data.huggingFaceToken,
      kaggleUsername: data.kaggleUsername,
      kaggleApiKey: data.kaggleApiKey,
    };

    // Sync base platforms (GitHub/Stack Overflow)
    const baseResult = await this.request<{ success: boolean; profile: any }>('/api/profile/sync', {
      method: 'POST',
      body: JSON.stringify(basePlatforms),
    });

    // Sync game dev and AI platforms if provided
    if (Object.values(gamePlatforms).some(v => v)) {
      await this.request<{ success: boolean; profile: any }>('/api/platforms/sync', {
        method: 'POST',
        body: JSON.stringify(gamePlatforms),
      });
    }

    return baseResult;
  }

  async getProfile(userId: string) {
    return this.request<{ user: any; profile: any }>(`/api/profile/${userId}`);
  }

  // Analytics endpoints
  async getAnalytics() {
    return this.request<any>('/api/analytics/dashboard');
  }

  async exportAnalytics() {
    const response = await fetch('/api/analytics/export', {
      headers: this.token ? { Authorization: `Bearer ${this.token}` } : {},
    });
    
    if (!response.ok) {
      throw new Error('Export failed');
    }

    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `analytics-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  }

  // Connection endpoints
  async getConnections() {
    return this.request<{ connections: any[] }>('/api/connections');
  }

  async sendConnectionRequest(connectedUserId: string) {
    return this.request<{ success: boolean; connection: any }>('/api/connections', {
      method: 'POST',
      body: JSON.stringify({ connectedUserId, action: 'request' }),
    });
  }

  async acceptConnection(connectionId: string) {
    return this.request<{ success: boolean; connection: any }>('/api/connections', {
      method: 'POST',
      body: JSON.stringify({ connectedUserId: connectionId, action: 'accept' }),
    });
  }

  async rejectConnection(connectionId: string) {
    return this.request<{ success: boolean; connection: any }>('/api/connections', {
      method: 'POST',
      body: JSON.stringify({ connectedUserId: connectionId, action: 'reject' }),
    });
  }

  // Marketplace endpoints
  async getMarketplaceListings() {
    return this.request<{ listings: any[] }>('/api/marketplace');
  }

  async listDomain(domain: string, price: number, description?: string) {
    return this.request<{ success: boolean; listing: any }>('/api/marketplace', {
      method: 'POST',
      body: JSON.stringify({ action: 'create', domain, price, description }),
    });
  }

  async buyDomain(listingId: string) {
    return this.request<{ success: boolean }>('/api/marketplace', {
      method: 'POST',
      body: JSON.stringify({ action: 'buy', listingId }),
    });
  }

  // Team endpoints
  async getTeams() {
    return this.request<{ teams: any[] }>('/api/teams');
  }

  async createTeam(name: string, description: string) {
    return this.request<{ success: boolean; team: any }>('/api/teams', {
      method: 'POST',
      body: JSON.stringify({ action: 'create', name, description }),
    });
  }

  async inviteToTeam(teamId: string, userId: string, role?: string) {
    return this.request<{ success: boolean; member: any }>('/api/teams', {
      method: 'POST',
      body: JSON.stringify({ action: 'invite', teamId, userId, role }),
    });
  }

  async leaveTeam(teamId: string) {
    return this.request<{ success: boolean }>('/api/teams', {
      method: 'POST',
      body: JSON.stringify({ action: 'leave', teamId }),
    });
  }

  // API Key endpoints
  async getApiKeys() {
    return this.request<{ keys: any[] }>('/api/keys');
  }

  async createApiKey(name: string, permissions: string[], expiresInDays?: number) {
    return this.request<{ success: boolean; apiKey: any }>('/api/keys', {
      method: 'POST',
      body: JSON.stringify({ action: 'create', name, permissions, expiresInDays }),
    });
  }

  async deleteApiKey(keyId: string) {
    return this.request<{ success: boolean }>('/api/keys', {
      method: 'POST',
      body: JSON.stringify({ action: 'delete', keyId }),
    });
  }
}

// Export a singleton instance
export const api = new APIClient();
