import { db } from '~/lib/db.server';

interface SuggestedRoute {
  title: string;
  uri: string;
}

interface RouteDescription {
  suggestedRoutes: SuggestedRoute[];
  itemTitle: string;
}

export async function getRouteDescription(): Promise<RouteDescription> {
  // Get all users from the database
  const users = await db.user.findAll();
  
  // Create suggested routes for each user
  const suggestedRoutes: SuggestedRoute[] = users.map(user => ({
    title: `${user.name} (@${user.username})`,
    uri: `/subdomain/${user.username}`,
  }));

  // If no users exist yet, provide a placeholder
  if (suggestedRoutes.length === 0) {
    suggestedRoutes.push({
      title: 'No users yet',
      uri: '/subdomain/demo',
    });
  }

  return {
    suggestedRoutes,
    itemTitle: 'User Profile',
  };
}
