import { useState } from 'react';
import { RefreshCw, CheckCircle2, XCircle, Clock } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '~/components/ui/dialog/dialog';
import { Button } from '~/components/ui/button/button';
import { Progress } from '~/components/ui/progress/progress';
import { useProfileSync } from '~/hooks/use-profile-sync';
import styles from './profile-sync-dialog.module.css';

export function ProfileSyncDialog() {
  const [isOpen, setIsOpen] = useState(false);
  const { syncProfile, isSyncing, lastSynced, error } = useProfileSync();
  const [progress, setProgress] = useState(0);

  const handleSync = async () => {
    setProgress(0);
    const interval = setInterval(() => {
      setProgress((prev) => Math.min(prev + 10, 90));
    }, 300);

    try {
      await syncProfile();
      setProgress(100);
      setTimeout(() => {
        setIsOpen(false);
      }, 1500);
    } catch (err) {
      // Error is handled by the hook
    } finally {
      clearInterval(interval);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <RefreshCw className={styles.icon} />
          Sync Profile
        </Button>
      </DialogTrigger>
      <DialogContent className={styles.dialog}>
        <DialogHeader>
          <DialogTitle className={styles.title}>Sync Your Profile</DialogTitle>
          <DialogDescription className={styles.description}>
            Update your profile with the latest data from all connected platforms
          </DialogDescription>
        </DialogHeader>

        <div className={styles.content}>
          {!isSyncing && !error && progress === 0 && (
            <div className={styles.ready}>
              <RefreshCw className={styles.readyIcon} />
              <p className={styles.readyText}>
                Ready to sync data from GitHub, Stack Overflow, Kaggle, and all your connected platforms.
              </p>
              {lastSynced && (
                <div className={styles.lastSync}>
                  <Clock className={styles.clockIcon} />
                  <span>Last synced: {new Date(lastSynced).toLocaleString()}</span>
                </div>
              )}
            </div>
          )}

          {isSyncing && (
            <div className={styles.syncing}>
              <RefreshCw className={styles.syncingIcon} />
              <p className={styles.syncingText}>Syncing your profile...</p>
              <Progress value={progress} className={styles.progress} />
              <p className={styles.progressText}>{progress}% complete</p>
            </div>
          )}

          {error && (
            <div className={styles.error}>
              <XCircle className={styles.errorIcon} />
              <p className={styles.errorText}>{error}</p>
            </div>
          )}

          {!isSyncing && progress === 100 && (
            <div className={styles.success}>
              <CheckCircle2 className={styles.successIcon} />
              <p className={styles.successText}>Profile synced successfully!</p>
            </div>
          )}

          <div className={styles.platforms}>
            <p className={styles.platformsTitle}>Connected Platforms:</p>
            <div className={styles.platformGrid}>
              {['GitHub', 'Stack Overflow', 'Kaggle', 'npm', 'Unity', 'Roblox'].map((platform) => (
                <div key={platform} className={styles.platformChip}>
                  {platform}
                </div>
              ))}
            </div>
          </div>

          <div className={styles.actions}>
            {!isSyncing && progress !== 100 && (
              <Button onClick={handleSync} disabled={isSyncing} className={styles.syncButton}>
                <RefreshCw className={styles.buttonIcon} />
                Start Sync
              </Button>
            )}
            <Button variant="outline" onClick={() => setIsOpen(false)} className={styles.cancelButton}>
              Close
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
