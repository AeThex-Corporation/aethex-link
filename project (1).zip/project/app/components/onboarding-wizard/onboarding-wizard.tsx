import { useState } from 'react';
import { CheckCircle2, Circle, ArrowRight, ArrowLeft } from 'lucide-react';
import { Button } from '~/components/ui/button/button';
import { Card } from '~/components/ui/card/card';
import { Progress } from '~/components/ui/progress/progress';
import styles from './onboarding-wizard.module.css';
import { PlatformConnections } from '~/components/platform-connections/platform-connections';
import { ProfileEditor } from '~/components/profile-editor/profile-editor';

interface OnboardingStep {
  id: string;
  title: string;
  description: string;
  completed: boolean;
}

interface OnboardingWizardProps {
  onComplete: () => void;
  onSkip?: () => void;
}

export function OnboardingWizard({ onComplete, onSkip }: OnboardingWizardProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [steps, setSteps] = useState<OnboardingStep[]>([
    {
      id: 'welcome',
      title: 'Welcome to CreatorHub',
      description: 'Let\'s set up your verified creator profile in just a few steps',
      completed: false,
    },
    {
      id: 'connect-platforms',
      title: 'Connect Your Platforms',
      description: 'Link your accounts to start building your verified profile',
      completed: false,
    },
    {
      id: 'complete-profile',
      title: 'Complete Your Profile',
      description: 'Add some basic information about yourself',
      completed: false,
    },
    {
      id: 'done',
      title: 'All Set!',
      description: 'Your profile is ready to showcase your work',
      completed: false,
    },
  ]);

  const progress = ((currentStep + 1) / steps.length) * 100;

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      const newSteps = [...steps];
      newSteps[currentStep].completed = true;
      setSteps(newSteps);
      setCurrentStep(currentStep + 1);
    } else {
      onComplete();
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSkipToStep = (stepIndex: number) => {
    if (stepIndex <= currentStep) {
      setCurrentStep(stepIndex);
    }
  };

  const renderStepContent = () => {
    switch (steps[currentStep].id) {
      case 'welcome':
        return (
          <div className={styles.welcomeContent}>
            <div className={styles.welcomeIcon}>🚀</div>
            <h2 className={styles.welcomeTitle}>Welcome to CreatorHub!</h2>
            <p className={styles.welcomeText}>
              You're about to build a comprehensive, verified profile that showcases your work across all platforms.
            </p>
            <div className={styles.benefitsList}>
              <div className={styles.benefit}>
                <CheckCircle2 className={styles.benefitIcon} />
                <span>Aggregate work from 12+ platforms</span>
              </div>
              <div className={styles.benefit}>
                <CheckCircle2 className={styles.benefitIcon} />
                <span>Auto-sync your latest projects and stats</span>
              </div>
              <div className={styles.benefit}>
                <CheckCircle2 className={styles.benefitIcon} />
                <span>Get discovered by recruiters and collaborators</span>
              </div>
              <div className={styles.benefit}>
                <CheckCircle2 className={styles.benefitIcon} />
                <span>Claim your personalized domain</span>
              </div>
            </div>
          </div>
        );

      case 'connect-platforms':
        return (
          <div className={styles.platformsContent}>
            <h3 className={styles.stepContentTitle}>Connect Your Accounts</h3>
            <p className={styles.stepContentDescription}>
              Connect the platforms where you create. We'll automatically pull in your work to build your verified profile.
            </p>
            <PlatformConnections />
            <p className={styles.note}>
              💡 Tip: You can always add more platforms later from your dashboard
            </p>
          </div>
        );

      case 'complete-profile':
        return (
          <div className={styles.profileContent}>
            <h3 className={styles.stepContentTitle}>Tell Us About Yourself</h3>
            <p className={styles.stepContentDescription}>
              Add some basic information to help others learn about you
            </p>
            <ProfileEditor compact />
          </div>
        );

      case 'done':
        return (
          <div className={styles.doneContent}>
            <div className={styles.doneIcon}>🎉</div>
            <h2 className={styles.doneTitle}>You're All Set!</h2>
            <p className={styles.doneText}>
              Your CreatorHub profile is ready. We're syncing your data from connected platforms and will keep it up to date automatically.
            </p>
            <div className={styles.nextSteps}>
              <h4>What's Next?</h4>
              <ul>
                <li>Explore your dashboard to see your aggregated stats</li>
                <li>Customize your profile page and claim your domain</li>
                <li>Connect with other creators in your field</li>
                <li>Share your profile with recruiters and collaborators</li>
              </ul>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className={styles.overlay}>
      <Card className={styles.wizard}>
        {/* Progress Section */}
        <div className={styles.header}>
          <div className={styles.progressSection}>
            <Progress value={progress} className={styles.progressBar} />
            <p className={styles.progressText}>
              Step {currentStep + 1} of {steps.length}
            </p>
          </div>

          {/* Step Indicators */}
          <div className={styles.stepIndicators}>
            {steps.map((step, index) => (
              <button
                key={step.id}
                className={`${styles.stepIndicator} ${
                  index === currentStep ? styles.active : ''
                } ${step.completed ? styles.completed : ''}`}
                onClick={() => handleSkipToStep(index)}
                disabled={index > currentStep}
              >
                {step.completed ? (
                  <CheckCircle2 className={styles.stepIcon} />
                ) : (
                  <Circle className={styles.stepIcon} />
                )}
                <span className={styles.stepLabel}>{step.title}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className={styles.content}>{renderStepContent()}</div>

        {/* Actions */}
        <div className={styles.actions}>
          <div className={styles.leftActions}>
            {currentStep > 0 && (
              <Button variant="ghost" onClick={handleBack}>
                <ArrowLeft />
                Back
              </Button>
            )}
          </div>

          <div className={styles.rightActions}>
            {onSkip && currentStep < steps.length - 1 && (
              <Button variant="ghost" onClick={onSkip}>
                Skip for now
              </Button>
            )}
            <Button onClick={handleNext}>
              {currentStep === steps.length - 1 ? 'Go to Dashboard' : 'Continue'}
              {currentStep < steps.length - 1 && <ArrowRight />}
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
