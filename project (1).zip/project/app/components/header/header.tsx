import { Link } from 'react-router';
import { Button } from '../ui/button/button';
import { ColorSchemeToggle } from '../ui/color-scheme-toggle/color-scheme-toggle';
import { useAuth } from '~/hooks/use-auth';
import { SettingsDialog } from '../settings-dialog/settings-dialog';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar/avatar';
import { LogOut, Settings } from 'lucide-react';
import styles from './header.module.css';

interface HeaderProps {
  isAuthenticated?: boolean;
}

export function Header({ isAuthenticated: _isAuthenticated }: HeaderProps) {
  const { user, logout } = useAuth();
  const isAuthenticated = user !== null;

  return (
    <header className={styles.header}>
      <div className={styles.container}>
        <Link to="/" className={styles.logo}>
          CreatorHub
        </Link>

        <nav className={styles.nav}>
          {isAuthenticated ? (
            <>
              <Link to="/dashboard" className={styles.navLink}>
                Dashboard
              </Link>
              <Link to="/social" className={styles.navLink}>
                Social
              </Link>
              <Link to="/portfolio/showcase" className={styles.navLink}>
                Portfolio
              </Link>
              <Link to="/marketplace" className={styles.navLink}>
                Marketplace
              </Link>
              <Link to="/career-hub" className={styles.navLink}>
                Career
              </Link>
              <Link to="/premium" className={styles.navLink}>
                Upgrade
              </Link>
              <SettingsDialog 
                trigger={
                  <Button variant="outline" size="sm">
                    <Settings size={16} />
                  </Button>
                }
              />
              <div className={styles.userMenu}>
                <Avatar className={styles.avatar}>
                  <AvatarImage src={user?.avatar} alt={user?.name} />
                  <AvatarFallback>
                    {user?.name?.split(' ').map(n => n[0]).join('') || 'U'}
                  </AvatarFallback>
                </Avatar>
                <Button variant="outline" size="sm" onClick={logout}>
                  <LogOut size={16} />
                  Logout
                </Button>
              </div>
            </>
          ) : (
            <>
              <Link to="/auth" className={styles.navLink}>
                Sign In
              </Link>
            </>
          )}
          <ColorSchemeToggle />
        </nav>
      </div>
    </header>
  );
}
