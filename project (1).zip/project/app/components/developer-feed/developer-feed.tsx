import { useState } from 'react';
import { Heart, MessageCircle, Share2, Bookmark, MoreHorizontal } from 'lucide-react';
import { Card } from '~/components/ui/card/card';
import { Button } from '~/components/ui/button/button';
import { Avatar } from '~/components/ui/avatar/avatar';
import { Badge } from '~/components/ui/badge/badge';
import styles from './developer-feed.module.css';

interface FeedActivity {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  userTitle?: string;
  type: 'project' | 'achievement' | 'post' | 'milestone';
  content: string;
  timestamp: string;
  platform?: string;
  stats?: {
    likes: number;
    comments: number;
    shares: number;
  };
  metadata?: {
    projectName?: string;
    projectImage?: string;
    achievementType?: string;
    milestoneValue?: string;
  };
  isLiked?: boolean;
  isBookmarked?: boolean;
}

const mockActivities: FeedActivity[] = [
  {
    id: '1',
    userId: 'user1',
    userName: 'Alex Chen',
    userAvatar: 'https://i.pravatar.cc/150?img=1',
    userTitle: 'Game Developer',
    type: 'project',
    content: 'Just launched my new Roblox game "Space Adventure"! 🚀 Already hit 10K plays in the first day!',
    timestamp: '2 hours ago',
    platform: 'Roblox',
    stats: { likes: 42, comments: 8, shares: 5 },
    metadata: {
      projectName: 'Space Adventure',
      projectImage: 'https://images.unsplash.com/photo-1614732414444-096e5f1122d5?w=400&h=200&fit=crop',
    },
    isLiked: false,
    isBookmarked: false,
  },
  {
    id: '2',
    userId: 'user2',
    userName: 'Sarah Martinez',
    userAvatar: 'https://i.pravatar.cc/150?img=5',
    userTitle: 'AI Engineer',
    type: 'achievement',
    content: 'Excited to share that my ML model on Hugging Face just reached 100K downloads! 🎉',
    timestamp: '5 hours ago',
    platform: 'Hugging Face',
    stats: { likes: 128, comments: 23, shares: 15 },
    metadata: {
      achievementType: '100K Downloads',
    },
    isLiked: true,
    isBookmarked: false,
  },
  {
    id: '3',
    userId: 'user3',
    userName: 'Jordan Kim',
    userAvatar: 'https://i.pravatar.cc/150?img=12',
    userTitle: 'Full Stack Developer',
    type: 'milestone',
    content: 'Just hit 1000 GitHub stars on my open-source React component library! Thank you all! ⭐',
    timestamp: '1 day ago',
    platform: 'GitHub',
    stats: { likes: 89, comments: 12, shares: 8 },
    metadata: {
      milestoneValue: '1000 Stars',
    },
    isLiked: false,
    isBookmarked: true,
  },
];

export function DeveloperFeed() {
  const [activities, setActivities] = useState<FeedActivity[]>(mockActivities);

  const handleLike = (activityId: string) => {
    setActivities(prev =>
      prev.map(activity => {
        if (activity.id === activityId) {
          return {
            ...activity,
            isLiked: !activity.isLiked,
            stats: activity.stats
              ? {
                  ...activity.stats,
                  likes: activity.isLiked ? activity.stats.likes - 1 : activity.stats.likes + 1,
                }
              : undefined,
          };
        }
        return activity;
      })
    );
  };

  const handleBookmark = (activityId: string) => {
    setActivities(prev =>
      prev.map(activity => (activity.id === activityId ? { ...activity, isBookmarked: !activity.isBookmarked } : activity))
    );
  };

  const getActivityIcon = (type: FeedActivity['type']) => {
    switch (type) {
      case 'project':
        return '🚀';
      case 'achievement':
        return '🎉';
      case 'milestone':
        return '⭐';
      case 'post':
        return '💬';
      default:
        return '📌';
    }
  };

  return (
    <div className={styles.feed}>
      <div className={styles.header}>
        <h2 className={styles.title}>Developer Feed</h2>
        <p className={styles.description}>See what other creators are building and achieving</p>
      </div>

      <div className={styles.activities}>
        {activities.map(activity => (
          <Card key={activity.id} className={styles.activityCard}>
            {/* User Header */}
            <div className={styles.activityHeader}>
              <div className={styles.userInfo}>
                <Avatar src={activity.userAvatar} alt={activity.userName} fallback={activity.userName[0]} />
                <div className={styles.userDetails}>
                  <div className={styles.userName}>{activity.userName}</div>
                  <div className={styles.userMeta}>
                    {activity.userTitle && <span className={styles.userTitle}>{activity.userTitle}</span>}
                    <span className={styles.timestamp}>{activity.timestamp}</span>
                  </div>
                </div>
              </div>
              <Button variant="ghost" size="sm">
                <MoreHorizontal />
              </Button>
            </div>

            {/* Activity Type Badge */}
            <div className={styles.activityType}>
              <span className={styles.activityIcon}>{getActivityIcon(activity.type)}</span>
              {activity.platform && <Badge variant="secondary">{activity.platform}</Badge>}
            </div>

            {/* Content */}
            <div className={styles.activityContent}>
              <p>{activity.content}</p>
            </div>

            {/* Metadata (Project Image, Achievement, etc.) */}
            {activity.metadata?.projectImage && (
              <div className={styles.projectPreview}>
                <img src={activity.metadata.projectImage} alt={activity.metadata.projectName} />
                {activity.metadata.projectName && <div className={styles.projectName}>{activity.metadata.projectName}</div>}
              </div>
            )}

            {activity.metadata?.achievementType && (
              <div className={styles.achievementBadge}>
                <Badge variant="default" size="lg">
                  {activity.metadata.achievementType}
                </Badge>
              </div>
            )}

            {activity.metadata?.milestoneValue && (
              <div className={styles.milestone}>
                <div className={styles.milestoneValue}>{activity.metadata.milestoneValue}</div>
              </div>
            )}

            {/* Actions */}
            {activity.stats && (
              <div className={styles.activityActions}>
                <Button
                  variant="ghost"
                  size="sm"
                  className={`${styles.actionButton} ${activity.isLiked ? styles.liked : ''}`}
                  onClick={() => handleLike(activity.id)}
                >
                  <Heart className={activity.isLiked ? styles.likedIcon : ''} />
                  {activity.stats.likes}
                </Button>

                <Button variant="ghost" size="sm" className={styles.actionButton}>
                  <MessageCircle />
                  {activity.stats.comments}
                </Button>

                <Button variant="ghost" size="sm" className={styles.actionButton}>
                  <Share2 />
                  {activity.stats.shares}
                </Button>

                <Button
                  variant="ghost"
                  size="sm"
                  className={`${styles.actionButton} ${activity.isBookmarked ? styles.bookmarked : ''}`}
                  onClick={() => handleBookmark(activity.id)}
                >
                  <Bookmark className={activity.isBookmarked ? styles.bookmarkedIcon : ''} />
                </Button>
              </div>
            )}
          </Card>
        ))}
      </div>

      <div className={styles.loadMore}>
        <Button variant="outline">Load More Activities</Button>
      </div>
    </div>
  );
}
