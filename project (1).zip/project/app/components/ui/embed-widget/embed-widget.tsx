import { useState } from "react";
import { Copy, Check, Code } from "lucide-react";
import { Button } from "~/components/ui/button/button";
import { Card } from "~/components/ui/card/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "~/components/ui/tabs/tabs";
import styles from "./embed-widget.module.css";

interface EmbedWidgetProps {
  username: string;
  profileUrl: string;
}

export function EmbedWidget({ username, profileUrl }: EmbedWidgetProps) {
  const [copied, setCopied] = useState(false);

  const embedCode = `<iframe 
  src="${profileUrl}" 
  width="100%" 
  height="600" 
  frameborder="0" 
  style="border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);"
  title="${username}'s Developer Profile">
</iframe>`;

  const scriptCode = `<div id="devhub-profile-${username}"></div>
<script src="https://devhub.dev/embed.js" data-username="${username}"></script>`;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Card className={styles.widget}>
      <div className={styles.header}>
        <div className={styles.headerIcon}>
          <Code />
        </div>
        <div>
          <h3 className={styles.title}>Embed Your Profile</h3>
          <p className={styles.description}>Add your verified developer profile to any website</p>
        </div>
      </div>

      <Tabs defaultValue="iframe" className={styles.tabs}>
        <TabsList>
          <TabsTrigger value="iframe">iFrame</TabsTrigger>
          <TabsTrigger value="script">JavaScript</TabsTrigger>
        </TabsList>

        <TabsContent value="iframe" className={styles.tabContent}>
          <div className={styles.codeBlock}>
            <pre>
              <code>{embedCode}</code>
            </pre>
            <Button
              size="sm"
              variant="outline"
              className={styles.copyButton}
              onClick={() => handleCopy(embedCode)}
              aria-label="Copy iframe code"
            >
              {copied ? <Check className={styles.icon} /> : <Copy className={styles.icon} />}
              {copied ? "Copied!" : "Copy"}
            </Button>
          </div>
          <div className={styles.preview}>
            <h4>Preview</h4>
            <div className={styles.previewFrame}>
              <p>Your profile would appear here as an embedded widget</p>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="script" className={styles.tabContent}>
          <div className={styles.codeBlock}>
            <pre>
              <code>{scriptCode}</code>
            </pre>
            <Button
              size="sm"
              variant="outline"
              className={styles.copyButton}
              onClick={() => handleCopy(scriptCode)}
              aria-label="Copy script code"
            >
              {copied ? <Check className={styles.icon} /> : <Copy className={styles.icon} />}
              {copied ? "Copied!" : "Copy"}
            </Button>
          </div>
          <div className={styles.info}>
            <p>
              This method dynamically loads your profile and automatically updates when you make changes. Perfect for
              portfolios and personal websites.
            </p>
          </div>
        </TabsContent>
      </Tabs>
    </Card>
  );
}
