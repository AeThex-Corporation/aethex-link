import { Loader2 } from 'lucide-react';
import { SiGithub, SiGitlab, SiStackoverflow, SiDevdotto, SiMedium } from '@icons-pack/react-simple-icons';
import { Button } from '~/components/ui/button/button';
import { Card } from '~/components/ui/card/card';
import { useState } from 'react';
import styles from './oauth-connect.module.css';
import { useToast } from '~/hooks/use-toast';

interface OAuthProvider {
  id: string;
  name: string;
  icon: React.ReactNode;
  color: string;
  description: string;
  scopes?: string[];
  connected?: boolean;
  connectedUsername?: string;
}

const oauthProviders: OAuthProvider[] = [
  {
    id: 'github',
    name: 'GitHub',
    icon: <SiGithub size={24} />,
    color: '#181717',
    description: 'Connect your GitHub account to sync repositories, contributions, and stars',
    scopes: ['read:user', 'repo'],
    connected: false,
  },
  {
    id: 'gitlab',
    name: 'GitLab',
    icon: <SiGitlab size={24} />,
    color: '#FC6D26',
    description: 'Connect GitLab to import your projects and merge requests',
    scopes: ['read_user', 'read_repository'],
    connected: false,
  },
  {
    id: 'stackoverflow',
    name: 'Stack Overflow',
    icon: <SiStackoverflow size={24} />,
    color: '#F58025',
    description: 'Link your Stack Overflow profile to display reputation and answers',
    scopes: ['read_inbox'],
    connected: false,
  },
  {
    id: 'devto',
    name: 'Dev.to',
    icon: <SiDevdotto size={24} />,
    color: '#0A0A0A',
    description: 'Connect your Dev.to account to showcase your technical articles',
    scopes: [],
    connected: false,
  },
  {
    id: 'medium',
    name: 'Medium',
    icon: <SiMedium size={24} />,
    color: '#000000',
    description: 'Connect your Medium account to display your blog posts',
    scopes: [],
    connected: false,
  },
];

interface OAuthConnectProps {
  onConnect?: (providerId: string) => void;
  onDisconnect?: (providerId: string) => void;
}

export function OAuthConnect({ onConnect, onDisconnect }: OAuthConnectProps) {
  const [providers, setProviders] = useState(oauthProviders);
  const [connectingProvider, setConnectingProvider] = useState<string | null>(null);
  const { toast } = useToast();

  const handleConnect = async (providerId: string) => {
    setConnectingProvider(providerId);

    try {
      // In a real implementation, this would redirect to OAuth provider
      // For now, simulate the flow
      const authUrl = `/api/auth/oauth/${providerId}`;
      
      // Mock OAuth flow
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Update provider state
      setProviders(prev =>
        prev.map(p =>
          p.id === providerId
            ? { ...p, connected: true, connectedUsername: `user_${providerId}` }
            : p
        )
      );

      toast({
        title: 'Connected Successfully',
        description: `Your ${providers.find(p => p.id === providerId)?.name} account has been connected.`,
        variant: 'default',
      });

      onConnect?.(providerId);
    } catch (error) {
      toast({
        title: 'Connection Failed',
        description: 'Failed to connect your account. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setConnectingProvider(null);
    }
  };

  const handleDisconnect = async (providerId: string) => {
    try {
      // In a real implementation, this would revoke OAuth token
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setProviders(prev =>
        prev.map(p =>
          p.id === providerId
            ? { ...p, connected: false, connectedUsername: undefined }
            : p
        )
      );

      toast({
        title: 'Disconnected',
        description: `Your ${providers.find(p => p.id === providerId)?.name} account has been disconnected.`,
      });

      onDisconnect?.(providerId);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to disconnect account. Please try again.',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h2 className={styles.title}>OAuth Connections</h2>
        <p className={styles.description}>
          Connect your accounts for automatic profile syncing
        </p>
      </div>

      <div className={styles.providers}>
        {providers.map(provider => (
          <Card key={provider.id} className={styles.providerCard}>
            <div className={styles.providerHeader}>
              <div
                className={styles.providerIcon}
                style={{ backgroundColor: provider.color }}
              >
                {provider.icon}
              </div>
              <div className={styles.providerInfo}>
                <h3 className={styles.providerName}>{provider.name}</h3>
                <p className={styles.providerDescription}>{provider.description}</p>
                {provider.connected && provider.connectedUsername && (
                  <p className={styles.connectedAs}>
                    Connected as <strong>@{provider.connectedUsername}</strong>
                  </p>
                )}
              </div>
            </div>

            <div className={styles.providerActions}>
              {provider.connected ? (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleDisconnect(provider.id)}
                >
                  Disconnect
                </Button>
              ) : (
                <Button
                  variant="default"
                  size="sm"
                  onClick={() => handleConnect(provider.id)}
                  disabled={connectingProvider === provider.id}
                >
                  {connectingProvider === provider.id ? (
                    <>
                      <Loader2 className={styles.spinner} />
                      Connecting...
                    </>
                  ) : (
                    'Connect'
                  )}
                </Button>
              )}
            </div>
          </Card>
        ))}
      </div>

      <div className={styles.footer}>
        <p className={styles.footerNote}>
          🔒 We only request read-only access to your public data. Your credentials are never stored.
        </p>
      </div>
    </div>
  );
}
