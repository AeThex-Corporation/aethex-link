import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog/dialog';
import { Button } from '../ui/button/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs/tabs';
import { Settings, User, Link as LinkIcon } from 'lucide-react';
import { ProfileSyncDialog } from '../profile-sync-dialog/profile-sync-dialog';
import styles from './settings-dialog.module.css';

interface SettingsDialogProps {
  trigger?: React.ReactNode;
}

export function SettingsDialog({ trigger }: SettingsDialogProps) {
  const [open, setOpen] = useState(false);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline">
            <Settings size={16} />
            Settings
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className={styles.dialog}>
        <DialogHeader>
          <DialogTitle>Settings</DialogTitle>
          <DialogDescription>
            Manage your profile connections and settings
          </DialogDescription>
        </DialogHeader>
        
        <Tabs defaultValue="connections" className={styles.tabs}>
          <TabsList>
            <TabsTrigger value="connections">
              <LinkIcon size={16} />
              Connections
            </TabsTrigger>
            <TabsTrigger value="profile">
              <User size={16} />
              Profile
            </TabsTrigger>
          </TabsList>

          <TabsContent value="connections" className={styles.tabContent}>
            <div className={styles.section}>
              <h3>Connected Accounts</h3>
              <p className={styles.description}>
                Sync your developer accounts to automatically aggregate your contributions.
              </p>
              <ProfileSyncDialog 
                trigger={<Button>Sync Accounts</Button>}
                onSuccess={() => setOpen(false)}
              />
            </div>
          </TabsContent>

          <TabsContent value="profile" className={styles.tabContent}>
            <div className={styles.section}>
              <h3>Profile Settings</h3>
              <p className={styles.description}>
                Update your profile information and preferences.
              </p>
              <Button variant="outline">Edit Profile</Button>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
