import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '~/components/ui/card/card';
import { Button } from '~/components/ui/button/button';
import { Badge } from '~/components/ui/badge/badge';
import { Progress } from '~/components/ui/progress/progress';
import { Separator } from '~/components/ui/separator/separator';
import {
  Globe,
  Shield,
  Calendar,
  Wallet,
  ExternalLink,
  RefreshCw,
  AlertCircle,
  CheckCircle2,
  Clock,
} from 'lucide-react';
import styles from './domain-manager.module.css';

interface DomainRecord {
  domain: string;
  walletAddress?: string;
  registrationDate: string;
  expiryDate: string;
  status: 'pending' | 'active' | 'expired' | 'suspended';
  transactionHash?: string;
  blockchain?: string;
  autoRenew: boolean;
}

interface Transaction {
  type: 'registration' | 'renewal' | 'transfer';
  amount: number;
  currency: string;
  status: 'pending' | 'completed' | 'failed';
  transactionHash?: string;
  createdAt: string;
}

interface DomainManagerProps {
  domainTier: 'free' | 'premium';
  username: string;
}

export function DomainManager({ domainTier, username }: DomainManagerProps) {
  const [domain, setDomain] = useState<DomainRecord | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isVerifying, setIsVerifying] = useState(false);
  const [isRenewing, setIsRenewing] = useState(false);
  const [showUpgrade, setShowUpgrade] = useState(false);

  useEffect(() => {
    loadDomainInfo();
  }, []);

  const loadDomainInfo = async () => {
    setIsLoading(true);
    try {
      const token = localStorage.getItem('auth_token');
      const response = await fetch('/api/domain/info', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (response.ok) {
        const data = await response.json();
        setDomain(data.domain);
        setTransactions(data.transactions || []);
      }
    } catch (error) {
      console.error('Failed to load domain info:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerify = async () => {
    setIsVerifying(true);
    try {
      const token = localStorage.getItem('auth_token');
      const response = await fetch('/api/domain/verify', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      if (response.ok) {
        await loadDomainInfo();
      }
    } catch (error) {
      console.error('Verification failed:', error);
    } finally {
      setIsVerifying(false);
    }
  };

  const handleRenew = async () => {
    setIsRenewing(true);
    try {
      const token = localStorage.getItem('auth_token');
      const response = await fetch('/api/domain/renew', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ years: 1 }),
      });

      if (response.ok) {
        await loadDomainInfo();
      }
    } catch (error) {
      console.error('Renewal failed:', error);
    } finally {
      setIsRenewing(false);
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className={styles.loading}>
          <RefreshCw className={styles.spinner} size={24} />
          <p>Loading domain information...</p>
        </CardContent>
      </Card>
    );
  }

  // Show upgrade option for free tier users
  if (!domain && domainTier === 'free') {
    return (
      <Card>
        <CardHeader>
          <CardTitle className={styles.title}>
            <Globe size={20} />
            Your Domain
          </CardTitle>
          <CardDescription>
            You're on the free tier with {username}.aethex.me
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className={styles.freeTier}>
            <div className={styles.freeTierInfo}>
              <h4>Current Domain</h4>
              <p className={styles.freeDomain}>{username}.aethex.me</p>
              <p className={styles.freeTierDesc}>
                Your portfolio is accessible at this subdomain. Upgrade to a premium .aethex domain
                for blockchain verification and NFT ownership.
              </p>
            </div>
            <Button onClick={() => setShowUpgrade(true)} variant="default">
              <Shield size={16} />
              Upgrade to Premium
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!domain) {
    return null;
  }

  const daysUntilExpiry = Math.floor(
    (new Date(domain.expiryDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24)
  );
  const expiryProgress = Math.max(0, Math.min(100, (daysUntilExpiry / 365) * 100));

  return (
    <div className={styles.container}>
      <Card>
        <CardHeader>
          <CardTitle className={styles.title}>
            <Globe size={20} />
            Your .aethex Domain
          </CardTitle>
          <CardDescription>Manage your blockchain-verified Web3 identity</CardDescription>
        </CardHeader>
        <CardContent className={styles.content}>
          {/* Domain Info */}
          <div className={styles.domainSection}>
            <div className={styles.domainHeader}>
              <div className={styles.domainName}>
                <Globe size={24} className={styles.domainIcon} />
                <span>{domain.domain}</span>
              </div>
              <Badge
                variant={
                  domain.status === 'active'
                    ? 'default'
                    : domain.status === 'pending'
                    ? 'secondary'
                    : 'destructive'
                }
              >
                {domain.status === 'active' && <CheckCircle2 size={12} />}
                {domain.status === 'pending' && <Clock size={12} />}
                {domain.status === 'expired' && <AlertCircle size={12} />}
                {domain.status}
              </Badge>
            </div>

            <div className={styles.domainDetails}>
              <div className={styles.detailRow}>
                <span className={styles.detailLabel}>
                  <Calendar size={16} />
                  Registered
                </span>
                <span className={styles.detailValue}>
                  {new Date(domain.registrationDate).toLocaleDateString()}
                </span>
              </div>

              <div className={styles.detailRow}>
                <span className={styles.detailLabel}>
                  <Calendar size={16} />
                  Expires
                </span>
                <span className={styles.detailValue}>
                  {new Date(domain.expiryDate).toLocaleDateString()}
                  <Badge variant={daysUntilExpiry < 30 ? 'destructive' : 'outline'} className={styles.daysLeft}>
                    {daysUntilExpiry} days left
                  </Badge>
                </span>
              </div>

              {domain.walletAddress && (
                <div className={styles.detailRow}>
                  <span className={styles.detailLabel}>
                    <Wallet size={16} />
                    Wallet
                  </span>
                  <span className={styles.detailValue}>
                    {domain.walletAddress.slice(0, 6)}...{domain.walletAddress.slice(-4)}
                  </span>
                </div>
              )}

              {domain.blockchain && (
                <div className={styles.detailRow}>
                  <span className={styles.detailLabel}>
                    <Shield size={16} />
                    Blockchain
                  </span>
                  <span className={styles.detailValue}>{domain.blockchain}</span>
                </div>
              )}
            </div>

            {/* Expiry Progress */}
            <div className={styles.expirySection}>
              <div className={styles.expiryHeader}>
                <span className={styles.expiryLabel}>Time Until Expiry</span>
                <span className={styles.expiryValue}>{daysUntilExpiry} days</span>
              </div>
              <Progress
                value={expiryProgress}
                className={`${styles.expiryProgress} ${daysUntilExpiry < 30 ? styles.expiryWarning : ''}`}
              />
            </div>

            {/* Actions */}
            <div className={styles.actions}>
              {domain.status === 'pending' && (
                <Button onClick={handleVerify} disabled={isVerifying} variant="default">
                  {isVerifying ? <RefreshCw className={styles.spinner} size={16} /> : <Shield size={16} />}
                  Verify Ownership
                </Button>
              )}

              <Button onClick={handleRenew} disabled={isRenewing} variant="outline">
                {isRenewing ? <RefreshCw className={styles.spinner} size={16} /> : <RefreshCw size={16} />}
                Renew Domain
              </Button>

              <Button variant="outline" asChild>
                <a href={`https://${domain.domain}`} target="_blank" rel="noopener noreferrer">
                  <ExternalLink size={16} />
                  View Portfolio
                </a>
              </Button>
            </div>

            {domain.transactionHash && (
              <div className={styles.blockchain}>
                <Shield size={14} />
                <span>Verified on blockchain</span>
                <a
                  href={`https://polygonscan.com/tx/${domain.transactionHash}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={styles.txLink}
                >
                  View Transaction
                  <ExternalLink size={12} />
                </a>
              </div>
            )}
          </div>

          {/* Transaction History */}
          {transactions.length > 0 && (
            <>
              <Separator />
              <div className={styles.transactionsSection}>
                <h4 className={styles.transactionsTitle}>Transaction History</h4>
                <div className={styles.transactionsList}>
                  {transactions.map((tx, index) => (
                    <div key={index} className={styles.transaction}>
                      <div className={styles.transactionInfo}>
                        <span className={styles.transactionType}>{tx.type}</span>
                        <span className={styles.transactionDate}>
                          {new Date(tx.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      <div className={styles.transactionDetails}>
                        <span className={styles.transactionAmount}>
                          {tx.currency === 'USD' ? '$' : ''}
                          {tx.amount}
                          {tx.currency !== 'USD' ? ` ${tx.currency}` : ''}
                        </span>
                        <Badge
                          variant={
                            tx.status === 'completed'
                              ? 'default'
                              : tx.status === 'pending'
                              ? 'secondary'
                              : 'destructive'
                          }
                        >
                          {tx.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
