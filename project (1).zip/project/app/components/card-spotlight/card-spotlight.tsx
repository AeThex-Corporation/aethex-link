import { type ReactNode, type MouseEvent, useState, useRef } from 'react';
import styles from './card-spotlight.module.css';

interface CardSpotlightProps {
  children: ReactNode;
  className?: string;
}

export function CardSpotlight({ children, className = '' }: CardSpotlightProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [spotlightPosition, setSpotlightPosition] = useState({ x: 0, y: 0 });
  const [isHovering, setIsHovering] = useState(false);

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;

    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setSpotlightPosition({ x, y });
  };

  return (
    <div
      ref={cardRef}
      className={`${styles.card} ${className}`}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
    >
      {isHovering && (
        <div
          className={styles.spotlight}
          style={{
            left: `${spotlightPosition.x}px`,
            top: `${spotlightPosition.y}px`,
          }}
        />
      )}
      <div className={styles.content}>{children}</div>
    </div>
  );
}
