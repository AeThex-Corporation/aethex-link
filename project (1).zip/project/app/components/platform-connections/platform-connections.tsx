import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '~/components/ui/card/card';
import { Button } from '~/components/ui/button/button';
import { Input } from '~/components/ui/input/input';
import { Label } from '~/components/ui/label/label';
import { Badge } from '~/components/ui/badge/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '~/components/ui/tabs/tabs';
import { Gamepad2, Brain, Code2, Check, Plus, RefreshCw } from 'lucide-react';
import { 
  SiRoblox, 
  SiUnity, 
  SiSteam, 
  SiItchdotio, 
  SiHuggingface, 
  SiKaggle, 
  SiGithub, 
  SiStackoverflow,
  SiNpm,
  SiPypi,
  SiGitlab,
  SiDevdotto,
  SiMedium
} from '@icons-pack/react-simple-icons';
import styles from './platform-connections.module.css';

interface Platform {
  id: string;
  name: string;
  category: 'game' | 'ai' | 'software';
  connected: boolean;
  username?: string;
  icon: React.ComponentType<{ size?: number | string; className?: string }>;
  stats?: {
    label: string;
    value: string | number;
  }[];
  fields: Array<{
    name: string;
    label: string;
    type: 'text' | 'password';
    placeholder: string;
    required: boolean;
  }>;
}

interface PlatformConnectionsProps {
  onConnect: (platformId: string, credentials: Record<string, string>) => Promise<void>;
  onDisconnect: (platformId: string) => Promise<void>;
  onSync: (platformId: string) => Promise<void>;
  className?: string;
}

const platforms: Platform[] = [
  // Game Dev Platforms
  {
    id: 'roblox',
    name: 'Roblox',
    category: 'game',
    icon: SiRoblox,
    connected: false,
    fields: [
      { name: 'robloxUsername', label: 'Username', type: 'text', placeholder: 'YourRobloxUsername', required: true },
      { name: 'robloxApiKey', label: 'API Key', type: 'password', placeholder: 'Your Roblox API Key', required: false },
    ],
  },
  {
    id: 'unity',
    name: 'Unity Asset Store',
    category: 'game',
    icon: SiUnity,
    connected: false,
    fields: [
      { name: 'unityPublisherId', label: 'Publisher ID', type: 'text', placeholder: 'Your Publisher ID', required: true },
      { name: 'unityApiKey', label: 'API Key', type: 'password', placeholder: 'Your Unity API Key', required: false },
    ],
  },
  {
    id: 'steam',
    name: 'Steam',
    category: 'game',
    icon: SiSteam,
    connected: false,
    fields: [
      { name: 'steamDeveloperId', label: 'Developer ID', type: 'text', placeholder: 'Your Steam Developer ID', required: true },
    ],
  },
  {
    id: 'itchio',
    name: 'Itch.io',
    category: 'game',
    icon: SiItchdotio,
    connected: false,
    fields: [
      { name: 'itchioUsername', label: 'Username', type: 'text', placeholder: 'YourItchioUsername', required: true },
    ],
  },
  // AI Platforms
  {
    id: 'huggingface',
    name: 'Hugging Face',
    category: 'ai',
    icon: SiHuggingface,
    connected: false,
    fields: [
      { name: 'huggingFaceUsername', label: 'Username', type: 'text', placeholder: 'YourHuggingFaceUsername', required: true },
      { name: 'huggingFaceToken', label: 'Access Token', type: 'password', placeholder: 'hf_...', required: false },
    ],
  },
  {
    id: 'kaggle',
    name: 'Kaggle',
    category: 'ai',
    icon: SiKaggle,
    connected: false,
    fields: [
      { name: 'kaggleUsername', label: 'Username', type: 'text', placeholder: 'YourKaggleUsername', required: true },
      { name: 'kaggleApiKey', label: 'API Key', type: 'password', placeholder: 'Your Kaggle API Key', required: false },
    ],
  },
  // Software Dev Platforms
  {
    id: 'github',
    name: 'GitHub',
    category: 'software',
    icon: SiGithub,
    connected: false,
    fields: [
      { name: 'githubUsername', label: 'Username', type: 'text', placeholder: 'YourGitHubUsername', required: true },
      { name: 'githubToken', label: 'Personal Access Token', type: 'password', placeholder: 'ghp_...', required: false },
    ],
  },
  {
    id: 'stackoverflow',
    name: 'Stack Overflow',
    category: 'software',
    icon: SiStackoverflow,
    connected: false,
    fields: [
      { name: 'stackOverflowId', label: 'User ID', type: 'text', placeholder: 'Your Stack Overflow User ID', required: true },
    ],
  },
  {
    id: 'npm',
    name: 'npm',
    category: 'software',
    icon: SiNpm,
    connected: false,
    fields: [
      { name: 'npmUsername', label: 'Username', type: 'text', placeholder: 'YourNpmUsername', required: true },
    ],
  },
  {
    id: 'pypi',
    name: 'PyPI',
    category: 'software',
    icon: SiPypi,
    connected: false,
    fields: [
      { name: 'pypiUsername', label: 'Username', type: 'text', placeholder: 'YourPyPIUsername', required: true },
    ],
  },
  {
    id: 'gitlab',
    name: 'GitLab',
    category: 'software',
    icon: SiGitlab,
    connected: false,
    fields: [
      { name: 'gitlabUsername', label: 'Username', type: 'text', placeholder: 'YourGitLabUsername', required: true },
      { name: 'gitlabToken', label: 'Access Token', type: 'password', placeholder: 'glpat-...', required: false },
    ],
  },
  {
    id: 'devto',
    name: 'Dev.to',
    category: 'software',
    icon: SiDevdotto,
    connected: false,
    fields: [
      { name: 'devtoUsername', label: 'Username', type: 'text', placeholder: 'YourDevtoUsername', required: true },
      { name: 'devtoApiKey', label: 'API Key', type: 'password', placeholder: 'Optional API Key', required: false },
    ],
  },
  {
    id: 'medium',
    name: 'Medium',
    category: 'software',
    icon: SiMedium,
    connected: false,
    fields: [
      { name: 'mediumUsername', label: 'Username', type: 'text', placeholder: '@YourMediumUsername', required: true },
    ],
  },
];

const categoryIcons = {
  game: Gamepad2,
  ai: Brain,
  software: Code2,
};

export function PlatformConnections({ onConnect, onDisconnect, onSync, className }: PlatformConnectionsProps) {
  const [activeTab, setActiveTab] = useState<'game' | 'ai' | 'software'>('game');
  const [connectingPlatform, setConnectingPlatform] = useState<string | null>(null);
  const [formData, setFormData] = useState<Record<string, Record<string, string>>>({});
  const [syncing, setSyncing] = useState<string | null>(null);

  const handleSubmit = async (platformId: string) => {
    setConnectingPlatform(platformId);
    try {
      await onConnect(platformId, formData[platformId] || {});
      setFormData(prev => ({ ...prev, [platformId]: {} }));
    } finally {
      setConnectingPlatform(null);
    }
  };

  const handleSync = async (platformId: string) => {
    setSyncing(platformId);
    try {
      await onSync(platformId);
    } finally {
      setSyncing(null);
    }
  };

  const updateFormData = (platformId: string, field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [platformId]: {
        ...(prev[platformId] || {}),
        [field]: value,
      },
    }));
  };

  const renderPlatformCard = (platform: Platform) => {
    const PlatformIcon = platform.icon;
    const CategoryIcon = categoryIcons[platform.category];

    return (
      <Card key={platform.id} className={styles.platformCard}>
        <CardHeader>
          <div className={styles.platformHeader}>
            <div className={styles.platformTitle}>
              <PlatformIcon size={24} />
              <CardTitle>{platform.name}</CardTitle>
            </div>
            {platform.connected && (
              <Badge variant="default">
                <Check size={14} />
                Connected
              </Badge>
            )}
          </div>
          {platform.connected && platform.username && (
            <CardDescription>@{platform.username}</CardDescription>
          )}
        </CardHeader>

        <CardContent>
          {platform.connected ? (
            <div className={styles.connectedContent}>
              {platform.stats && (
                <div className={styles.stats}>
                  {platform.stats.map((stat, index) => (
                    <div key={index} className={styles.stat}>
                      <span className={styles.statLabel}>{stat.label}</span>
                      <span className={styles.statValue}>{stat.value}</span>
                    </div>
                  ))}
                </div>
              )}
              
              <div className={styles.actions}>
                <Button
                  variant="outline"
                  onClick={() => handleSync(platform.id)}
                  disabled={syncing === platform.id}
                >
                  <RefreshCw size={16} className={syncing === platform.id ? styles.spinning : ''} />
                  {syncing === platform.id ? 'Syncing...' : 'Sync Now'}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => onDisconnect(platform.id)}
                >
                  Disconnect
                </Button>
              </div>
            </div>
          ) : (
            <div className={styles.connectForm}>
              {platform.fields.map((field) => (
                <div key={field.name} className={styles.field}>
                  <Label htmlFor={`${platform.id}-${field.name}`}>
                    {field.label}
                    {field.required && <span className={styles.required}>*</span>}
                  </Label>
                  <Input
                    id={`${platform.id}-${field.name}`}
                    type={field.type}
                    placeholder={field.placeholder}
                    value={formData[platform.id]?.[field.name] || ''}
                    onChange={(e) => updateFormData(platform.id, field.name, e.target.value)}
                  />
                </div>
              ))}

              <Button
                onClick={() => handleSubmit(platform.id)}
                disabled={connectingPlatform === platform.id}
                className={styles.connectButton}
              >
                <Plus size={16} />
                {connectingPlatform === platform.id ? 'Connecting...' : 'Connect'}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    );
  };

  const filteredPlatforms = platforms.filter(p => p.category === activeTab);

  return (
    <div className={`${styles.container} ${className || ''}`}>
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)}>
        <TabsList className={styles.tabsList}>
          <TabsTrigger value="game">
            <Gamepad2 size={16} />
            Game Dev
          </TabsTrigger>
          <TabsTrigger value="ai">
            <Brain size={16} />
            AI & ML
          </TabsTrigger>
          <TabsTrigger value="software">
            <Code2 size={16} />
            Software Dev
          </TabsTrigger>
        </TabsList>

        <TabsContent value="game" className={styles.tabContent}>
          <div className={styles.platformGrid}>
            {filteredPlatforms.map(renderPlatformCard)}
          </div>
        </TabsContent>

        <TabsContent value="ai" className={styles.tabContent}>
          <div className={styles.platformGrid}>
            {filteredPlatforms.map(renderPlatformCard)}
          </div>
        </TabsContent>

        <TabsContent value="software" className={styles.tabContent}>
          <div className={styles.platformGrid}>
            {filteredPlatforms.map(renderPlatformCard)}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
