import { useState, useRef } from 'react';
import { Button } from '~/components/ui/button/button';
import { Input } from '~/components/ui/input/input';
import { Label } from '~/components/ui/label/label';
import { Textarea } from '~/components/ui/textarea/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from '~/components/ui/dialog/dialog';
import { Avatar, AvatarImage, AvatarFallback } from '~/components/ui/avatar/avatar';
import { useToast } from '~/hooks/use-toast';
import { api } from '~/lib/api.client';
import { Pencil, Upload, X } from 'lucide-react';
import styles from './profile-editor.module.css';

interface ProfileEditorProps {
  user: {
    name: string;
    bio?: string;
    location?: string;
    title?: string;
    avatar?: string;
  };
  onUpdate: () => void;
}

export function ProfileEditor({ user, onUpdate }: ProfileEditorProps) {
  const [open, setOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: user.name || '',
    bio: user.bio || '',
    location: user.location || '',
    title: user.title || '',
    avatar: user.avatar || '',
  });
  const [previewUrl, setPreviewUrl] = useState<string>(user.avatar || '');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      if (!file.type.startsWith('image/')) {
        toast({
          title: 'Invalid file type',
          description: 'Please select an image file',
          variant: 'destructive',
        });
        return;
      }

      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: 'File too large',
          description: 'Please select an image smaller than 5MB',
          variant: 'destructive',
        });
        return;
      }

      // Create preview URL
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setPreviewUrl(base64String);
        setFormData({ ...formData, avatar: base64String });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveAvatar = () => {
    setPreviewUrl('');
    setFormData({ ...formData, avatar: '' });
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const response = await api.updateProfile(formData);

      if (response.success) {
        toast({
          title: 'Profile updated',
          description: 'Your profile has been updated successfully.',
        });
        setOpen(false);
        onUpdate();
      }
    } catch (error: any) {
      toast({
        title: 'Update failed',
        description: error.message || 'Failed to update profile',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className={styles.trigger}>
          <Pencil size={18} />
          Edit Profile
        </Button>
      </DialogTrigger>
      <DialogContent className={styles.content}>
        <DialogHeader>
          <DialogTitle>Edit Profile</DialogTitle>
          <DialogDescription>
            Make changes to your profile here. Click save when you're done.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className={styles.form}>
          <div className={styles.formField}>
            <Label htmlFor="name">Name</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Your name"
              required
            />
          </div>

          <div className={styles.formField}>
            <Label htmlFor="title">Title</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="e.g., Full-Stack Developer"
            />
          </div>

          <div className={styles.formField}>
            <Label htmlFor="location">Location</Label>
            <Input
              id="location"
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              placeholder="e.g., San Francisco, CA"
            />
          </div>

          <div className={styles.formField}>
            <Label>Profile Picture</Label>
            <div className={styles.avatarUpload}>
              <div className={styles.avatarPreview}>
                <Avatar className={styles.avatar}>
                  <AvatarImage src={previewUrl} alt={formData.name} />
                  <AvatarFallback>{formData.name.charAt(0).toUpperCase()}</AvatarFallback>
                </Avatar>
                {previewUrl && (
                  <button
                    type="button"
                    onClick={handleRemoveAvatar}
                    className={styles.removeButton}
                    aria-label="Remove avatar"
                  >
                    <X size={16} />
                  </button>
                )}
              </div>
              <div className={styles.uploadControls}>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileChange}
                  className={styles.fileInput}
                  id="avatar-upload"
                />
                <Label htmlFor="avatar-upload" className={styles.uploadButton}>
                  <Upload size={16} />
                  Choose Image
                </Label>
                <p className={styles.uploadHint}>Max size: 5MB. JPG, PNG, GIF supported.</p>
              </div>
            </div>
          </div>

          <div className={styles.formField}>
            <Label htmlFor="bio">Bio</Label>
            <Textarea
              id="bio"
              value={formData.bio}
              onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
              placeholder="Tell us about yourself..."
              rows={4}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? 'Saving...' : 'Save Changes'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
