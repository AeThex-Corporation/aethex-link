import { Check, Zap, Crown, Sparkles } from 'lucide-react';
import { Button } from '~/components/ui/button/button';
import { Card } from '~/components/ui/card/card';
import { Badge } from '~/components/ui/badge/badge';
import { Switch } from '~/components/ui/switch/switch';
import { useState } from 'react';
import styles from './premium-upgrade.module.css';

interface PricingTier {
  id: string;
  name: string;
  price: number;
  priceYearly: number;
  description: string;
  features: string[];
  recommended?: boolean;
  icon: React.ReactNode;
  cta: string;
}

const tiers: PricingTier[] = [
  {
    id: 'free',
    name: 'Free',
    price: 0,
    priceYearly: 0,
    description: 'Perfect for getting started',
    icon: <Sparkles />,
    cta: 'Current Plan',
    features: [
      'Connect up to 3 platforms',
      'Basic profile customization',
      'Public profile page',
      'Basic analytics',
      'Community access',
    ],
  },
  {
    id: 'pro',
    name: 'Pro',
    price: 9,
    priceYearly: 89,
    description: 'For serious creators',
    icon: <Zap />,
    recommended: true,
    cta: 'Upgrade to Pro',
    features: [
      'Connect unlimited platforms',
      'Advanced profile customization',
      'Premium .aethex domain',
      'Advanced analytics & insights',
      'AI-powered recommendations',
      'Priority support',
      'Remove CreatorHub branding',
      'Export data & reports',
      'Early access to new features',
    ],
  },
  {
    id: 'business',
    name: 'Business',
    price: 29,
    priceYearly: 279,
    description: 'For teams and recruiters',
    icon: <Crown />,
    cta: 'Upgrade to Business',
    features: [
      'Everything in Pro',
      'Team collaboration (up to 10 members)',
      'Advanced recruiter tools',
      'API access',
      'White-label options',
      'Custom integrations',
      'Dedicated account manager',
      'SLA & premium support',
      'Advanced security features',
    ],
  },
];

interface PremiumUpgradeProps {
  onUpgrade?: (tierId: string) => void;
  currentTier?: string;
}

export function PremiumUpgrade({ onUpgrade, currentTier = 'free' }: PremiumUpgradeProps) {
  const [isYearly, setIsYearly] = useState(true);

  const handleUpgrade = (tierId: string) => {
    if (onUpgrade) {
      onUpgrade(tierId);
    } else {
      // Default: Navigate to checkout or show payment modal
      console.log(`Upgrading to ${tierId}`, { isYearly });
    }
  };

  const calculateSavings = (tier: PricingTier) => {
    if (tier.price === 0) return 0;
    const monthlyTotal = tier.price * 12;
    return monthlyTotal - tier.priceYearly;
  };

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h1 className={styles.title}>Choose Your Plan</h1>
        <p className={styles.description}>Unlock more features and grow your creator profile</p>

        {/* Billing Toggle */}
        <div className={styles.billingToggle}>
          <span className={`${styles.billingOption} ${!isYearly ? styles.active : ''}`}>Monthly</span>
          <Switch checked={isYearly} onCheckedChange={setIsYearly} />
          <span className={`${styles.billingOption} ${isYearly ? styles.active : ''}`}>
            Yearly
            <Badge variant="success" className={styles.savingsBadge}>
              Save up to 17%
            </Badge>
          </span>
        </div>
      </div>

      <div className={styles.tiers}>
        {tiers.map(tier => {
          const isCurrentTier = tier.id === currentTier;
          const price = isYearly ? tier.priceYearly : tier.price;
          const savings = isYearly ? calculateSavings(tier) : 0;

          return (
            <Card
              key={tier.id}
              className={`${styles.tierCard} ${tier.recommended ? styles.recommended : ''} ${
                isCurrentTier ? styles.current : ''
              }`}
            >
              {tier.recommended && (
                <div className={styles.recommendedBadge}>
                  <Badge variant="default">Most Popular</Badge>
                </div>
              )}

              <div className={styles.tierHeader}>
                <div className={styles.tierIcon}>{tier.icon}</div>
                <h3 className={styles.tierName}>{tier.name}</h3>
                <p className={styles.tierDescription}>{tier.description}</p>
              </div>

              <div className={styles.tierPrice}>
                <div className={styles.priceAmount}>
                  <span className={styles.currency}>$</span>
                  <span className={styles.amount}>{isYearly ? Math.round(tier.priceYearly / 12) : price}</span>
                  <span className={styles.period}>/{isYearly ? 'mo' : 'month'}</span>
                </div>
                {isYearly && tier.price > 0 && (
                  <div className={styles.yearlyPrice}>
                    Billed ${tier.priceYearly}/year
                    {savings > 0 && <span className={styles.savings}>(Save ${savings})</span>}
                  </div>
                )}
              </div>

              <Button
                className={styles.ctaButton}
                variant={tier.recommended ? 'default' : 'outline'}
                size="lg"
                onClick={() => handleUpgrade(tier.id)}
                disabled={isCurrentTier}
              >
                {isCurrentTier ? 'Current Plan' : tier.cta}
              </Button>

              <div className={styles.tierFeatures}>
                <div className={styles.featuresLabel}>What's included:</div>
                <ul className={styles.featuresList}>
                  {tier.features.map((feature, index) => (
                    <li key={index} className={styles.feature}>
                      <Check className={styles.checkIcon} />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </Card>
          );
        })}
      </div>

      <div className={styles.footer}>
        <p className={styles.footerText}>
          All plans include a 14-day money-back guarantee. No questions asked.
        </p>
        <p className={styles.footerText}>
          Need a custom enterprise plan? <a href="#contact">Contact us</a>
        </p>
      </div>
    </div>
  );
}
