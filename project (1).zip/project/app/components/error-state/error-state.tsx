import { AlertCircle, RefreshCw, Home } from 'lucide-react';
import { Button } from '~/components/ui/button/button';
import styles from './error-state.module.css';

interface ErrorStateProps {
  title?: string;
  message?: string;
  onRetry?: () => void;
  showHomeButton?: boolean;
}

export function ErrorState({
  title = 'Something went wrong',
  message = 'An unexpected error occurred. Please try again.',
  onRetry,
  showHomeButton = false,
}: ErrorStateProps) {
  return (
    <div className={styles.container}>
      <div className={styles.icon}>
        <AlertCircle size={64} />
      </div>
      <h2 className={styles.title}>{title}</h2>
      <p className={styles.message}>{message}</p>
      <div className={styles.actions}>
        {onRetry && (
          <Button onClick={onRetry}>
            <RefreshCw size={18} />
            Try Again
          </Button>
        )}
        {showHomeButton && (
          <Button variant="outline" asChild>
            <a href="/">
              <Home size={18} />
              Go Home
            </a>
          </Button>
        )}
      </div>
    </div>
  );
}

interface NotFoundStateProps {
  entity?: string;
  message?: string;
}

export function NotFoundState({
  entity = 'Page',
  message,
}: NotFoundStateProps) {
  return (
    <div className={styles.container}>
      <div className={styles.notFoundNumber}>404</div>
      <h2 className={styles.title}>{entity} Not Found</h2>
      <p className={styles.message}>
        {message || `The ${entity.toLowerCase()} you're looking for doesn't exist or has been removed.`}
      </p>
      <div className={styles.actions}>
        <Button asChild>
          <a href="/">
            <Home size={18} />
            Back to Home
          </a>
        </Button>
      </div>
    </div>
  );
}
