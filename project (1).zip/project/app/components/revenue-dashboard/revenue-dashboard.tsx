import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '~/components/ui/card/card';
import { Badge } from '~/components/ui/badge/badge';
import { Progress } from '~/components/ui/progress/progress';
import { DollarSign, TrendingUp, Award, Download } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import styles from './revenue-dashboard.module.css';

interface RevenueDashboardProps {
  revenue: {
    totalRevenue: number;
    currency: string;
    sources: Array<{
      platform: string;
      revenue: number;
      breakdown?: Array<{ name: string; amount: number }>;
    }>;
    monthlyTrend: Array<{ month: string; revenue: number }>;
    topEarningPlatform: string;
    yearToDateRevenue: number;
    projectedAnnualRevenue: number;
  };
  milestones: Array<{
    milestone: string;
    achieved: boolean;
    progress: number;
  }>;
  className?: string;
}

const PLATFORM_COLORS: Record<string, string> = {
  'Roblox': 'var(--color-accent-9)',
  'Unity Asset Store': 'var(--color-success-9)',
  'Itch.io': 'var(--red-9)',
  'Steam': 'var(--blue-9)',
  'Hugging Face': 'var(--yellow-9)',
  'GitHub Sponsors': 'var(--color-neutral-9)',
};

export function RevenueDashboard({ revenue, milestones, className }: RevenueDashboardProps) {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: revenue.currency,
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const pieData = revenue.sources.map(source => ({
    name: source.platform,
    value: source.revenue,
  }));

  return (
    <div className={`${styles.container} ${className || ''}`}>
      {/* Summary Cards */}
      <div className={styles.summaryGrid}>
        <Card>
          <CardHeader>
            <CardTitle className={styles.cardTitle}>
              <DollarSign size={18} />
              Total Revenue
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className={styles.statValue}>{formatCurrency(revenue.totalRevenue)}</div>
            <div className={styles.statLabel}>Year to date</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className={styles.cardTitle}>
              <TrendingUp size={18} />
              Projected Annual
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className={styles.statValue}>{formatCurrency(revenue.projectedAnnualRevenue)}</div>
            <div className={styles.statLabel}>Based on current trend</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className={styles.cardTitle}>
              <Award size={18} />
              Top Platform
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className={styles.statValue}>{revenue.topEarningPlatform}</div>
            <div className={styles.statLabel}>
              {formatCurrency(revenue.sources.find(s => s.platform === revenue.topEarningPlatform)?.revenue || 0)}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className={styles.chartsGrid}>
        {/* Monthly Revenue Trend */}
        <Card className={styles.chartCard}>
          <CardHeader>
            <CardTitle>Monthly Revenue Trend</CardTitle>
            <CardDescription>Revenue growth over time</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={revenue.monthlyTrend}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-neutral-6)" />
                <XAxis dataKey="month" stroke="var(--color-neutral-11)" />
                <YAxis stroke="var(--color-neutral-11)" />
                <Tooltip 
                  contentStyle={{ 
                    background: 'var(--color-neutral-2)', 
                    border: '1px solid var(--color-neutral-6)',
                    borderRadius: 'var(--radius-2)',
                  }}
                  formatter={(value: any) => formatCurrency(value)}
                />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="revenue" 
                  stroke="var(--color-accent-9)" 
                  strokeWidth={2}
                  name="Revenue"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Platform Breakdown */}
        <Card className={styles.chartCard}>
          <CardHeader>
            <CardTitle>Revenue by Platform</CardTitle>
            <CardDescription>Distribution across platforms</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={(entry) => `${entry.name}: ${formatCurrency(Number(entry.value) || 0)}`}
                  outerRadius={100}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={PLATFORM_COLORS[entry.name] || 'var(--color-neutral-9)'} 
                    />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    background: 'var(--color-neutral-2)', 
                    border: '1px solid var(--color-neutral-6)',
                    borderRadius: 'var(--radius-2)',
                  }}
                  formatter={(value: any) => formatCurrency(value)}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Platform Details */}
      <Card>
        <CardHeader>
          <CardTitle>Platform Revenue Details</CardTitle>
          <CardDescription>Detailed breakdown by platform and source</CardDescription>
        </CardHeader>
        <CardContent>
          <div className={styles.platformList}>
            {revenue.sources.map((source, index) => (
              <div key={index} className={styles.platformItem}>
                <div className={styles.platformHeader}>
                  <div className={styles.platformInfo}>
                    <span className={styles.platformName}>{source.platform}</span>
                    <span className={styles.platformRevenue}>{formatCurrency(source.revenue)}</span>
                  </div>
                </div>
                {source.breakdown && (
                  <div className={styles.breakdown}>
                    {source.breakdown.map((item, i) => (
                      <div key={i} className={styles.breakdownItem}>
                        <span className={styles.breakdownName}>{item.name}</span>
                        <span className={styles.breakdownAmount}>{formatCurrency(item.amount)}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Milestones */}
      <Card>
        <CardHeader>
          <CardTitle>Revenue Milestones</CardTitle>
          <CardDescription>Track your earnings achievements</CardDescription>
        </CardHeader>
        <CardContent>
          <div className={styles.milestonesList}>
            {milestones.map((milestone, index) => (
              <div key={index} className={styles.milestoneItem}>
                <div className={styles.milestoneHeader}>
                  <span className={styles.milestoneName}>{milestone.milestone}</span>
                  {milestone.achieved && (
                    <Badge variant="default">
                      <Award size={14} />
                      Achieved
                    </Badge>
                  )}
                </div>
                <Progress value={milestone.progress} className={styles.milestoneProgress} />
                <span className={styles.milestoneProgress}>{milestone.progress}%</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
