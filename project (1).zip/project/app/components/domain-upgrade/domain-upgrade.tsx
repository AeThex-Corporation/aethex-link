import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '~/components/ui/card/card';
import { Button } from '~/components/ui/button/button';
import { Input } from '~/components/ui/input/input';
import { Label } from '~/components/ui/label/label';
import { Badge } from '~/components/ui/badge/badge';
import { Alert, AlertDescription } from '~/components/ui/alert/alert';
import {
  Globe,
  Shield,
  Zap,
  ArrowRight,
  CheckCircle2,
  XCircle,
  Loader2,
} from 'lucide-react';
import styles from './domain-upgrade.module.css';

interface DomainUpgradeProps {
  currentUsername: string;
  onUpgradeComplete?: () => void;
}

export function DomainUpgrade({ currentUsername, onUpgradeComplete }: DomainUpgradeProps) {
  const [domain, setDomain] = useState(`${currentUsername}.aethex`);
  const [walletAddress, setWalletAddress] = useState('');
  const [isChecking, setIsChecking] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [isAvailable, setIsAvailable] = useState<boolean | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const handleCheckAvailability = async () => {
    setIsChecking(true);
    setError(null);
    setIsAvailable(null);

    try {
      const token = localStorage.getItem('auth_token');
      const response = await fetch('/api/domain/check', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ domain }),
      });

      const data = await response.json();
      
      if (response.ok) {
        setIsAvailable(data.available);
      } else {
        setError(data.error || 'Failed to check availability');
      }
    } catch (err: any) {
      setError(err.message || 'Failed to check availability');
    } finally {
      setIsChecking(false);
    }
  };

  const handleUpgrade = async () => {
    if (!walletAddress || !isAvailable) return;

    setIsRegistering(true);
    setError(null);

    try {
      const token = localStorage.getItem('auth_token');
      const response = await fetch('/api/domain/upgrade', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ domain, walletAddress }),
      });

      const data = await response.json();
      
      if (response.ok) {
        setSuccess(true);
        onUpgradeComplete?.();
      } else {
        setError(data.error || 'Failed to upgrade domain');
      }
    } catch (err: any) {
      setError(err.message || 'Failed to upgrade domain');
    } finally {
      setIsRegistering(false);
    }
  };

  if (success) {
    return (
      <Card className={styles.successCard}>
        <CardContent className={styles.successContent}>
          <CheckCircle2 size={48} className={styles.successIcon} />
          <h3>Upgrade Successful!</h3>
          <p>Your premium .aethex domain is being registered on the blockchain.</p>
          <p className={styles.domainName}>{domain}</p>
          <Button onClick={() => window.location.reload()}>
            View Your Domain
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className={styles.container}>
      <Card>
        <CardHeader>
          <CardTitle className={styles.title}>
            <Globe size={20} />
            Upgrade to Premium Domain
          </CardTitle>
          <CardDescription>
            Own your blockchain-verified .aethex domain as an NFT
          </CardDescription>
        </CardHeader>
        <CardContent className={styles.content}>
          {/* Comparison Table */}
          <div className={styles.comparison}>
            <div className={styles.tier}>
              <div className={styles.tierHeader}>
                <h4>Free Tier</h4>
                <Badge variant="outline">Current</Badge>
              </div>
              <p className={styles.tierDomain}>{currentUsername}.aethex.me</p>
              <ul className={styles.features}>
                <li><CheckCircle2 size={16} /> Portfolio page</li>
                <li><CheckCircle2 size={16} /> Platform connections</li>
                <li><CheckCircle2 size={16} /> Custom URL</li>
                <li><XCircle size={16} className={styles.disabled} /> Blockchain verified</li>
                <li><XCircle size={16} className={styles.disabled} /> Transferable NFT</li>
                <li><XCircle size={16} className={styles.disabled} /> Custom DNS</li>
              </ul>
            </div>

            <ArrowRight size={24} className={styles.arrow} />

            <div className={`${styles.tier} ${styles.premium}`}>
              <div className={styles.tierHeader}>
                <h4>Premium</h4>
                <Badge>
                  <Zap size={12} />
                  $10/year
                </Badge>
              </div>
              <p className={styles.tierDomain}>{currentUsername}.aethex</p>
              <ul className={styles.features}>
                <li><CheckCircle2 size={16} /> Portfolio page</li>
                <li><CheckCircle2 size={16} /> Platform connections</li>
                <li><CheckCircle2 size={16} /> Custom URL</li>
                <li><CheckCircle2 size={16} className={styles.highlight} /> Blockchain verified</li>
                <li><CheckCircle2 size={16} className={styles.highlight} /> Transferable NFT</li>
                <li><CheckCircle2 size={16} className={styles.highlight} /> Custom DNS</li>
                <li><CheckCircle2 size={16} className={styles.highlight} /> Verified badge</li>
                <li><CheckCircle2 size={16} className={styles.highlight} /> Sell on marketplace</li>
              </ul>
            </div>
          </div>

          {/* Domain Registration Form */}
          <div className={styles.form}>
            <div className={styles.inputGroup}>
              <Label htmlFor="domain">Domain Name</Label>
              <div className={styles.domainInput}>
                <Input
                  id="domain"
                  type="text"
                  value={domain}
                  onChange={(e) => {
                    setDomain(e.target.value);
                    setIsAvailable(null);
                  }}
                  placeholder="yourusername.aethex"
                />
                <Button
                  onClick={handleCheckAvailability}
                  disabled={isChecking || !domain}
                  variant="outline"
                >
                  {isChecking ? (
                    <Loader2 size={16} className={styles.spinner} />
                  ) : (
                    'Check'
                  )}
                </Button>
              </div>
              
              {isAvailable !== null && (
                <div className={styles.availability}>
                  {isAvailable ? (
                    <Badge variant="default">
                      <CheckCircle2 size={12} />
                      Available
                    </Badge>
                  ) : (
                    <Badge variant="destructive">
                      <XCircle size={12} />
                      Not Available
                    </Badge>
                  )}
                </div>
              )}
            </div>

            <div className={styles.inputGroup}>
              <Label htmlFor="wallet">Polygon Wallet Address</Label>
              <Input
                id="wallet"
                type="text"
                value={walletAddress}
                onChange={(e) => setWalletAddress(e.target.value)}
                placeholder="0x..."
              />
              <p className={styles.hint}>
                Your domain will be minted as an NFT to this address
              </p>
            </div>

            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <Button
              onClick={handleUpgrade}
              disabled={!isAvailable || !walletAddress || isRegistering}
              className={styles.upgradeButton}
              size="lg"
            >
              {isRegistering ? (
                <>
                  <Loader2 size={18} className={styles.spinner} />
                  Processing...
                </>
              ) : (
                <>
                  <Shield size={18} />
                  Upgrade for $10/year
                </>
              )}
            </Button>

            <div className={styles.benefits}>
              <Shield size={16} />
              <p>
                Your domain is registered on the Polygon blockchain and owned as an NFT.
                You can transfer, sell, or use it across Web3 applications.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
