import { type ReactNode } from 'react';
import styles from './gradient-text.module.css';

interface GradientTextProps {
  children: ReactNode;
  className?: string;
  animated?: boolean;
}

export function GradientText({ children, className = '', animated = false }: GradientTextProps) {
  return (
    <span className={`${styles.gradientText} ${animated ? styles.animated : ''} ${className}`}>
      {children}
    </span>
  );
}
