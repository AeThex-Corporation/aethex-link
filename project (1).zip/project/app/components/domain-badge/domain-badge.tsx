import { Globe, Shield } from 'lucide-react';
import { Badge } from '~/components/ui/badge/badge';
import styles from './domain-badge.module.css';

interface DomainBadgeProps {
  domain: string;
  verified?: boolean;
  size?: 'sm' | 'md' | 'lg';
  showIcon?: boolean;
  className?: string;
}

export function DomainBadge({ 
  domain, 
  verified = true, 
  size = 'md', 
  showIcon = true,
  className 
}: DomainBadgeProps) {
  return (
    <Badge 
      variant={verified ? 'default' : 'secondary'} 
      className={`${styles.badge} ${styles[size]} ${className || ''}`}
    >
      {showIcon && (
        verified ? <Shield size={12} /> : <Globe size={12} />
      )}
      <span className={styles.domain}>{domain}</span>
    </Badge>
  );
}
