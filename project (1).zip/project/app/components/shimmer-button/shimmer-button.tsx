import { type ReactNode } from 'react';
import { Button, type ButtonProps } from '../ui/button/button';
import styles from './shimmer-button.module.css';

interface ShimmerButtonProps extends ButtonProps {
  children: ReactNode;
}

export function ShimmerButton({ children, className = '', ...props }: ShimmerButtonProps) {
  return (
    <Button {...props} className={`${styles.shimmerButton} ${className}`}>
      <span className={styles.shimmer} />
      {children}
    </Button>
  );
}
