import styles from './floating-shapes.module.css';

export function FloatingShapes() {
  return (
    <div className={styles.shapesContainer}>
      <div className={`${styles.shape} ${styles.shape1}`} />
      <div className={`${styles.shape} ${styles.shape2}`} />
      <div className={`${styles.shape} ${styles.shape3}`} />
      <div className={`${styles.shape} ${styles.shape4}`} />
      <div className={`${styles.shape} ${styles.shape5}`} />
    </div>
  );
}
