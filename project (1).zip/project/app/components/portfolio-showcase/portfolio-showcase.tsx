import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '~/components/ui/card/card';
import { Badge } from '~/components/ui/badge/badge';
import { Button } from '~/components/ui/button/button';
import { Gamepad2, Brain, Code2, ExternalLink, Eye, Heart, Download, Play } from 'lucide-react';
import styles from './portfolio-showcase.module.css';

interface PortfolioItem {
  id: string;
  type: 'game' | 'ai_model' | 'asset' | 'project';
  title: string;
  description: string;
  platform: string;
  url?: string;
  thumbnailUrl?: string;
  videoUrl?: string;
  stats?: {
    views?: number;
    likes?: number;
    downloads?: number;
    plays?: number;
    rating?: number;
  };
  tags: string[];
  featured: boolean;
}

interface PortfolioShowcaseProps {
  items: PortfolioItem[];
  type?: 'game' | 'ai_model' | 'asset' | 'project';
  className?: string;
}

const typeIcons = {
  game: Gamepad2,
  ai_model: Brain,
  asset: Code2,
  project: Code2,
};

const platformColors: Record<string, string> = {
  'Roblox': 'var(--red-9)',
  'Unity': 'var(--color-neutral-9)',
  'Unreal': 'var(--blue-9)',
  'Steam': 'var(--indigo-9)',
  'Itch.io': 'var(--red-9)',
  'Hugging Face': 'var(--yellow-9)',
  'Kaggle': 'var(--cyan-9)',
  'GitHub': 'var(--color-neutral-9)',
};

export function PortfolioShowcase({ items, type, className }: PortfolioShowcaseProps) {
  const filteredItems = type ? items.filter(item => item.type === type) : items;
  const featuredItems = filteredItems.filter(item => item.featured);
  const regularItems = filteredItems.filter(item => !item.featured);

  const formatNumber = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const renderItem = (item: PortfolioItem) => {
    const Icon = typeIcons[item.type];

    return (
      <Card key={item.id} className={`${styles.portfolioCard} ${item.featured ? styles.featured : ''}`}>
        {item.thumbnailUrl && (
          <div className={styles.thumbnail}>
            <img src={item.thumbnailUrl} alt={item.title} />
            {item.videoUrl && (
              <div className={styles.playOverlay}>
                <Play size={48} />
              </div>
            )}
            {item.featured && (
              <Badge className={styles.featuredBadge} variant="default">Featured</Badge>
            )}
          </div>
        )}
        
        <CardHeader>
          <div className={styles.cardHeaderContent}>
            <CardTitle className={styles.cardTitle}>
              <Icon size={18} />
              {item.title}
            </CardTitle>
            <Badge 
              variant="outline" 
              style={{ backgroundColor: platformColors[item.platform] || 'var(--color-neutral-6)' }}
            >
              {item.platform}
            </Badge>
          </div>
          <CardDescription>{item.description}</CardDescription>
        </CardHeader>

        <CardContent>
          {item.stats && (
            <div className={styles.stats}>
              {item.stats.views !== undefined && (
                <div className={styles.stat}>
                  <Eye size={16} />
                  <span>{formatNumber(item.stats.views)}</span>
                </div>
              )}
              {item.stats.likes !== undefined && (
                <div className={styles.stat}>
                  <Heart size={16} />
                  <span>{formatNumber(item.stats.likes)}</span>
                </div>
              )}
              {item.stats.downloads !== undefined && (
                <div className={styles.stat}>
                  <Download size={16} />
                  <span>{formatNumber(item.stats.downloads)}</span>
                </div>
              )}
              {item.stats.plays !== undefined && (
                <div className={styles.stat}>
                  <Play size={16} />
                  <span>{formatNumber(item.stats.plays)}</span>
                </div>
              )}
              {item.stats.rating !== undefined && (
                <div className={styles.stat}>
                  <span className={styles.rating}>★ {item.stats.rating.toFixed(1)}</span>
                </div>
              )}
            </div>
          )}

          {item.tags.length > 0 && (
            <div className={styles.tags}>
              {item.tags.slice(0, 4).map((tag, index) => (
                <Badge key={index} variant="secondary">{tag}</Badge>
              ))}
            </div>
          )}

          {item.url && (
            <Button variant="outline" className={styles.viewButton} asChild>
              <a href={item.url} target="_blank" rel="noopener noreferrer">
                <ExternalLink size={16} />
                View Project
              </a>
            </Button>
          )}
        </CardContent>
      </Card>
    );
  };

  return (
    <div className={`${styles.container} ${className || ''}`}>
      {featuredItems.length > 0 && (
        <div className={styles.section}>
          <h2 className={styles.sectionTitle}>Featured</h2>
          <div className={styles.featuredGrid}>
            {featuredItems.map(renderItem)}
          </div>
        </div>
      )}

      {regularItems.length > 0 && (
        <div className={styles.section}>
          {featuredItems.length > 0 && <h2 className={styles.sectionTitle}>All Projects</h2>}
          <div className={styles.grid}>
            {regularItems.map(renderItem)}
          </div>
        </div>
      )}

      {filteredItems.length === 0 && (
        <div className={styles.empty}>
          <p>No portfolio items yet</p>
        </div>
      )}
    </div>
  );
}
