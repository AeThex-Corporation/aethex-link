import { useState, useEffect } from 'react';
import { Button } from '~/components/ui/button/button';
import { Input } from '~/components/ui/input/input';
import { Label } from '~/components/ui/label/label';
import { Badge } from '~/components/ui/badge/badge';
import { Alert, AlertDescription } from '~/components/ui/alert/alert';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '~/components/ui/dialog/dialog';
import { 
  Globe, 
  Check, 
  X, 
  Loader2, 
  Shield, 
  Wallet,
  ExternalLink,
} from 'lucide-react';
import styles from './domain-registration.module.css';

interface DomainAvailability {
  domain: string;
  available: boolean;
  price?: number;
  currency?: string;
  premium?: boolean;
}

interface DomainRegistrationProps {
  onSuccess?: (domain: string) => void;
}

export function DomainRegistration({ onSuccess }: DomainRegistrationProps) {
  const [username, setUsername] = useState('');
  const [walletAddress, setWalletAddress] = useState('');
  const [isChecking, setIsChecking] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [availability, setAvailability] = useState<DomainAvailability | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  // Check availability when username changes
  useEffect(() => {
    if (!username || username.length < 3) {
      setAvailability(null);
      return;
    }

    const timer = setTimeout(async () => {
      await checkAvailability();
    }, 500);

    return () => clearTimeout(timer);
  }, [username]);

  const checkAvailability = async () => {
    if (!/^[a-zA-Z0-9_-]{3,20}$/.test(username)) {
      setError('Username must be 3-20 characters and contain only letters, numbers, hyphens, and underscores');
      setAvailability(null);
      return;
    }

    setIsChecking(true);
    setError(null);

    try {
      const response = await fetch(`/api/domain/check?username=${encodeURIComponent(username)}`);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error);
      }

      setAvailability(data);
    } catch (err: any) {
      setError(err.message || 'Failed to check availability');
      setAvailability(null);
    } finally {
      setIsChecking(false);
    }
  };

  const handleRegister = async () => {
    if (!availability?.available) return;

    setIsRegistering(true);
    setError(null);

    try {
      const token = localStorage.getItem('auth_token');
      const response = await fetch('/api/domain/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          username,
          walletAddress: walletAddress || undefined,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error);
      }

      setSuccess(true);
      if (onSuccess) {
        onSuccess(data.domain.domain);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to register domain');
    } finally {
      setIsRegistering(false);
    }
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button className={styles.trigger}>
          <Globe size={16} />
          Register .aethex Domain
        </Button>
      </DialogTrigger>
      <DialogContent className={styles.dialog}>
        <DialogHeader>
          <DialogTitle className={styles.title}>
            <Globe className={styles.titleIcon} />
            Claim Your .aethex Domain
          </DialogTitle>
          <DialogDescription className={styles.description}>
            Get your blockchain-verified Web3 identity. Your .aethex domain becomes your universal creator identity.
          </DialogDescription>
        </DialogHeader>

        {!success ? (
          <div className={styles.content}>
            {/* Username Input */}
            <div className={styles.field}>
              <Label htmlFor="username">Choose Your Username</Label>
              <div className={styles.inputWrapper}>
                <Input
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value.toLowerCase())}
                  placeholder="yourname"
                  className={styles.input}
                  disabled={isRegistering}
                />
                <span className={styles.suffix}>.aethex</span>
              </div>
              
              {/* Availability Status */}
              {isChecking && (
                <div className={styles.status}>
                  <Loader2 className={styles.spinner} size={16} />
                  <span>Checking availability...</span>
                </div>
              )}
              
              {availability && !isChecking && (
                <div className={`${styles.status} ${availability.available ? styles.available : styles.unavailable}`}>
                  {availability.available ? (
                    <>
                      <Check size={16} />
                      <span>{availability.domain} is available!</span>
                      {availability.premium && <Badge variant="secondary">Premium</Badge>}
                    </>
                  ) : (
                    <>
                      <X size={16} />
                      <span>{availability.domain} is not available</span>
                    </>
                  )}
                </div>
              )}
            </div>

            {/* Wallet Address (Optional) */}
            <div className={styles.field}>
              <Label htmlFor="wallet">
                Wallet Address <span className={styles.optional}>(optional)</span>
              </Label>
              <div className={styles.inputWrapper}>
                <Wallet className={styles.inputIcon} size={16} />
                <Input
                  id="wallet"
                  value={walletAddress}
                  onChange={(e) => setWalletAddress(e.target.value)}
                  placeholder="0x..."
                  className={styles.input}
                  disabled={isRegistering}
                />
              </div>
              <p className={styles.hint}>
                Link your wallet to enable on-chain verification and transfers
              </p>
            </div>

            {/* Pricing */}
            {availability?.available && (
              <div className={styles.pricing}>
                <div className={styles.pricingRow}>
                  <span>Registration (1 year)</span>
                  <span className={styles.price}>
                    {availability.currency === 'USD' ? '$' : ''}{availability.price}
                    {availability.currency !== 'USD' ? ` ${availability.currency}` : ''}
                  </span>
                </div>
                {availability.premium && (
                  <Alert className={styles.premiumAlert}>
                    <Shield size={16} />
                    <AlertDescription>
                      Premium domain - includes additional features and priority support
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            )}

            {/* Error Message */}
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {/* Features */}
            <div className={styles.features}>
              <h4 className={styles.featuresTitle}>What You Get:</h4>
              <ul className={styles.featuresList}>
                <li>
                  <Shield size={14} />
                  <span>Blockchain-verified identity</span>
                </li>
                <li>
                  <Globe size={14} />
                  <span>Custom portfolio page at {username || 'yourname'}.aethex</span>
                </li>
                <li>
                  <Check size={14} />
                  <span>Verified creator badge across platform</span>
                </li>
                <li>
                  <Wallet size={14} />
                  <span>Portable Web3 identity you own</span>
                </li>
              </ul>
            </div>

            {/* Actions */}
            <div className={styles.actions}>
              <Button
                onClick={handleRegister}
                disabled={!availability?.available || isRegistering}
                className={styles.registerButton}
              >
                {isRegistering ? (
                  <>
                    <Loader2 className={styles.spinner} size={16} />
                    Registering...
                  </>
                ) : (
                  <>
                    <Shield size={16} />
                    Register Domain
                  </>
                )}
              </Button>
            </div>
          </div>
        ) : (
          <div className={styles.successContent}>
            <div className={styles.successIcon}>
              <Check size={48} />
            </div>
            <h3 className={styles.successTitle}>Domain Registered!</h3>
            <p className={styles.successMessage}>
              Your .aethex domain is now active and verified on the blockchain.
            </p>
            <div className={styles.successDomain}>
              <Globe size={20} />
              <span>{username}.aethex</span>
              <Badge variant="default">
                <Shield size={12} />
                Verified
              </Badge>
            </div>
            <div className={styles.successActions}>
              <Button variant="outline" asChild>
                <a href={`https://${username}.aethex`} target="_blank" rel="noopener noreferrer">
                  <ExternalLink size={16} />
                  View Portfolio
                </a>
              </Button>
              <Button onClick={() => window.location.reload()}>
                Go to Dashboard
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
