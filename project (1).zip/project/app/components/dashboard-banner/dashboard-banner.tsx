import { X, Sparkles, Link2 } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router';
import { Button } from '~/components/ui/button/button';
import { Card } from '~/components/ui/card/card';
import styles from './dashboard-banner.module.css';

interface DashboardBannerProps {
  type: 'onboarding' | 'oauth' | 'premium';
  onDismiss?: () => void;
}

export function DashboardBanner({ type, onDismiss }: DashboardBannerProps) {
  const [dismissed, setDismissed] = useState(false);

  const handleDismiss = () => {
    setDismissed(true);
    onDismiss?.();
    localStorage.setItem(`banner_${type}_dismissed`, 'true');
  };

  if (dismissed || localStorage.getItem(`banner_${type}_dismissed`)) {
    return null;
  }

  const banners = {
    onboarding: {
      icon: <Sparkles />,
      title: 'Complete your profile setup',
      description: 'Connect your platforms and complete your profile to get the most out of CreatorHub',
      action: {
        label: 'Complete Setup',
        to: '/onboarding',
      },
      variant: 'accent' as const,
    },
    oauth: {
      icon: <Link2 />,
      title: 'Connect with OAuth',
      description: 'Use OAuth to automatically sync your GitHub, GitLab, and other accounts',
      action: {
        label: 'Connect Accounts',
        to: '/profile',
      },
      variant: 'success' as const,
    },
    premium: {
      icon: <Sparkles />,
      title: 'Upgrade to Premium',
      description: 'Unlock advanced analytics, custom domains, and priority support',
      action: {
        label: 'View Plans',
        to: '/premium',
      },
      variant: 'default' as const,
    },
  };

  const banner = banners[type];

  return (
    <Card className={`${styles.banner} ${styles[`banner${banner.variant.charAt(0).toUpperCase()}${banner.variant.slice(1)}`]}`}>
      <div className={styles.content}>
        <div className={styles.icon}>{banner.icon}</div>
        <div className={styles.text}>
          <h3 className={styles.title}>{banner.title}</h3>
          <p className={styles.description}>{banner.description}</p>
        </div>
        <Button asChild size="sm">
          <Link to={banner.action.to}>{banner.action.label}</Link>
        </Button>
      </div>
      <button className={styles.dismissButton} onClick={handleDismiss} aria-label="Dismiss">
        <X />
      </button>
    </Card>
  );
}
