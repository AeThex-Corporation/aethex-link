import styles from './pulse-dot.module.css';

interface PulseDotProps {
  color?: 'accent' | 'success' | 'error';
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export function PulseDot({ color = 'accent', size = 'md', className = '' }: PulseDotProps) {
  return (
    <span className={`${styles.pulseDot} ${styles[color]} ${styles[size]} ${className}`}>
      <span className={styles.ping} />
      <span className={styles.dot} />
    </span>
  );
}
