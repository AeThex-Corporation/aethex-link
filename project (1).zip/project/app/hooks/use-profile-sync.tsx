import { useState } from 'react';

export function useProfileSync() {
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSynced, setLastSynced] = useState<Date | null>(null);
  const [error, setError] = useState<string | null>(null);

  const syncProfile = async () => {
    setIsSyncing(true);
    setError(null);

    try {
      const response = await fetch('/api/profile/sync', {
        method: 'POST',
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to sync profile');
      }

      setLastSynced(new Date());
      return data.profile;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      setError(errorMessage);
      throw err;
    } finally {
      setIsSyncing(false);
    }
  };

  return {
    syncProfile,
    isSyncing,
    lastSynced,
    error,
  };
}
