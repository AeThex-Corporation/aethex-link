/**
 * Utility functions for exporting analytics data
 */

export function downloadAnalytics(format: 'csv' | 'json', range: string = '30d') {
  const url = `/api/analytics/export?format=${format}&range=${range}`;
  
  // Create a temporary link and trigger download
  const link = document.createElement('a');
  link.href = url;
  link.download = `analytics-${range}.${format}`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function shareAnalytics(data: any): string {
  // Generate a shareable summary
  const summary = `
📊 CreatorHub Analytics Summary

Profile Views: ${data.profileViews?.total?.toLocaleString() || 0}
Total Reach: ${data.engagement?.profileClicks?.toLocaleString() || 0}
Market Value: $${data.marketValue?.estimated?.toLocaleString() || 0}
Top Percentile: ${data.marketValue?.percentile || 0}%

View my full profile at CreatorHub!
  `.trim();

  return summary;
}

export function formatAnalyticsForPDF(data: any): any {
  // Format data for PDF generation
  return {
    title: 'CreatorHub Analytics Report',
    generatedAt: new Date().toISOString(),
    sections: [
      {
        title: 'Profile Performance',
        metrics: {
          'Total Views': data.profileViews?.total,
          'Unique Visitors': data.profileViews?.unique,
          'Profile Clicks': data.engagement?.profileClicks,
          'Platform Clicks': data.engagement?.platformClicks,
        },
      },
      {
        title: 'Skills & Growth',
        skills: data.skillGrowth || [],
      },
      {
        title: 'Revenue Overview',
        revenue: {
          total: data.revenue?.total,
          projected: data.revenue?.projectedAnnual,
          breakdown: data.revenue?.bySource,
        },
      },
      {
        title: 'Market Value',
        value: {
          estimated: data.marketValue?.estimated,
          percentile: data.marketValue?.percentile,
          trend: data.marketValue?.trend,
        },
      },
    ],
  };
}
